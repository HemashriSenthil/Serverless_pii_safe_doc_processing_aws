// Fast, Streamlined Document Redaction Studio Client
const API_BASE = window.location.origin;

let currentDocuments = [];
let selectedDocId = null;
let pollTimer = null;
let isUploading = false;

// DOM Elements
const connectionStatus = document.getElementById("connection-status");
const metricTotal = document.getElementById("metric-total");
const metricCompleted = document.getElementById("metric-completed");
const metricProcessing = document.getElementById("metric-processing");
const metricFailed = document.getElementById("metric-failed");
const metricPii = document.getElementById("metric-pii");
const metricDlq = document.getElementById("metric-dlq");

const statusFilter = document.getElementById("status-filter");

const dropZone = document.getElementById("drop-zone");
const fileInput = document.getElementById("file-input");
const browseBtn = document.getElementById("browse-btn");
const uploadSpinner = document.getElementById("upload-spinner");
const spinnerMsg = document.getElementById("spinner-msg");
const dropContent = document.querySelector(".drop-content");

const ledgerBody = document.getElementById("ledger-body");
const refreshBtn = document.getElementById("refresh-btn");

const inspectorEmpty = document.getElementById("inspector-empty");
const inspectorContent = document.getElementById("inspector-content");
const inspectFileName = document.getElementById("inspect-file-name");
const inspectorStatusBadge = document.getElementById("inspector-status-badge");
const inspectPiiCount = document.getElementById("inspect-pii-count");
const inspectDuration = document.getElementById("inspect-duration");
const inspectOcrEngine = document.getElementById("inspect-ocr-engine");
const inspectPiiEngine = document.getElementById("inspect-pii-engine");

const timelineContainer = document.getElementById("timeline-container");
const timelineFlow = document.getElementById("timeline-flow");

const failureBanner = document.getElementById("failure-banner");
const failureStagePill = document.getElementById("failure-stage-pill");
const failureReasonText = document.getElementById("failure-reason-text");
const piiBreakdownSection = document.getElementById("pii-breakdown-section");
const piiTagList = document.getElementById("pii-tag-list");

const redactedTextBox = document.getElementById("redacted-text-box");
const copyTextBtn = document.getElementById("copy-text-btn");
const downloadTextBtn = document.getElementById("download-text-btn");

const customKeywordsInput = document.getElementById("custom-keywords-input");

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  setupUploadEvents();
  setupSampleButtons();
  setupActionButtons();

  if (statusFilter) {
    statusFilter.addEventListener("change", () => {
      renderLedger(currentDocuments);
    });
  }

  fetchDocuments();

  // Background refresh every 3 seconds (paused during active uploads)
  pollTimer = setInterval(() => {
    if (!isUploading) {
      fetchDocuments(false);
    }
  }, 3000);
});

// Masking rules collection (Additive keywords only; server default-denies all PII)
function getSelectedMasks() {
  const checkboxes = document.querySelectorAll(".rules-checkboxes input[type='checkbox']:checked");
  return Array.from(checkboxes).map(cb => cb.value).join(",");
}

function getSelectedMaskMode() {
  const selected = document.querySelector("input[name='mask-mode']:checked");
  return selected ? selected.value : "LABEL";
}

function getCustomKeywords() {
  return customKeywordsInput ? customKeywordsInput.value.trim() : "";
}

// File Upload & Drag-and-drop
function setupUploadEvents() {
  browseBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    fileInput.click();
  });

  dropZone.addEventListener("click", () => {
    if (!isUploading) fileInput.click();
  });

  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("drag-over");
  });

  dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("drag-over");
  });

  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.classList.remove("drag-over");
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      uploadLocalFile(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) {
      uploadLocalFile(e.target.files[0]);
    }
  });
}

// Real-time tracking loop: polls until Lambda finishes and renders text instantly
// Matches document deterministically by server-returned document_id (F19)
async function trackUploadedDocument(targetDocId, fileName, uploadStartTime = null) {
  const startTime = Date.now();
  const maxWaitMs = 15000;
  const pollInterval = 350;
  const minTimestamp = uploadStartTime || new Date(Date.now() - 4000).toISOString();

  spinnerMsg.innerText = `Uploaded to S3 raw bucket. Triggering AWS Lambda...`;

  while (Date.now() - startTime < maxWaitMs) {
    try {
      const res = await fetch(`${API_BASE}/documents`);
      if (res.ok) {
        const data = await res.json();
        const docs = data.documents || [];
        if (data.stats) updateStatsUI(data.stats);

        // Deterministic matching by document_id first, falling back to file name
        let match = null;
        if (targetDocId) {
          match = docs.find(d => d.document_id === targetDocId);
        }
        if (!match && fileName) {
          match = docs.find(d => d.file_name === fileName && (d.upload_timestamp || "") >= minTimestamp);
        }
        if (!match && (Date.now() - startTime > 4000) && fileName) {
          match = docs.find(d => d.file_name === fileName);
        }

        if (match) {
          const status = (match.status || "").toUpperCase();
          if (status === "PROCESSING") {
            spinnerMsg.innerText = `AWS Lambda processing... Running OCR & PII redaction...`;
          } else if (status === "COMPLETED") {
            spinnerMsg.innerText = `✓ Redaction complete! Rendering results...`;
            currentDocuments = docs;
            renderLedger(docs);
            await inspectDocument(match);
            finishUpload();
            return;
          } else if (status === "FAILED") {
            spinnerMsg.innerText = `Processing completed with failure. Displaying result...`;
            currentDocuments = docs;
            renderLedger(docs);
            await inspectDocument(match);
            finishUpload();
            return;
          }
        }
      }
    } catch (e) {
      console.warn("Polling error:", e);
    }
    await new Promise(r => setTimeout(r, pollInterval));
  }

  // Fallback after timeout
  await fetchDocuments(true, fileName);
  finishUpload();
}

// Direct Local File Upload (with F19 robust error handling in reader.onload)
async function uploadLocalFile(file) {
  isUploading = true;
  dropContent.style.display = "none";
  uploadSpinner.style.display = "flex";
  spinnerMsg.innerText = `Uploading ${file.name} to S3 raw storage...`;

  try {
    const reader = new FileReader();

    reader.onerror = () => {
      console.error("FileReader failed to read file.");
      alert(`Could not read file "${file.name}".`);
      finishUpload();
    };

    reader.onload = async () => {
      try {
        const base64Data = reader.result.split(",")[1];
        const masks = getSelectedMasks();
        const keywords = getCustomKeywords();
        const mode = getSelectedMaskMode();
        const uploadStartTime = new Date(Date.now() - 2000).toISOString();

        const res = await fetch(`${API_BASE}/upload-direct`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            file_name: file.name,
            data_base64: base64Data,
            mask_types: masks,
            custom_keywords: keywords,
            mask_mode: mode
          })
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || `Upload failed with HTTP ${res.status}`);
        }

        const resData = await res.json();
        // Track processing by deterministic server-returned document_id
        await trackUploadedDocument(resData.document_id, file.name, uploadStartTime);
      } catch (err) {
        console.error("Upload handler error:", err);
        alert(`Upload failed: ${err.message}`);
        finishUpload();
      }
    };

    reader.readAsDataURL(file);
  } catch (err) {
    console.error("Upload initiation error:", err);
    alert(`Upload failed: ${err.message}`);
    finishUpload();
  }
}

// Sample buttons
function setupSampleButtons() {
  document.querySelectorAll(".sample-pill").forEach(btn => {
    btn.addEventListener("click", async () => {
      const fileName = btn.getAttribute("data-file");
      if (!fileName) return;

      isUploading = true;
      dropContent.style.display = "none";
      uploadSpinner.style.display = "flex";
      spinnerMsg.innerText = `Uploading ${fileName} to pipeline...`;

      try {
        const masks = encodeURIComponent(getSelectedMasks());
        const keywords = encodeURIComponent(getCustomKeywords());
        const mode = encodeURIComponent(getSelectedMaskMode());
        const uploadStartTime = new Date(Date.now() - 2000).toISOString();
        const res = await fetch(`${API_BASE}/upload-sample?file=${encodeURIComponent(fileName)}&masks=${masks}&keywords=${keywords}&mode=${mode}`, {
          method: "POST"
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || `Sample ingestion failed with HTTP ${res.status}`);
        }

        const resData = await res.json();
        await trackUploadedDocument(resData.document_id, fileName, uploadStartTime);
      } catch (err) {
        console.error("Sample upload error:", err);
        alert(`Failed to upload sample: ${err.message}`);
        finishUpload();
      }
    });
  });
}

function finishUpload() {
  isUploading = false;
  uploadSpinner.style.display = "none";
  dropContent.style.display = "block";
  if (fileInput) fileInput.value = "";
}

// Setup Copy & Download Buttons
function setupActionButtons() {
  refreshBtn.addEventListener("click", () => {
    fetchDocuments(true);
  });

  copyTextBtn.addEventListener("click", () => {
    const text = redactedTextBox.innerText;
    navigator.clipboard.writeText(text);
    copyTextBtn.innerText = "✓ Copied!";
    setTimeout(() => { copyTextBtn.innerText = "📋 Copy Text"; }, 1500);
  });

  downloadTextBtn.addEventListener("click", () => {
    const text = redactedTextBox.innerText;
    const docName = inspectFileName.innerText || "redacted_document";
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${docName}.redacted.txt`;
    a.click();
    URL.revokeObjectURL(url);
  });
}

function updateStatsUI(stats) {
  if (!stats) return;
  metricTotal.innerText = stats.total_documents ?? 0;
  metricCompleted.innerText = stats.completed ?? 0;
  if (metricProcessing) metricProcessing.innerText = stats.processing ?? 0;
  metricFailed.innerText = stats.failed ?? 0;
  if (metricPii) metricPii.innerText = stats.total_pii_redacted ?? 0;
  if (metricDlq) metricDlq.innerText = stats.dlq_message_count ?? 0;
  connectionStatus.innerText = "Live Connected";
}

// Fetch System Stats (fallback)
async function fetchStats() {
  try {
    const res = await fetch(`${API_BASE}/stats`);
    if (!res.ok) return;
    const data = await res.json();
    updateStatsUI(data);
  } catch (err) {
    connectionStatus.innerText = "Standby";
  }
}

// Fetch Document Ledger
async function fetchDocuments(forceRerender = false, selectFileName = null) {
  try {
    const res = await fetch(`${API_BASE}/documents`);
    if (!res.ok) return;
    const data = await res.json();
    const docs = data.documents || [];
    if (data.stats) updateStatsUI(data.stats);

    if (!forceRerender && JSON.stringify(docs) === JSON.stringify(currentDocuments)) {
      return;
    }

    currentDocuments = docs;
    renderLedger(docs);

    // If selectFileName was specified, select that newest matching document
    if (selectFileName) {
      const match = docs.find(d => d.file_name === selectFileName);
      if (match) {
        inspectDocument(match);
        return;
      }
    }

    // If an item is currently selected, refresh its details
    if (selectedDocId) {
      const updated = docs.find(d => d.document_id === selectedDocId);
      if (updated) inspectDocument(updated);
    } else if (docs.length > 0 && !selectedDocId) {
      // Auto-select the first document
      inspectDocument(docs[0]);
    }
  } catch (err) {
    console.warn("Could not fetch documents:", err);
  }
}

// Render Document Ledger with Status Filter Support
function renderLedger(docs) {
  if (!docs || docs.length === 0) {
    ledgerBody.innerHTML = `<tr><td colspan="4" class="table-empty">No documents processed yet. Select a file above to begin.</td></tr>`;
    return;
  }

  const filterVal = statusFilter ? statusFilter.value : "ALL";
  const filtered = filterVal === "ALL"
    ? docs
    : docs.filter(d => (d.status || "").toUpperCase() === filterVal);

  if (filtered.length === 0) {
    ledgerBody.innerHTML = `<tr><td colspan="4" class="table-empty">No documents matching filter "${filterVal}".</td></tr>`;
    return;
  }

  ledgerBody.innerHTML = "";
  filtered.forEach(doc => {
    const tr = document.createElement("tr");
    if (doc.document_id === selectedDocId) tr.classList.add("active-row");

    const status = (doc.status || "PROCESSING").toUpperCase();
    const statusClass = status.toLowerCase();

    const timestamp = doc.upload_timestamp ? new Date(doc.upload_timestamp).toLocaleTimeString() : "-";
    const piiCount = doc.pii_count !== undefined ? doc.pii_count : 0;
    const piiLabel = status === "COMPLETED" ? `${piiCount} entities` : "-";

    tr.innerHTML = `
      <td><span class="status-pill ${statusClass}">${status}</span></td>
      <td><strong>${escapeHtml(doc.file_name || doc.document_id || "Document")}</strong></td>
      <td>${piiLabel}</td>
      <td>${timestamp}</td>
    `;

    tr.addEventListener("click", () => {
      document.querySelectorAll("#ledger-body tr").forEach(r => r.classList.remove("active-row"));
      tr.classList.add("active-row");
      inspectDocument(doc);
    });

    ledgerBody.appendChild(tr);
  });
}

// Inspect Selected Document
async function inspectDocument(doc) {
  selectedDocId = doc.document_id;
  inspectorEmpty.style.display = "none";
  inspectorContent.style.display = "flex";

  inspectFileName.innerText = doc.file_name || doc.document_id || "-";
  inspectPiiCount.innerText = doc.pii_count !== undefined ? doc.pii_count : 0;
  inspectDuration.innerText = doc.execution_duration_ms ? `${doc.execution_duration_ms} ms` : "-";

  const status = (doc.status || "PROCESSING").toUpperCase();
  inspectorStatusBadge.innerText = status;
  inspectorStatusBadge.className = `chip status-pill ${status.toLowerCase()}`;

  // Engine provenance (F18)
  if (inspectOcrEngine) {
    inspectOcrEngine.innerText = doc.ocr_engine || (status === "COMPLETED" ? "textract" : "-");
  }
  if (inspectPiiEngine) {
    inspectPiiEngine.innerText = doc.pii_engine || (status === "COMPLETED" ? "comprehend" : "-");
  }

  // Render stage timeline (F18)
  renderTimeline(doc.stages || []);

  // Failure display with step / reason
  if (status === "FAILED") {
    failureBanner.style.display = "block";
    if (failureStagePill) {
      failureStagePill.innerText = doc.error_step || "VALIDATION";
    }
    failureReasonText.innerText = `Step: ${doc.error_step || 'VALIDATION'}\nReason: ${doc.failure_reason || 'Document validation or processing error.'}`;
    piiBreakdownSection.style.display = "none";
  } else {
    failureBanner.style.display = "none";
    piiBreakdownSection.style.display = "flex";
  }

  // PII tags breakdown for this file
  piiTagList.innerHTML = "";
  const types = doc.pii_types_found || {};
  const entries = Object.entries(types);

  if (entries.length === 0) {
    piiTagList.innerHTML = `<span style="color: var(--text-dim); font-size: 0.8rem;">No sensitive entities detected or required masking.</span>`;
  } else {
    entries.forEach(([type, count]) => {
      const badge = document.createElement("span");
      badge.className = "pii-badge";
      badge.innerHTML = `[${escapeHtml(type)}] <span class="badge-count">${count}</span>`;
      piiTagList.appendChild(badge);
    });
  }

  // Fetch full redacted text from S3 via backend
  if (status === "COMPLETED") {
    try {
      redactedTextBox.innerText = "Loading redacted text from S3 Processed Bucket...";
      const res = await fetch(`${API_BASE}/document?id=${encodeURIComponent(doc.document_id)}`);
      if (res.ok) {
        const data = await res.json();
        const text = data.redacted_text || "Redacted document text is empty.";
        renderRedactedText(text);
        if (data.document) {
          if (data.document.stages && data.document.stages.length > 0) {
            renderTimeline(data.document.stages);
          }
          if (data.document.ocr_engine && inspectOcrEngine) {
            inspectOcrEngine.innerText = data.document.ocr_engine;
          }
          if (data.document.pii_engine && inspectPiiEngine) {
            inspectPiiEngine.innerText = data.document.pii_engine;
          }
        }
      } else {
        redactedTextBox.innerText = "Could not fetch redacted text.";
      }
    } catch (err) {
      redactedTextBox.innerText = `Notice: Redacted text could not be loaded: ${err.message}`;
    }
  } else if (status === "FAILED") {
    redactedTextBox.innerText = `No redacted text generated due to failure:\n\nStep: ${doc.error_step}\nReason: ${doc.failure_reason}`;
  } else {
    redactedTextBox.innerText = "Processing document in Lambda... Refreshing automatically.";
  }
}

// Render Timeline & Provenance (F18)
function renderTimeline(stages) {
  if (!timelineContainer || !timelineFlow) return;

  if (!stages || stages.length === 0) {
    timelineContainer.style.display = "none";
    timelineFlow.innerHTML = "";
    return;
  }

  timelineContainer.style.display = "flex";
  timelineFlow.innerHTML = "";

  stages.forEach((stage, index) => {
    const step = document.createElement("div");
    step.className = "timeline-step completed";

    const name = stage.stage || `step_${index + 1}`;
    const service = stage.service || "-";
    const duration = stage.duration_ms !== undefined ? stage.duration_ms : (stage.ms !== undefined ? stage.ms : 0);
    const at = stage.at || stage.timestamp;
    const timeStr = at ? new Date(at).toLocaleTimeString() : "";

    let itemsStr = "";
    if (stage.items !== undefined && stage.items !== null) {
      if (name === "uploaded" || name === "validated") {
        itemsStr = `${stage.items} B`;
      } else if (name === "ocr_done") {
        itemsStr = `${stage.items} lines`;
      } else if (name === "pii_done") {
        itemsStr = `${stage.items} PII`;
      } else if (name === "stored") {
        itemsStr = `${stage.items} chars`;
      } else {
        itemsStr = `${stage.items}`;
      }
    }

    step.innerHTML = `
      <div class="timeline-step-header">
        <span class="timeline-step-name">${escapeHtml(name)}</span>
        <span class="timeline-step-service">${escapeHtml(service)}</span>
      </div>
      <div class="timeline-step-meta">
        <span>${duration}ms</span>
        <span>${escapeHtml(itemsStr || timeStr)}</span>
      </div>
    `;

    timelineFlow.appendChild(step);

    if (index < stages.length - 1) {
      const arrow = document.createElement("span");
      arrow.className = "timeline-arrow";
      arrow.innerText = "→";
      timelineFlow.appendChild(arrow);
    }
  });
}

// Render syntax highlighted redacted text
function renderRedactedText(text) {
  const escaped = escapeHtml(text);
  const regex = /\[([A-Z_]+)\]/g;
  const highlighted = escaped.replace(regex, '<span class="redacted-chip">[$1]</span>');
  redactedTextBox.innerHTML = highlighted;
}

function escapeHtml(str) {
  if (!str) return "";
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
