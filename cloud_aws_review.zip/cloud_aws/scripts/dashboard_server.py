import os
import sys
import json
import time
import base64
import hashlib
from decimal import Decimal
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import urllib.parse
from typing import Any, Optional
import boto3  # type: ignore
from boto3.dynamodb.conditions import Key  # type: ignore
from botocore.exceptions import ClientError  # type: ignore

DASHBOARD_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "dashboard"))
SAMPLE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "sample_docs"))
STACK_NAME = os.environ.get("STACK_NAME", "pii-safe-pipeline")
REGION = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))

MAX_BODY_SIZE = 10 * 1024 * 1024  # 10 MB
ALLOWED_HOSTNAMES = {"localhost", "127.0.0.1"}

# In-memory resource and items cache to eliminate latency
_CACHED_RESOURCES: Optional[dict[str, str]] = None
_CACHED_TIME: float = 0
_CACHED_ITEMS: list[Any] = []
_CACHED_ITEMS_TIME: float = 0


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return int(o) if o % 1 == 0 else float(o)
        return super().default(o)


def get_aws_resources(force=False):
    global _CACHED_RESOURCES, _CACHED_TIME
    if not force and _CACHED_RESOURCES and (time.time() - _CACHED_TIME < 300):
        return _CACHED_RESOURCES
    try:
        cf = boto3.client("cloudformation", region_name=REGION)
        res = cf.describe_stacks(StackName=STACK_NAME)
        outputs = {o["OutputKey"]: o["OutputValue"] for o in res["Stacks"][0].get("Outputs", [])}
        _CACHED_RESOURCES = outputs
        _CACHED_TIME = time.time()
        return outputs
    except Exception as e:
        print(f"[!] Warning: describe_stacks failed: {type(e).__name__}")
        return _CACHED_RESOURCES or {}


def count_status_items(table, status: str) -> int:
    """F12: Counts items per status using paginated GSI Query with Select='COUNT'."""
    try:
        count = 0
        kwargs = {
            "IndexName": "StatusIndex",
            "KeyConditionExpression": Key("status").eq(status),
            "Select": "COUNT",
        }
        while True:
            res = table.query(**kwargs)
            count += res.get("Count", 0)
            lek = res.get("LastEvaluatedKey")
            if not lek:
                break
            kwargs["ExclusiveStartKey"] = lek
        return count
    except Exception as e:
        # Fallback to scan if GSI is not available
        try:
            scan_kwargs = {
                "FilterExpression": Key("status").eq(status),
                "Select": "COUNT"
            }
            res = table.scan(**scan_kwargs)
            count = res.get("Count", 0)
            while "LastEvaluatedKey" in res:
                scan_kwargs["ExclusiveStartKey"] = res["LastEvaluatedKey"]
                res = table.scan(**scan_kwargs)
                count += res.get("Count", 0)
            return count
        except Exception:
            return 0


def fetch_table_items_by_gsi(table, status_filter: Optional[str] = None, limit: int = 50):
    """
    F12: Queries StatusIndex GSI with ScanIndexForward=False (newest first).
    If status_filter is provided (and != 'ALL'), queries that status with pagination up to limit.
    Otherwise queries each status ('PROCESSING', 'COMPLETED', 'FAILED'), merges the items,
    and sorts by upload_timestamp descending.
    """
    items = []
    statuses = [status_filter.upper()] if (status_filter and status_filter.upper() != "ALL") else ["PROCESSING", "COMPLETED", "FAILED"]
    
    try:
        for st in statuses:
            kwargs = {
                "IndexName": "StatusIndex",
                "KeyConditionExpression": Key("status").eq(st),
                "ScanIndexForward": False,
                "Limit": limit,
            }
            res = table.query(**kwargs)
            items.extend(res.get("Items", []))
            while len(items) < limit and "LastEvaluatedKey" in res:
                kwargs["ExclusiveStartKey"] = res["LastEvaluatedKey"]
                res = table.query(**kwargs)
                items.extend(res.get("Items", []))
        
        items.sort(key=lambda x: str(x.get("upload_timestamp", "")), reverse=True)
        return items[:limit] if (status_filter and status_filter.upper() != "ALL") else items
    except Exception as e:
        # Graceful fallback to scan if StatusIndex is missing
        try:
            scan_res = table.scan()
            all_items = scan_res.get("Items", [])
            while "LastEvaluatedKey" in scan_res:
                scan_res = table.scan(ExclusiveStartKey=scan_res["LastEvaluatedKey"])
                all_items.extend(scan_res.get("Items", []))
            if status_filter and status_filter.upper() != "ALL":
                all_items = [i for i in all_items if (i.get("status") or "").upper() == status_filter.upper()]
            all_items.sort(key=lambda x: str(x.get("upload_timestamp", "")), reverse=True)
            return all_items[:limit]
        except Exception as scan_err:
            print(f"[!] Warning: table scan fallback failed: {scan_err}")
            return []


def get_table_stats(table, resources=None, items=None) -> dict:
    """
    F12: Computes exact document statistics using paginated GSI Query with Select='COUNT'.
    """
    completed = count_status_items(table, "COMPLETED")
    failed = count_status_items(table, "FAILED")
    processing = count_status_items(table, "PROCESSING")
    total = completed + failed + processing

    total_pii = 0
    try:
        kwargs = {
            "IndexName": "StatusIndex",
            "KeyConditionExpression": Key("status").eq("COMPLETED"),
            "ProjectionExpression": "pii_count",
        }
        res = table.query(**kwargs)
        for i in res.get("Items", []):
            total_pii += int(i.get("pii_count", 0))
        while "LastEvaluatedKey" in res:
            kwargs["ExclusiveStartKey"] = res["LastEvaluatedKey"]
            res = table.query(**kwargs)
            for i in res.get("Items", []):
                total_pii += int(i.get("pii_count", 0))
    except Exception:
        if items:
            total_pii = sum(int(i.get("pii_count", 0)) for i in items if i.get("status") == "COMPLETED")

    dlq_count = get_dlq_message_count(resources) if resources else 0

    return {
        "total_documents": total,
        "completed": completed,
        "failed": failed,
        "processing": processing,
        "total_pii_redacted": total_pii,
        "dlq_message_count": dlq_count
    }


def fetch_table_items(force=False, status_filter: Optional[str] = None, limit: int = 50):
    global _CACHED_ITEMS, _CACHED_ITEMS_TIME
    if not force and not status_filter and _CACHED_ITEMS and (time.time() - _CACHED_ITEMS_TIME < 0.8):
        return _CACHED_ITEMS
    resources = get_aws_resources()
    table_name = resources.get("DocumentTrackingTableName")
    if not table_name:
        return []
    try:
        dynamodb: Any = boto3.resource("dynamodb", region_name=REGION)
        table = dynamodb.Table(table_name)
        items = fetch_table_items_by_gsi(table, status_filter=status_filter, limit=limit)
        if not status_filter:
            _CACHED_ITEMS = items
            _CACHED_ITEMS_TIME = time.time()
        return items
    except Exception as e:
        print(f"[!] Warning: table query failed: {type(e).__name__}")
        return _CACHED_ITEMS or []


def get_dlq_message_count(resources):
    dlq_url = resources.get("PipelineDeadLetterQueueUrl")
    if not dlq_url:
        return 0
    try:
        sqs = boto3.client("sqs", region_name=REGION)
        attr = sqs.get_queue_attributes(
            QueueUrl=dlq_url,
            AttributeNames=["ApproximateNumberOfMessages"]
        )
        return int(attr.get("Attributes", {}).get("ApproximateNumberOfMessages", 0))
    except Exception as sqs_err:
        print(f"[!] Warning: reading DLQ count failed: {type(sqs_err).__name__}")
        return 0


def invalidate_items_cache():
    global _CACHED_ITEMS_TIME
    _CACHED_ITEMS_TIME = 0


class PipelineDashboardHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DASHBOARD_DIR, **kwargs)

    def _validate_host_and_origin(self) -> bool:
        """Validate Host and Origin headers to prevent DNS rebinding and cross-origin attacks."""
        host = self.headers.get("Host", "")
        hostname = host.split(":")[0].lower()
        if hostname not in ALLOWED_HOSTNAMES:
            self.send_error(403, f"Forbidden: Host '{host}' is not permitted.")
            return False

        origin = self.headers.get("Origin")
        if origin:
            parsed = urllib.parse.urlparse(origin)
            origin_host = (parsed.hostname or "").lower()
            if origin_host not in ALLOWED_HOSTNAMES:
                self.send_error(403, f"Forbidden: Origin '{origin}' is not permitted.")
                return False
        return True

    def _send_json(self, status_code: int, data: dict):
        body = json.dumps(data, cls=DecimalEncoder).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))

        origin = self.headers.get("Origin")
        if origin:
            parsed = urllib.parse.urlparse(origin)
            if (parsed.hostname or "").lower() in ALLOWED_HOSTNAMES:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")

        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        if not self._validate_host_and_origin():
            return
        self.send_response(200)
        origin = self.headers.get("Origin")
        if origin:
            parsed = urllib.parse.urlparse(origin)
            if (parsed.hostname or "").lower() in ALLOWED_HOSTNAMES:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if not self._validate_host_and_origin():
            return

        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/stats":
            return self._handle_stats()
        elif path == "/documents":
            return self._handle_documents()
        elif path == "/document":
            query = urllib.parse.parse_qs(parsed.query)
            doc_id = query.get("id", [""])[0]
            return self._handle_document_detail(doc_id)
        elif path.startswith("/document/"):
            doc_id = urllib.parse.unquote(path[10:])
            return self._handle_document_detail(doc_id)
        elif path == "/sample-files":
            return self._handle_sample_files()

        # Serve static assets from dashboard/
        return super().do_GET()

    def do_POST(self):
        if not self._validate_host_and_origin():
            return

        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        # Check Content-Length to enforce body size cap
        content_len_header = self.headers.get("Content-Length")
        try:
            length = int(content_len_header or 0)
        except ValueError:
            return self._send_json(400, {"error": "Invalid Content-Length header."})

        if length > MAX_BODY_SIZE:
            return self._send_json(413, {"error": f"Payload too large. Limit is {MAX_BODY_SIZE} bytes."})

        if path == "/upload-direct":
            try:
                raw_bytes = self.rfile.read(length)
                raw_str = raw_bytes.decode("utf-8") if raw_bytes else "{}"
                body = json.loads(raw_str)
            except Exception:
                return self._send_json(400, {"error": "Malformed JSON in request body."})
            return self._handle_upload_direct(body)

        elif path == "/upload-sample":
            query = urllib.parse.parse_qs(parsed.query)
            file_name = query.get("file", [""])[0]
            mask_types = query.get("masks", [""])[0]
            custom_keywords = query.get("keywords", [""])[0]
            mask_mode = query.get("mode", ["LABEL"])[0]
            return self._handle_upload_sample(file_name, mask_types, custom_keywords, mask_mode)

        self.send_error(404, "Unknown endpoint")

    def _handle_sample_files(self):
        files = []
        if os.path.exists(SAMPLE_DIR):
            for f in sorted(os.listdir(SAMPLE_DIR)):
                if os.path.isfile(os.path.join(SAMPLE_DIR, f)):
                    files.append(f)
        return self._send_json(200, {"files": files})

    def _handle_stats(self):
        try:
            resources = get_aws_resources()
            table_name = resources.get("DocumentTrackingTableName")
            if not table_name:
                return self._send_json(200, {
                    "total_documents": 0,
                    "completed": 0,
                    "failed": 0,
                    "processing": 0,
                    "total_pii_redacted": 0,
                    "dlq_message_count": 0
                })
            dynamodb: Any = boto3.resource("dynamodb", region_name=REGION)
            table = dynamodb.Table(table_name)
            stats = get_table_stats(table, resources)
            return self._send_json(200, stats)
        except Exception as e:
            return self._send_json(500, {"error": "Internal server error."})

    def _handle_documents(self):
        try:
            parsed = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            status_filter = query.get("status", [None])[0]
            try:
                limit_param = int(query.get("limit", [50])[0])
            except (ValueError, TypeError):
                limit_param = 50

            resources = get_aws_resources()
            table_name = resources.get("DocumentTrackingTableName")
            if not table_name:
                return self._send_json(200, {
                    "documents": [],
                    "stats": {
                        "total_documents": 0,
                        "completed": 0,
                        "failed": 0,
                        "processing": 0,
                        "total_pii_redacted": 0,
                        "dlq_message_count": 0
                    }
                })

            dynamodb: Any = boto3.resource("dynamodb", region_name=REGION)
            table = dynamodb.Table(table_name)
            items = fetch_table_items(force=False, status_filter=status_filter, limit=limit_param)
            stats = get_table_stats(table, resources, items=items)

            return self._send_json(200, {
                "documents": items,
                "stats": stats
            })
        except Exception as e:
            return self._send_json(500, {"error": "Internal server error."})

    def _handle_document_detail(self, doc_id: str):
        resources = get_aws_resources()
        table_name = resources.get("DocumentTrackingTableName")
        if not table_name:
            return self._send_json(404, {"error": "DynamoDB table not configured"})

        # Sanitize document ID
        clean_id = os.path.basename(doc_id.strip())
        if clean_id != doc_id or ".." in doc_id or "/" in doc_id or "\\" in doc_id:
            return self._send_json(400, {"error": "Invalid document ID format."})

        try:
            dynamodb: Any = boto3.resource("dynamodb", region_name=REGION)
            s3 = boto3.client("s3", region_name=REGION)
            table = dynamodb.Table(table_name)
            item = table.get_item(Key={"document_id": clean_id}).get("Item")
            if not item:
                return self._send_json(404, {"error": f"Document {clean_id} not found in DynamoDB"})

            redacted_text = ""
            p_bucket = item.get("processed_bucket") or resources.get("ProcessedBucketName")
            p_key = item.get("processed_key")

            if p_bucket and p_key and ".." not in p_key:
                try:
                    obj = s3.get_object(Bucket=p_bucket, Key=p_key)
                    redacted_text = obj["Body"].read().decode("utf-8")
                except Exception as s3_err:
                    redacted_text = f"Notice: Redacted text could not be read from S3."
            elif item.get("status") == "FAILED":
                redacted_text = (
                    f"Pipeline Execution Failed at step [{item.get('error_step', 'VALIDATION')}]:\n\n"
                    f"{item.get('failure_reason', 'No detailed failure message recorded.')}"
                )
            elif item.get("status") == "PROCESSING":
                redacted_text = "Document is currently processing in AWS Lambda. Please wait a moment..."
            else:
                redacted_text = "No redacted output available for this document."

            return self._send_json(200, {
                "document": item,
                "redacted_text": redacted_text
            })
        except Exception as e:
            return self._send_json(500, {"error": "Internal server error."})

    def _handle_upload_direct(self, body: dict):
        resources = get_aws_resources()
        raw_bucket = resources.get("RawBucketName")
        if not raw_bucket:
            return self._send_json(500, {"error": "RawBucketName not resolved from CloudFormation stack."})

        file_name = body.get("file_name", "sample_id_card.png")
        data_base64 = body.get("data_base64", "")
        custom_keywords = body.get("custom_keywords", "")

        # Directory traversal prevention
        clean_name = os.path.basename(file_name)
        if not clean_name or clean_name != file_name or "/" in file_name or "\\" in file_name or ".." in file_name:
            return self._send_json(400, {"error": "Invalid file name: directory traversal is prohibited."})

        if not data_base64 or not isinstance(data_base64, str):
            return self._send_json(400, {"error": "Missing or invalid file data"})

        try:
            file_bytes = base64.b64decode(data_base64, validate=True)
        except Exception:
            return self._send_json(400, {"error": "Invalid base64 payload."})

        content_type = "application/octet-stream"
        lower_name = clean_name.lower()
        if lower_name.endswith(".png"): content_type = "image/png"
        elif lower_name.endswith((".jpg", ".jpeg")): content_type = "image/jpeg"
        elif lower_name.endswith(".pdf"): content_type = "application/pdf"
        elif lower_name.endswith(".txt"): content_type = "text/plain"

        metadata = {}
        if custom_keywords:
            metadata["custom-keywords"] = str(custom_keywords)

        s3 = boto3.client("s3", region_name=REGION)
        put_res = s3.put_object(
            Bucket=raw_bucket,
            Key=clean_name,
            Body=file_bytes,
            ContentType=content_type,
            Metadata=metadata
        )
        invalidate_items_cache()

        # Compute deterministic document_id for client tracking
        etag = (put_res.get("ETag") or "").strip('"')
        seq = put_res.get("ResponseMetadata", {}).get("HTTPHeaders", {}).get("x-amz-version-id") or etag
        doc_id = hashlib.sha256(f"{raw_bucket}/{clean_name}/{seq}".encode()).hexdigest()[:24]

        return self._send_json(200, {
            "status": "SUCCESS",
            "document_id": doc_id,
            "file_name": clean_name,
            "bucket": raw_bucket,
            "size_bytes": len(file_bytes),
            "upload_timestamp": time.time()
        })

    def _handle_upload_sample(self, file_name: str, mask_types: str = "", custom_keywords: str = "", mask_mode: str = "LABEL"):
        resources = get_aws_resources()
        raw_bucket = resources.get("RawBucketName")
        if not raw_bucket:
            return self._send_json(500, {"error": "RawBucketName not resolved."})

        # Require os.path.basename and membership in os.listdir(SAMPLE_DIR)
        clean_name = os.path.basename(file_name)
        valid_samples = set(os.listdir(SAMPLE_DIR)) if os.path.exists(SAMPLE_DIR) else set()
        if not clean_name or clean_name != file_name or clean_name not in valid_samples:
            return self._send_json(400, {"error": f"Invalid sample file '{file_name}'. Must be a valid file in sample_docs."})

        file_path = os.path.join(SAMPLE_DIR, clean_name)
        if not os.path.exists(file_path):
            return self._send_json(404, {"error": f"Sample file {clean_name} does not exist."})

        content_type = "application/octet-stream"
        lower_name = clean_name.lower()
        if lower_name.endswith(".png"): content_type = "image/png"
        elif lower_name.endswith((".jpg", ".jpeg")): content_type = "image/jpeg"
        elif lower_name.endswith(".pdf"): content_type = "application/pdf"
        elif lower_name.endswith(".txt"): content_type = "text/plain"

        metadata = {}
        if custom_keywords:
            metadata["custom-keywords"] = custom_keywords

        s3 = boto3.client("s3", region_name=REGION)
        with open(file_path, "rb") as f:
            file_data = f.read()

        put_res = s3.put_object(
            Bucket=raw_bucket,
            Key=clean_name,
            Body=file_data,
            ContentType=content_type,
            Metadata=metadata
        )
        invalidate_items_cache()

        # Compute deterministic document_id for client tracking
        etag = (put_res.get("ETag") or "").strip('"')
        seq = put_res.get("ResponseMetadata", {}).get("HTTPHeaders", {}).get("x-amz-version-id") or etag
        doc_id = hashlib.sha256(f"{raw_bucket}/{clean_name}/{seq}".encode()).hexdigest()[:24]

        return self._send_json(200, {
            "status": "SUCCESS",
            "document_id": doc_id,
            "file_name": clean_name,
            "bucket": raw_bucket
        })


def run(port=8000):
    global STACK_NAME, REGION
    server_address = ("127.0.0.1", port)
    httpd = ThreadingHTTPServer(server_address, PipelineDashboardHandler)
    print(f"\n==================================================================")
    print(f"  Hardened PII Document Redaction Server running at:")
    print(f"  --> http://localhost:{port}")
    print(f"  Stack: {STACK_NAME} | Region: {REGION}")
    print(f"==================================================================\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping dashboard server...")
        httpd.server_close()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    if len(sys.argv) > 2:
        STACK_NAME = sys.argv[2]
    if len(sys.argv) > 3:
        REGION = sys.argv[3]
    run(port)
