import os
import sys
import time
import json
import argparse
from typing import Optional
from datetime import datetime, timezone
import boto3
from botocore.exceptions import ClientError

def get_stack_outputs(stack_name="pii-safe-pipeline", region="us-east-1"):
    """Fetches CloudFormation stack outputs to automatically discover bucket and table names."""
    cf = boto3.client("cloudformation", region_name=region)
    try:
        res = cf.describe_stacks(StackName=stack_name)
        outputs = res["Stacks"][0].get("Outputs", [])
        output_map = {o["OutputKey"]: o["OutputValue"] for o in outputs}
        return output_map
    except ClientError as e:
        print(f"[!] Warning: Could not fetch CloudFormation outputs for '{stack_name}': {e}")
        return {}

def upload_document(s3_client, bucket: str, file_path: str):
    file_name = os.path.basename(file_path)
    upload_time_iso = datetime.now(timezone.utc).isoformat()
    print(f"\n[*] Uploading '{file_name}' to s3://{bucket}/{file_name}...")
    content_type = "application/octet-stream"
    if file_path.lower().endswith(".png"):
        content_type = "image/png"
    elif file_path.lower().endswith((".jpg", ".jpeg")):
        content_type = "image/jpeg"
    elif file_path.lower().endswith(".pdf"):
        content_type = "application/pdf"
    elif file_path.lower().endswith(".txt"):
        content_type = "text/plain"

    with open(file_path, "rb") as f:
        s3_client.put_object(
            Bucket=bucket,
            Key=file_name,
            Body=f,
            ContentType=content_type
        )
    print(f"[+] Successfully uploaded '{file_name}'! Pipeline triggered via S3 event.")
    return file_name, upload_time_iso

def monitor_dynamodb(dynamodb_resource, table_name: str, file_name: str, uploaded_after_iso: Optional[str] = None, timeout_seconds=45):
    """
    Polls DynamoDB until the record created for this file reaches COMPLETED or FAILED.
    """
    table = dynamodb_resource.Table(table_name)
    print(f"[*] Monitoring DynamoDB table '{table_name}' for file '{file_name}'...")
    start_time = time.time()

    matched_doc_id = None

    while time.time() - start_time < timeout_seconds:
        # Scan for records matching this file_name
        response = table.scan()
        items = response.get("Items", [])
        candidates = [i for i in items if i.get("file_name") == file_name]

        if uploaded_after_iso:
            # Filter to candidates uploaded at or after the upload start time (tolerance of 5 seconds)
            candidates = [i for i in candidates if i.get("upload_timestamp", "") >= uploaded_after_iso[:19]]

        if candidates:
            # Sort by upload_timestamp descending to get the newest
            candidates.sort(key=lambda x: str(x.get("upload_timestamp", "")), reverse=True)
            record = candidates[0]
            matched_doc_id = record.get("document_id")
            status = record.get("status")

            elapsed = int(time.time() - start_time)
            print(f"    [{elapsed}s] Document ID: {matched_doc_id} | Status: {status}")

            if status in ("COMPLETED", "FAILED"):
                return record

        time.sleep(2)

    print(f"[!] Timeout reached ({timeout_seconds}s) while monitoring DynamoDB.")
    return None

def display_summary(s3_client, record: Optional[dict]):
    if not record:
        print("[!] No record to display.")
        return

    print("\n" + "=" * 70)
    print("                     PIPELINE EXECUTION SUMMARY")
    print("=" * 70)
    print(f"Document ID:          {record.get('document_id')}")
    print(f"File Name:            {record.get('file_name')}")
    print(f"Status:               {record.get('status')}")
    print(f"File Type:            {record.get('file_type')}")
    print(f"File Size:            {record.get('file_size_bytes')} bytes")
    print(f"Upload Timestamp:     {record.get('upload_timestamp')}")

    status = record.get("status")
    if status == "FAILED":
        print(f"Failure Step:         {record.get('error_step')}")
        print(f"Failure Reason:       {record.get('failure_reason')}")
        print("=" * 70)
        return

    print(f"Execution Duration:   {record.get('execution_duration_ms')} ms")
    print(f"Total PII Redacted:   {record.get('pii_count')}")
    print(f"PII Types Breakdown:  {json.dumps(record.get('pii_types_found', {}), indent=2, default=str)}")
    print(f"Processed S3 Bucket:  {record.get('processed_bucket')}")
    print(f"Processed Text Key:   {record.get('processed_key')}")
    print("=" * 70)

    # Fetch and print the redacted text content
    p_bucket = record.get("processed_bucket")
    p_key = record.get("processed_key")
    if p_bucket and p_key:
        try:
            obj = s3_client.get_object(Bucket=p_bucket, Key=p_key)
            redacted_content = obj["Body"].read().decode("utf-8")
            print("\n--- SAFELY REDACTED DOCUMENT TEXT (FROM PROCESSED S3) ---")
            print(redacted_content)
            print("---------------------------------------------------------")
        except Exception as e:
            print(f"[!] Could not download redacted text: {e}")

def main():
    parser = argparse.ArgumentParser(description="Upload documents to AWS PII pipeline and monitor status.")
    parser.add_argument("--file", "-f", help="Path to document to upload (defaults to sample_id_card.png)")
    parser.add_argument("--all", action="store_true", help="Upload all 5 sample test documents sequentially")
    parser.add_argument("--stack", default="pii-safe-pipeline", help="CloudFormation stack name")
    parser.add_argument("--raw-bucket", help="Explicit raw bucket name (overrides stack lookup)")
    parser.add_argument("--processed-bucket", help="Explicit processed bucket name")
    parser.add_argument("--table", help="Explicit DynamoDB table name")
    parser.add_argument("--region", default="us-east-1", help="AWS Region (default: us-east-1)")
    args = parser.parse_args()

    s3 = boto3.client("s3", region_name=args.region)
    dynamodb = boto3.resource("dynamodb", region_name=args.region)

    outputs = get_stack_outputs(args.stack, args.region)
    raw_bucket = args.raw_bucket or outputs.get("RawBucketName")
    table_name = args.table or outputs.get("DocumentTrackingTableName")

    if not raw_bucket or not table_name:
        print("[!] Error: Raw Bucket or DynamoDB Table name could not be resolved.")
        print("    Ensure the stack is deployed, or specify --raw-bucket and --table directly.")
        sys.exit(1)

    sample_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "sample_docs"))
    
    if args.all:
        files = [
            os.path.join(sample_dir, "sample_id_card.png"),
            os.path.join(sample_dir, "sample_medical_intake.jpg"),
            os.path.join(sample_dir, "sample_application.pdf"),
            os.path.join(sample_dir, "blank_document.png"),
            os.path.join(sample_dir, "unsupported_document.txt"),
        ]
        for f in files:
            if os.path.exists(f):
                fname, up_time = upload_document(s3, raw_bucket, f)
                rec = monitor_dynamodb(dynamodb, table_name, fname, uploaded_after_iso=up_time)
                display_summary(s3, rec)
    else:
        target_file = args.file or os.path.join(sample_dir, "sample_id_card.png")
        if not os.path.exists(target_file):
            print(f"[!] File not found: {target_file}")
            sys.exit(1)
        fname, up_time = upload_document(s3, raw_bucket, target_file)
        rec = monitor_dynamodb(dynamodb, table_name, fname, uploaded_after_iso=up_time)
        display_summary(s3, rec)

if __name__ == "__main__":
    main()
