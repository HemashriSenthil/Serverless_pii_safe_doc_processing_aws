import os
from PIL import Image, ImageDraw, ImageFont  # type: ignore

OUTPUT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "sample_docs"))
os.makedirs(OUTPUT_DIR, exist_ok=True)

def get_font(size=20):
    try:
        # Standard Windows fonts
        return ImageFont.truetype("arial.ttf", size)
    except Exception:
        return ImageFont.load_default()

def get_bold_font(size=24):
    try:
        return ImageFont.truetype("arialbd.ttf", size)
    except Exception:
        return ImageFont.load_default()

def create_id_card():
    """
    Creates sample_id_card.png (Driver's License / State ID card style)
    """
    width, height = 800, 500
    img = Image.new("RGB", (width, height), color=(248, 249, 250))
    draw = ImageDraw.Draw(img)
    font_bold = get_bold_font(26)
    font_sub = get_bold_font(18)
    font_body = get_font(20)

    # Header banner
    draw.rectangle([(0, 0), (width, 80)], fill=(24, 76, 120))
    draw.text((30, 25), "STATE DRIVER LICENSE / IDENTIFICATION", fill=(255, 255, 255), font=font_bold)

    # Mock Photo box
    draw.rectangle([(40, 110), (220, 350)], fill=(220, 226, 230), outline=(100, 110, 120), width=2)
    draw.text((80, 220), "[ PHOTO ]", fill=(100, 110, 120), font=font_sub)

    # PII Fields
    fields = [
        ("LICENSE NO:", "DL-98432109-X"),
        ("FULL NAME:", "Jane Elizabeth Doe"),
        ("DATE OF BIRTH:", "05/14/1988"),
        ("ADDRESS:", "742 Evergreen Terrace"),
        ("CITY, STATE, ZIP:", "Springfield, OR 97477"),
        ("PHONE:", "+1 (555) 867-5309"),
        ("EMAIL:", "jane.doe@example.com"),
        ("SSN:", "555-01-9988"),
        ("EXPIRATION:", "05/14/2028")
    ]

    x_start = 260
    y_start = 100
    line_spacing = 35

    for i, (label, value) in enumerate(fields):
        y = y_start + (i * line_spacing)
        draw.text((x_start, y), label, fill=(80, 80, 80), font=font_sub)
        draw.text((x_start + 200, y), value, fill=(20, 20, 20), font=font_body)

    out_path = os.path.join(OUTPUT_DIR, "sample_id_card.png")
    img.save(out_path, "PNG")
    print(f"Generated: {out_path}")

def create_medical_form():
    """
    Creates sample_medical_intake.jpg (Patient intake form)
    """
    width, height = 850, 1100
    img = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    font_title = get_bold_font(28)
    font_section = get_bold_font(20)
    font_body = get_font(18)
    font_label = get_bold_font(18)

    # Header
    draw.rectangle([(40, 40), (810, 110)], fill=(230, 240, 250))
    draw.text((60, 60), "METROPOLITAN HEALTH CLINIC - PATIENT INTAKE FORM", fill=(10, 40, 80), font=font_title)

    sections = [
        ("SECTION 1: PATIENT DEMOGRAPHICS", [
            ("Patient Name:", "Robert Michael Smith"),
            ("Date of Birth:", "11/22/1979"),
            ("Home Address:", "1042 Maplewood Avenue, Apt 4B"),
            ("City, State, Zip:", "Seattle, WA 98101"),
            ("Contact Phone:", "(206) 555-0199"),
            ("Email Address:", "robert.smith@healthmail.org"),
            ("Emergency Contact:", "Sarah Smith - Spouse (206) 555-0144"),
            ("Social Security Number:", "555-01-4432")
        ]),
        ("SECTION 2: INSURANCE & BILLING DETAILS", [
            ("Insurance Provider:", "Blue Cross Horizon"),
            ("Policy Number:", "BCH-88371902"),
            ("Group Number:", "GRP-40291")
        ]),
        ("SECTION 3: MEDICAL HISTORY SUMMARY", [
            ("Primary Physician:", "Dr. Amanda Vance, MD"),
            ("Known Allergies:", "Penicillin, Peanuts"),
            ("Current Medications:", "Lisinopril 10mg, Metformin 500mg")
        ])
    ]

    current_y = 135
    for section_title, rows in sections:
        draw.rectangle([(40, current_y), (810, current_y + 32)], fill=(240, 244, 248))
        draw.text((50, current_y + 6), section_title, fill=(30, 60, 90), font=font_section)
        current_y += 44

        for label, val in rows:
            draw.text((60, current_y), label, fill=(70, 70, 70), font=font_label)
            draw.text((320, current_y), val, fill=(15, 15, 15), font=font_body)
            # Underline
            draw.line([(315, current_y + 22), (790, current_y + 22)], fill=(200, 200, 200), width=1)
            current_y += 33
        current_y += 15

    out_path = os.path.join(OUTPUT_DIR, "sample_medical_intake.jpg")
    img.save(out_path, "JPEG", quality=95)
    print(f"Generated: {out_path}")

def create_application_pdf():
    """
    Creates sample_application.pdf (Single-page PDF Loan/Rental Application)
    """
    width, height = 850, 1100
    img = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    font_title = get_bold_font(28)
    font_section = get_bold_font(20)
    font_body = get_font(18)
    font_label = get_bold_font(18)

    # Header
    draw.rectangle([(40, 40), (810, 110)], fill=(34, 139, 34))
    draw.text((60, 60), "CONFIDENTIAL FINANCIAL CREDIT APPLICATION", fill=(255, 255, 255), font=font_title)

    fields = [
        ("Applicant Full Name:", "David Alexander Miller"),
        ("National ID:", "DL-94821034-X"),
        ("Social Security Number:", "555-01-7890"),
        ("Date of Birth:", "03/19/1992"),
        ("Residential Address:", "550 Market Street, Suite 1200"),
        ("City, State, Zip Code:", "San Francisco, CA 94104"),
        ("Primary Mobile Phone:", "(415) 555-7821"),
        ("Personal Email Address:", "david.miller@financestart.io"),
        ("Employer Name:", "Apex Cloud Technologies Inc"),
        ("Annual Income:", "$145,000 USD"),
        ("Bank Account Number:", "8823901452"),
        ("Routing Number:", "121000358")
    ]

    current_y = 150
    draw.text((50, current_y), "PRIMARY APPLICANT DETAILS", fill=(30, 30, 30), font=font_section)
    current_y += 45

    for label, val in fields:
        draw.text((60, current_y), label, fill=(80, 80, 80), font=font_label)
        draw.text((340, current_y), val, fill=(10, 10, 10), font=font_body)
        draw.line([(335, current_y + 22), (790, current_y + 22)], fill=(210, 210, 210), width=1)
        current_y += 42

    # Disclaimer footer
    draw.text(
        (60, 950),
        "Notice: This document contains Personally Identifiable Information (PII) protected under privacy regulations.",
        fill=(120, 120, 120),
        font=get_font(13)
    )

    out_path = os.path.join(OUTPUT_DIR, "sample_application.pdf")
    img.save(out_path, "PDF", resolution=100.0)
    print(f"Generated: {out_path}")

def create_scholarship_application_pdf():
    """
    Creates sample_scholarship_application.pdf (Scholarship & Admissions Application Form)
    """
    width, height = 850, 1100
    img = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    font_title = get_bold_font(26)
    font_section = get_bold_font(18)
    font_body = get_font(16)
    font_label = get_bold_font(16)

    # Header
    draw.rectangle([(40, 30), (810, 95)], fill=(20, 60, 110))
    draw.text((60, 48), "SCHOLARSHIP & ADMISSIONS APPLICATION FORM", fill=(255, 255, 255), font=font_title)

    # Section 1: Candidate Personal Details (To Be Masked)
    draw.rectangle([(40, 110), (810, 140)], fill=(240, 244, 248))
    draw.text((50, 116), "SECTION 1: APPLICANT IDENTITY (BLIND SCREENING TARGETS)", fill=(30, 60, 90), font=font_section)

    p_fields = [
        ("Applicant Name:", "Alex M. Sample"),
        ("Date of Birth:", "01/01/2000"),
        ("Email Address:", "alex.sample@example.com"),
        ("Contact Phone:", "+1-555-019-2834"),
        ("Father / Guardian Name:", "Jordan Sample"),
        ("Home Address:", "100 Innovation Way, Suite 400, Austin, TX 78701"),
        ("Application Number:", "APP-2024-00001"),
        ("Bank Account Number:", "000123456789")
    ]
    cur_y = 150
    for lbl, val in p_fields:
        draw.text((60, cur_y), lbl, fill=(80, 80, 80), font=font_label)
        draw.text((320, cur_y), val, fill=(10, 10, 10), font=font_body)
        draw.line([(315, cur_y + 20), (790, cur_y + 20)], fill=(220, 220, 220), width=1)
        cur_y += 32

    # Section 2: Academic Merit & Financial Need (To Keep Visible)
    cur_y += 10
    draw.rectangle([(40, cur_y), (810, cur_y + 30)], fill=(235, 248, 235))
    draw.text((50, cur_y + 6), "SECTION 2: ACADEMIC MERIT & NEED (REVIEWER EVALUATION DATA)", fill=(20, 90, 40), font=font_section)
    cur_y += 40

    m_fields = [
        ("Course & Degree:", "B.E. Computer Science and Engineering"),
        ("Year of Study:", "2nd Year (2023-2027)"),
        ("Current Cumulative CGPA:", "8.92 / 10.00"),
        ("Class 12 Board Percentage:", "95.4%"),
        ("Score in Mathematics:", "98/100"),
        ("Annual Family Income:", "Rs. 1,20,000 per annum"),
        ("Tuition Fee Needed:", "Rs. 75,000")
    ]
    for lbl, val in m_fields:
        draw.text((60, cur_y), lbl, fill=(40, 40, 40), font=font_label)
        draw.text((340, cur_y), val, fill=(10, 80, 20), font=font_body)
        draw.line([(335, cur_y + 20), (790, cur_y + 20)], fill=(210, 230, 210), width=1)
        cur_y += 32

    # Section 3: Essay / Statement of Purpose
    cur_y += 10
    draw.rectangle([(40, cur_y), (810, cur_y + 30)], fill=(245, 245, 250))
    draw.text((50, cur_y + 6), "SECTION 3: STATEMENT OF PURPOSE / NEED ESSAY", fill=(50, 50, 90), font=font_section)
    cur_y += 40

    essay_lines = [
        "I am a dedicated first-generation college student passionate about artificial intelligence.",
        "My family's annual income is insufficient to cover the current engineering tuition fees.",
        "Receiving this merit-cum-need scholarship will enable me to successfully complete my degree",
        "and contribute to impactful research in modern computer systems."
    ]
    for line in essay_lines:
        draw.text((60, cur_y), line, fill=(30, 30, 30), font=font_body)
        cur_y += 26

    out_path = os.path.join(OUTPUT_DIR, "sample_scholarship_application.pdf")
    img.save(out_path, "PDF", resolution=100.0)
    print(f"Generated: {out_path}")

def create_income_certificate():
    """
    Creates sample_income_certificate.png (Revenue Department Income Certificate & Fee Document)
    """
    width, height = 850, 750
    img = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    font_title = get_bold_font(24)
    font_sub = get_bold_font(18)
    font_body = get_font(18)
    font_label = get_bold_font(17)

    # Header
    draw.rectangle([(40, 30), (810, 95)], fill=(120, 60, 20))
    draw.text((90, 40), "REVENUE DEPARTMENT - GOVERNMENT OF TAMIL NADU", fill=(255, 255, 255), font=font_title)
    draw.text((280, 68), "TALUK OFFICE, ATTUR - INCOME CERTIFICATE", fill=(255, 230, 200), font=font_sub)

    lines = [
        ("Certificate No:", "INC-2024-00123", "Date of Birth:", "01/01/2000"),
        ("Applicant Name:", "Pat Q. Test", "Father Name:", "Morgan Test"),
        ("Residential Address:", "456 Mockingbird Lane, Test City, NY 10001", "", ""),
        ("Annual Family Income:", "$25,000 USD per annum", "(Verified Need)", "Eligible"),
        ("College Fee Structure:", "Tuition Fee $15,000, Exam Fee $500", "", ""),
        ("Bank Account Number:", "000987654321", "Routing Number:", "121000358"),
        ("Authorized Signatory:", "Official Registrar", "Designation:", "Certifying Officer")
    ]
    cur_y = 120
    for row in lines:
        draw.text((60, cur_y), row[0], fill=(70, 70, 70), font=font_label)
        draw.text((260, cur_y), row[1], fill=(20, 20, 20), font=font_body)
        if row[2]:
            draw.text((540, cur_y), row[2], fill=(70, 70, 70), font=font_label)
            draw.text((680, cur_y), row[3], fill=(20, 20, 20), font=font_body)
        draw.line([(55, cur_y + 26), (795, cur_y + 26)], fill=(225, 225, 225), width=1)
        cur_y += 50

    # Stamp box
    draw.rectangle([(550, 520), (780, 650)], outline=(120, 60, 20), width=2)
    draw.text((580, 560), "[ OFFICIAL SEAL ]\nCertifying Officer", fill=(120, 60, 20), font=font_sub)

    out_path = os.path.join(OUTPUT_DIR, "sample_income_certificate.png")
    img.save(out_path, "PNG")
    print(f"Generated: {out_path}")

def create_academic_marksheet_pdf():
    """
    Creates sample_academic_marksheet.pdf (College Marksheet / Transcript)
    """
    width, height = 850, 1100
    img = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    font_title = get_bold_font(26)
    font_section = get_bold_font(18)
    font_body = get_font(16)
    font_label = get_bold_font(16)

    # Header
    draw.rectangle([(40, 30), (810, 95)], fill=(30, 70, 100))
    draw.text((120, 40), "ANNA UNIVERSITY / TECHNICAL EXAMINATIONS", fill=(255, 255, 255), font=font_title)
    draw.text((220, 68), "CONSOLIDATED SEMESTER GRADE REPORT", fill=(200, 230, 255), font=font_section)

    # Student header (PII to mask)
    draw.rectangle([(40, 110), (810, 140)], fill=(240, 244, 248))
    draw.text((50, 116), "STUDENT INFORMATION (BLIND REVIEW MASKING)", fill=(30, 60, 90), font=font_section)

    cur_y = 150
    st_info = [
        ("Candidate Name:", "Sam K. Student", "Register Number:", "REG-2024-9999"),
        ("Date of Birth:", "01/01/2000", "Degree / Branch:", "B.S. Computer Science"),
        ("Semester:", "Semester IV", "Month & Year:", "MAY 2024")
    ]
    for row in st_info:
        draw.text((60, cur_y), row[0], fill=(70, 70, 70), font=font_label)
        draw.text((220, cur_y), row[1], fill=(15, 15, 15), font=font_body)
        draw.text((480, cur_y), row[2], fill=(70, 70, 70), font=font_label)
        draw.text((640, cur_y), row[3], fill=(15, 15, 15), font=font_body)
        cur_y += 32

    # Table Header (Merit to keep visible)
    cur_y += 20
    draw.rectangle([(40, cur_y), (810, cur_y + 35)], fill=(230, 240, 250))
    draw.text((50, cur_y + 8), "CODE", fill=(20, 50, 80), font=font_label)
    draw.text((150, cur_y + 8), "COURSE TITLE", fill=(20, 50, 80), font=font_label)
    draw.text((520, cur_y + 8), "CREDITS", fill=(20, 50, 80), font=font_label)
    draw.text((610, cur_y + 8), "GRADE", fill=(20, 50, 80), font=font_label)
    draw.text((690, cur_y + 8), "MARKS", fill=(20, 50, 80), font=font_label)
    draw.text((750, cur_y + 8), "RESULT", fill=(20, 50, 80), font=font_label)
    cur_y += 40

    courses = [
        ("CS8451", "Design and Analysis of Algorithms", "4", "A+", "92/100", "PASS"),
        ("CS8491", "Computer Architecture", "3", "O", "98/100", "PASS"),
        ("CS8492", "Database Management Systems", "4", "A+", "90/100", "PASS"),
        ("CS8493", "Operating Systems", "3", "O", "96/100", "PASS"),
        ("CS8494", "Software Engineering", "3", "A+", "91/100", "PASS"),
        ("MA8402", "Probability and Queuing Theory", "4", "A", "85/100", "PASS")
    ]
    for code, title, cred, grade, marks, res in courses:
        draw.text((50, cur_y), code, fill=(30, 30, 30), font=font_body)
        draw.text((150, cur_y), title, fill=(30, 30, 30), font=font_body)
        draw.text((540, cur_y), cred, fill=(30, 30, 30), font=font_body)
        draw.text((620, cur_y), grade, fill=(10, 100, 20), font=font_label)
        draw.text((690, cur_y), marks, fill=(10, 10, 10), font=font_body)
        draw.text((750, cur_y), res, fill=(10, 100, 20), font=font_label)
        draw.line([(40, cur_y + 24), (810, cur_y + 24)], fill=(230, 230, 230), width=1)
        cur_y += 34

    # Summary
    cur_y += 20
    draw.rectangle([(40, cur_y), (810, cur_y + 40)], fill=(245, 250, 245))
    draw.text((60, cur_y + 10), "Semester GPA: 9.24 / 10.00", fill=(10, 90, 20), font=font_label)
    draw.text((340, cur_y + 10), "Cumulative CGPA: 9.12 / 10.00", fill=(10, 90, 20), font=font_label)
    draw.text((640, cur_y + 10), "Class Rank: 2", fill=(10, 90, 20), font=font_label)

    out_path = os.path.join(OUTPUT_DIR, "sample_academic_marksheet.pdf")
    img.save(out_path, "PDF", resolution=100.0)
    print(f"Generated: {out_path}")

def create_unsupported_file():
    """
    Creates unsupported_document.txt to test Step 4 Validation Failure
    """
    out_path = os.path.join(OUTPUT_DIR, "unsupported_document.txt")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("This is a plain text file (.txt). The pipeline must reject this during Step 4 validation.\n")
    print(f"Generated: {out_path}")

def create_blank_image():
    """
    Creates blank_document.png to test Step 5 'No text found' failure
    """
    img = Image.new("RGB", (600, 400), color=(255, 255, 255))
    out_path = os.path.join(OUTPUT_DIR, "blank_document.png")
    img.save(out_path, "PNG")
    print(f"Generated: {out_path}")

if __name__ == "__main__":
    print("Generating comprehensive sample test documents for Blind Screening...")
    create_id_card()
    create_medical_form()
    create_application_pdf()
    create_scholarship_application_pdf()
    create_income_certificate()
    create_academic_marksheet_pdf()
    create_unsupported_file()
    create_blank_image()
    print("All sample documents successfully generated!")
