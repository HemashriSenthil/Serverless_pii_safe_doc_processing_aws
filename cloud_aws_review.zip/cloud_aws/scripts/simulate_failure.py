import os
import sys
import time
import json
import hashlib
import argparse
import boto3
from typing import Optional
from botocore.exceptions import ClientError


def get_stack_resources(stack_name="pii-safe-pipeline", region="us-east-1"):
    cf = boto3.client("cloudformation", region_name=region)
    try:
        res = cf.describe_stacks(StackName=stack_name)
        outputs = {o["OutputKey"]: o["OutputValue"] for o in res["Stacks"][0].get("Outputs", [])}
        return outputs
    except ClientError as e:
        print(f"[!] Warning: Could not describe stack '{stack_name}': {e}")
        return {}


def test_unhandled_failure_and_dlq(
    lambda_client,
    sqs_client,
    cw_client,
    sns_client,
    dynamodb_resource,
    function_arn: str,
    dlq_url: str,
    alarm_name: str,
    topic_arn: Optional[str] = None,
    table_name: Optional[str] = None
) -> bool:
    print("\n" + "=" * 75)
    print("      STEP 10 VERIFICATION: UNHANDLED FAILURE, RETRIES & DLQ/SNS")
    print("=" * 75)
    print(f"Target Lambda ARN:       {function_arn}")
    print(f"Dead-Letter Queue URL:   {dlq_url}")
    print(f"CloudWatch Alarm:       {alarm_name}")
    print(f"SNS Topic ARN:           {topic_arn or 'N/A'}")
    print(f"DynamoDB Table:          {table_name or 'N/A'}")
    print("-" * 75)

    all_passed = True

    # 1. Inspect initial DLQ state
    attr = sqs_client.get_queue_attributes(
        QueueUrl=dlq_url,
        AttributeNames=["ApproximateNumberOfMessages", "ApproximateNumberOfMessagesNotVisible"]
    )
    initial_dlq_count = int(attr["Attributes"].get("ApproximateNumberOfMessages", 0))
    print(f"[*] Initial SQS DLQ Message Count: {initial_dlq_count}")

    # 2. Invoke Lambda asynchronously with a malformed event that induces an unhandled exception
    test_bucket = "non-existent-test-bucket-for-failure-simulation-xyz"
    test_key = "corrupt_document_crash_test.png"
    test_doc_id = hashlib.sha256(f"{test_bucket}/{test_key}/".encode("utf-8")).hexdigest()[:24]

    corrupt_payload = {
        "Records": [
            {
                "eventVersion": "2.1",
                "eventSource": "aws:s3",
                "s3": {
                    "bucket": {"name": test_bucket},
                    "object": {"key": test_key, "size": 1024}
                }
            }
        ]
    }

    print("\n[*] Invoking Lambda asynchronously (InvocationType='Event') with error-inducing payload...")
    lambda_response = lambda_client.invoke(
        FunctionName=function_arn,
        InvocationType="Event",
        Payload=json.dumps(corrupt_payload).encode("utf-8")
    )
    print(f"[+] Lambda invocation dispatched! HTTP StatusCode: {lambda_response.get('StatusCode')}")
    print("    AWS Lambda is now executing attempt 1, will retry up to 2 times upon failure,")
    print("    and will automatically route the failed event to the SQS Dead-Letter Queue.\n")

    # 3. Monitor DLQ for the new message
    print("[*] Monitoring SQS DLQ for failed event arrival (waiting for retries to exhaust)...")
    wait_time = 0
    max_wait = 90
    message_arrived = False

    while wait_time < max_wait:
        time.sleep(5)
        wait_time += 5
        attr = sqs_client.get_queue_attributes(
            QueueUrl=dlq_url,
            AttributeNames=["ApproximateNumberOfMessages"]
        )
        current_count = int(attr["Attributes"].get("ApproximateNumberOfMessages", 0))
        print(f"    [{wait_time}s] DLQ Messages Visible: {current_count}")

        if current_count > initial_dlq_count:
            message_arrived = True
            print(f"\n[+] SUCCESS: New failure message landed in SQS Dead-Letter Queue! (Total: {current_count})")
            break

    if not message_arrived:
        print("\n[!] FAILURE: Dead-Letter Queue did not receive the expected failure message within timeout.")
        all_passed = False

    # 4. Monitor CloudWatch Alarm until ALARM state
    alarm_reached = False
    if alarm_name:
        print(f"\n[*] Monitoring CloudWatch Alarm '{alarm_name}' (waiting for evaluation period)...")
        alarm_wait = 0
        alarm_max_wait = 180
        while alarm_wait < alarm_max_wait:
            try:
                alarms = cw_client.describe_alarms(AlarmNames=[alarm_name]).get("MetricAlarms", [])
                if alarms:
                    alarm_state = alarms[0].get("StateValue")
                    alarm_reason = alarms[0].get("StateReason")
                    print(f"    [{alarm_wait}s] Alarm State: {alarm_state}")
                    if alarm_state == "ALARM":
                        alarm_reached = True
                        print(f"[+] SUCCESS: CloudWatch Alarm transitioned to ALARM!")
                        print(f"    Reason: {alarm_reason}")
                        break
            except Exception as e:
                print(f"[!] Could not describe CloudWatch alarm: {e}")
            time.sleep(10)
            alarm_wait += 10

        if not alarm_reached:
            print("\n[!] FAILURE: CloudWatch Alarm did not reach 'ALARM' state.")
            all_passed = False
    else:
        print("[!] Warning: Alarm name not resolved.")
        all_passed = False

    # 5. Check SNS Subscription Confirmation
    subscription_confirmed = False
    if topic_arn and sns_client:
        print(f"\n[*] Checking SNS topic subscriptions for '{topic_arn}'...")
        try:
            subs_res = sns_client.list_subscriptions_by_topic(TopicArn=topic_arn)
            subs = subs_res.get("Subscriptions", [])
            confirmed_subs = [
                s for s in subs
                if s.get("SubscriptionArn") and not s.get("SubscriptionArn").startswith("PendingConfirmation")
            ]
            pending_subs = [
                s for s in subs
                if s.get("SubscriptionArn") and s.get("SubscriptionArn").startswith("PendingConfirmation")
            ]

            if confirmed_subs:
                subscription_confirmed = True
                print(f"[+] SUCCESS: Found {len(confirmed_subs)} confirmed SNS subscription(s):")
                for cs in confirmed_subs:
                    print(f"    - Endpoint: {cs.get('Endpoint')} (Protocol: {cs.get('Protocol')})")
            elif pending_subs:
                print(f"[!] FAILURE: SNS subscription is still 'PendingConfirmation' for {len(pending_subs)} recipient(s).")
                print("    Please click the verification link in the AWS confirmation email to activate alerts.")
            else:
                print("[!] FAILURE: No subscriptions found on the SNS Alert Topic. Deploy with -AlertEmail your-email@example.com.")
        except Exception as e:
            print(f"[!] Error querying SNS subscriptions: {e}")

        if not subscription_confirmed:
            all_passed = False
    else:
        print("[!] Warning: SNS Topic ARN not resolved.")
        all_passed = False

    # 6. Clean up test junk rows from DynamoDB
    if table_name and dynamodb_resource:
        print(f"\n[*] Cleaning up simulation junk rows from DynamoDB table '{table_name}'...")
        try:
            table = dynamodb_resource.Table(table_name)
            table.delete_item(Key={"document_id": test_doc_id})
            print(f"[+] Cleaned up test document_id={test_doc_id}")
        except Exception as e:
            print(f"[!] Note: Cleanup of {test_doc_id} skipped or not needed: {e}")

    print("\n" + "=" * 75)
    if all_passed:
        print("[+] VERIFICATION PASSED: DLQ message arrived, Alarm reached ALARM, SNS confirmed.")
    else:
        print("[!] VERIFICATION FAILED: One or more required failure assertions failed.")
    print("=" * 75)

    return all_passed


def main():
    parser = argparse.ArgumentParser(description="Simulate unhandled failure to verify retries, SQS DLQ, and CloudWatch Alarm.")
    parser.add_argument("--stack", default="pii-safe-pipeline", help="CloudFormation stack name (default: pii-safe-pipeline)")
    parser.add_argument("--region", default="us-east-1", help="AWS Region (default: us-east-1)")
    args = parser.parse_args()

    outputs = get_stack_resources(args.stack, args.region)
    function_arn = outputs.get("ProcessorFunctionArn")
    dlq_url = outputs.get("PipelineDeadLetterQueueUrl")
    topic_arn = outputs.get("FailureNotificationTopicArn")
    table_name = outputs.get("DocumentTrackingTableName")
    alarm_name = f"{args.stack}-DLQ-Messages-Alarm"

    if not function_arn or not dlq_url:
        print("[!] Error: Stack outputs not found. Make sure the stack is deployed first.")
        sys.exit(1)

    lambda_client = boto3.client("lambda", region_name=args.region)
    sqs_client = boto3.client("sqs", region_name=args.region)
    cw_client = boto3.client("cloudwatch", region_name=args.region)
    sns_client = boto3.client("sns", region_name=args.region)
    dynamodb_resource = boto3.resource("dynamodb", region_name=args.region)

    success = test_unhandled_failure_and_dlq(
        lambda_client=lambda_client,
        sqs_client=sqs_client,
        cw_client=cw_client,
        sns_client=sns_client,
        dynamodb_resource=dynamodb_resource,
        function_arn=function_arn,
        dlq_url=dlq_url,
        alarm_name=alarm_name,
        topic_arn=topic_arn,
        table_name=table_name
    )

    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
