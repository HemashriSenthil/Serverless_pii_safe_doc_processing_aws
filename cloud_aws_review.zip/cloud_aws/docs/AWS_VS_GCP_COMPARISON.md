# Direct Platform Comparison: AWS vs. GCP
## Serverless PII-Safe Document Processing Pipeline

This document provides a comprehensive side-by-side architectural and technical comparison between the AWS and Google Cloud Platform (GCP) implementations of the Serverless PII-Safe Document Processing Pipeline.

---

## 1. Component Mapping Matrix

| Architectural Stage | AWS Implementation | Google Cloud Platform (GCP) Implementation | Key Differences |
| :--- | :--- | :--- | :--- |
| **1. Raw File Storage** | **Amazon S3** (Raw Bucket) | **Google Cloud Storage (GCS)** (Raw Bucket) | Both offer 99.999999999% (11 9's) durability. S3 uses ARNs/Bucket names; GCS uses `gs://` URIs and uniform bucket-level access. |
| **2. Event Trigger** | **S3 Event Notification** (`s3:ObjectCreated:*`) | **Eventarc** / **GCS Pub/Sub Notification** (`google.cloud.storage.object.v1.finalized`) | AWS invokes Lambda directly with S3 event payload; GCP Eventarc delivers CloudEvents via Pub/Sub to Cloud Functions (2nd gen) or Cloud Run. |
| **3. Serverless Compute** | **AWS Lambda** (Python 3.12) | **Cloud Functions (2nd gen)** or **Cloud Run** | AWS Lambda is natively event-driven. Cloud Functions 2nd gen is built on top of Cloud Run (Knative container), offering concurrency per instance. |
| **4. State & Audit Store** | **Amazon DynamoDB** | **Google Cloud Firestore** (Datastore or Native mode) | DynamoDB uses Hash/Range key schema with GSIs; Firestore offers native hierarchical document collections and real-time listeners. |
| **5. OCR Extraction** | **Amazon Textract** (`detect_document_text`) | **Google Cloud Document AI** or **Cloud Vision API** (`DOCUMENT_TEXT_DETECTION`) | Textract specializes in structured forms/tables and dense single-page documents; Google Document AI specializes in parser/form extractors, and Cloud Vision API provides broad multi-lingual OCR. |
| **6. PII Detection** | **Amazon Comprehend** (`detect_pii_entities`) | **Google Cloud DLP** (Sensitive Data Protection API) | AWS Comprehend returns entity classes & character offsets; GCP Cloud DLP offers 150+ built-in infoTypes and custom dictionary/regex rules. |
| **7. Redaction** | **Lambda Custom Logic** (Union-merge overlap resolution with reverse-offset slicing) | **Cloud DLP De-identification** (`deidentifyContent` / `redactImage`) | GCP DLP has native built-in transformation primitives (masking, crypto-hashing, bucketing) directly in the API; AWS requires custom string replacement logic. |
| **8. Processed Storage** | **Amazon S3** (Processed Bucket) | **Google Cloud Storage (GCS)** (Processed Bucket) | Equivalent object storage functionality with lifecycle management. |
| **9. Auto-Cleanup** | **S3 Lifecycle Rules** (`ExpirationInDays: 1` raw, `30` processed) | **GCS Object Lifecycle Management** (`Action: Delete`, `Age: 1` raw, `30` processed) | Both automatically purge data without requiring custom compute execution. |
| **10. Failure Handling** | **SQS Dead-Letter Queue** | **Cloud Pub/Sub Dead-Letter Topic** | Both capture exhausted retries with 14-day retention. |
| **11. Monitoring & Alerts** | **CloudWatch Alarms + SNS** | **Cloud Monitoring + Alerting Policy** (Notification Channels) | AWS routes CloudWatch metric alarm to SNS Topic; GCP triggers Alerting Policy dispatching to Email/SMS/Webhook channels. |
| **IaC** | **AWS SAM / CloudFormation** | **Terraform** / **Google Cloud Deployment Manager** | SAM provides serverless-optimized shorthand; Terraform offers multi-cloud declarative resource graphs. |

---

## 2. Deep Dive: OCR & PII Capabilities

### AWS: Textract + Comprehend
- **Textract Advantage**: Excellent out-of-the-box support for synchronous single-page PDF, forms, and table structures without requiring asynchronous polling for simple files.
- **Comprehend Workflow**: Comprehend returns character start and end offsets. The application is responsible for:
  1. Union-merging overlapping bounding intervals to prevent character fragments from leaking.
  2. Applying string slices in descending order from the end of the string to the beginning so that offset positions do not drift as text length changes.
  3. Formatting redacted tags (e.g. `[NAME]`, `[ID_NUMBER]`, `[DOB]`).

### GCP: Document AI / Cloud Vision + Cloud DLP (Sensitive Data Protection)
- **Document AI / Cloud Vision**: Fast, multi-lingual OCR with entity extraction or word and paragraph bounding boxes.
- **Cloud DLP Advantage**: Cloud DLP is the industry standard for comprehensive data privacy. It includes **native de-identification transformations**:
  - `ReplaceWithInfoTypeConfig`: Replaces matches with `[INFO_TYPE_NAME]` directly in the API call.
  - `CharacterMaskConfig`: Masks characters with asterisks `****`.
  - `CryptoReplaceFfxFpeConfig`: Format-preserving encryption.
  - Native pixel-level image redaction: Can black out PII directly on the image bytes without separate text extraction!

---

## 3. Failure Handling & Resiliency Comparison

```mermaid
graph LR
    subgraph AWS Resilience Model
        L["AWS Lambda"] -->|"Failure"| R1["Auto Retry (1 & 2)"]
        R1 -->|"Exhausted"| DLQ1["SQS DLQ"]
        DLQ1 -->|"Metric: NumberOfMessagesSent >= 1"| CW["CloudWatch Alarm"]
        CW -->|"Trigger"| SNS["SNS Topic"]
        SNS -->|"Email"| Admin1["Engineer"]
    end

    subgraph GCP Resilience Model
        CF["Cloud Functions"] -->|"Failure"| R2["Pub/Sub Retry & Backoff"]
        R2 -->|"Max Delivery Attempts"| DLQ2["Pub/Sub Dead-Letter Topic"]
        DLQ2 -->|"Metric: undelivered_messages"| CM["Cloud Monitoring Alert"]
        CM -->|"Trigger"| NC["Notification Channel"]
        NC -->|"Email"| Admin2["Engineer"]
    end
```

---

## 4. Operational & Cost Comparison

Both cloud providers operate on a consumption-based, pay-as-you-go pricing model for serverless workloads. For current, official pricing schedules, consult:
- **AWS Official Pricing**:
  - [AWS Lambda Pricing](https://aws.amazon.com/lambda/pricing/)
  - [Amazon Textract Pricing](https://aws.amazon.com/textract/pricing/)
  - [Amazon Comprehend Pricing](https://aws.amazon.com/comprehend/pricing/)
  - [Amazon DynamoDB Pricing](https://aws.amazon.com/dynamodb/pricing/)
  - [Amazon S3 Pricing](https://aws.amazon.com/s3/pricing/)
- **GCP Official Pricing**:
  - [Cloud Functions Pricing](https://cloud.google.com/functions/pricing)
  - [Document AI Pricing](https://cloud.google.com/document-ai/pricing)
  - [Cloud Vision API Pricing](https://cloud.google.com/vision/pricing)
  - [Sensitive Data Protection (Cloud DLP) Pricing](https://cloud.google.com/sensitive-data-protection/pricing)
  - [Cloud Storage Pricing](https://cloud.google.com/storage/pricing)

| Architecture Dimension | AWS Pricing Metric | GCP Pricing Metric | Trade-off Summary |
| :--- | :--- | :--- | :--- |
| **Compute Execution** | Per millisecond and allocated GB RAM | Per millisecond (vCPU/GB RAM seconds) | Virtually identical; AWS includes 1M requests/mo free tier; GCP includes 2M calls/mo. |
| **OCR Text Extraction** | Per page processed (`DetectDocumentText`) | Per page (Document AI) or per 1,000 images (Cloud Vision) | Document AI provides domain-trained parsers; Textract provides synchronous key-value and raw line extraction. |
| **PII Detection & Redaction** | Per unit (100 characters in Comprehend) | Per GB of data inspected / stored in Cloud DLP | Comprehend scales by character volume; Cloud DLP scales by megabytes/gigabytes of inspected content. |
| **Object Storage** | Per GB-month stored + PUT/GET request tiers | Per GB-month stored + Class A/B request tiers | Both cost ~$0.02 - $0.023 per GB-month with automatic lifecycle transitioning. |
| **State Store** | DynamoDB On-Demand: Pay-Per-Request read/write units | Firestore: Per document read, write, and delete operations | DynamoDB scales on throughput capacity units; Firestore scales on discrete document mutations. |

---

## 5. Architectural Verdict

- **Choose AWS When**:
  - The organization already operates in AWS with existing IAM guardrails, SAM CI/CD pipelines, and CloudWatch operational runbooks.
  - Synchronous document processing with AWS Textract and Comprehend fits existing compliance boundaries.
  - Native integration with DynamoDB and SQS DLQ provides a robust, zero-maintenance serverless event-driven architecture.
- **Choose GCP When**:
  - Advanced privacy transformations (format-preserving encryption, tokenization, k-anonymity, or direct image pixel redaction) are required, where **Cloud DLP** provides native built-in operations.
  - Multi-lingual OCR across diverse global languages is required via Document AI / Cloud Vision API.
