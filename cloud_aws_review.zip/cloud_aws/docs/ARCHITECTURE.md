# Architecture: Serverless PII-Safe Document Processing Pipeline on AWS

This document outlines the architecture, data flow, security model, and failure-handling mechanisms for the Serverless PII-Safe Document Processing Pipeline implemented on Amazon Web Services (AWS).

---

## 1. End-to-End Architecture Flow

```mermaid
flowchart TD
    classDef storage fill:#1e293b,stroke:#06b6d4,stroke-width:2px,color:#f8fafc;
    classDef compute fill:#1e293b,stroke:#6366f1,stroke-width:2px,color:#f8fafc;
    classDef ai fill:#1e293b,stroke:#a855f7,stroke-width:2px,color:#f8fafc;
    classDef failure fill:#3b0764,stroke:#f43f5e,stroke-width:2px,color:#f8fafc;

    User["👤 User / Client"] -->|"1. Uploads JPG, PNG, or single-page PDF"| RawS3["🪣 S3 Raw Bucket (TLS Deny)"]:::storage
    RawS3 -->|"2. S3 ObjectCreated Trigger"| Lambda["⚡ AWS Lambda Processor (Python 3.12)"]:::compute

    subgraph Core Pipeline Execution
        Lambda -->|"3. Conditional Put (Idempotent ID)"| DDB[("📊 DynamoDB Tracking Table")]:::storage
        Lambda -->|"4. Validate Extension, Magic Bytes, Size, PDF Pages"| ValidCheck{"Valid Format?"}
        
        ValidCheck -- "No" --> FailStep4["Update DynamoDB: FAILED\n(error_step: VALIDATION, no retry)"]:::failure
        ValidCheck -- "Yes" --> TextractCall["5. Amazon Textract\ndetect_document_text"]:::ai
        
        TextractCall --> TextFoundCheck{"Text Detected?"}
        TextFoundCheck -- "No" --> FailStep5["Update DynamoDB: FAILED\n(error_step: TEXT_EXTRACTION)"]:::failure
        TextFoundCheck -- "Yes" --> ComprehendCall["6. Amazon Comprehend\ndetect_pii_entities"]:::ai
        
        ComprehendCall --> RedactionLogic["7. Union-Merge & Reverse-Offset Redaction\n(Default-deny masking with [TYPE] labels)"]:::compute
        
        RedactionLogic --> StoreProcessed["8a. Put Redacted Text & Audit JSON"| ProcessedS3["🪣 S3 Processed Bucket (TLS Deny)"]:::storage
        RedactionLogic --> UpdateDDB["8b. Update DynamoDB: COMPLETED\n(PII counts, stage timeline, provenances)"]:::storage
    end

    RawS3 -.->|"9. Lifecycle Rule (1-Day Expiry)"| AutoDelete["🗑️ Automatic Raw Data Purge"]:::storage
    ProcessedS3 -.->|"9b. Lifecycle Rule (30-Day Expiry)"| AutoDeleteProc["🗑️ Automatic Processed Data Purge"]:::storage

    subgraph Failure Handling & Alerting
        Lambda -.->|"10. Unhandled Exceptions (Auto-retry 2x)"| DLQ["📥 SQS Dead-Letter Queue (DLQ)"]:::failure
        DLQ -->|"Metric: NumberOfMessagesSent >= 1"| CWAlarm["⏰ CloudWatch Metric Alarm"]:::failure
        CWAlarm -->|"Alarm & OK Actions"| SNSAlert["📢 SNS Alert Topic"]:::failure
        SNSAlert -->|"Email Notification"| AdminEmail["📧 Security Engineer / Operations"]
    end
```

---

## 2. Component Breakdown & Responsibilities

| Purpose | AWS Service | Role in Pipeline |
| :--- | :--- | :--- |
| **File Upload & Ingestion** | **Amazon S3 (Raw Bucket)** | Ingestion point for JPG, PNG, and single-page PDF files. Enforces Server-Side Encryption (AES256), TLS transport deny policy, and blocks public access. |
| **Event Ingestion Trigger** | **Amazon S3 Notifications** | Generates an `s3:ObjectCreated:*` event that invokes the Lambda processor asynchronously with execution environment reuse. |
| **Serverless Compute** | **AWS Lambda (Python 3.12)** | Orchestrates validation, text extraction, PII entity detection, span union-merging, reverse-offset masking, DynamoDB record persistence, and S3 storage. |
| **OCR Text Extraction** | **Amazon Textract** | Extracts raw text lines synchronously (`DetectDocumentText`) from images and single-page PDFs with `ocr_engine: "textract"` provenance. |
| **PII Entity Detection** | **Amazon Comprehend** | Performs natural language processing and entity detection (`DetectPiiEntities`), returning entity types and character offset positions with `pii_engine: "comprehend"` provenance. |
| **Status & Audit Storage** | **Amazon DynamoDB** | Single-table design with `StatusIndex` GSI tracking real-time status transitions (`PROCESSING` &rarr; `COMPLETED` / `FAILED`), PII entity counts, execution latency, and stage timeline. |
| **Processed Storage** | **Amazon S3 (Processed Bucket)** | Stores safe, masked document text files (`redacted/{document_id}.txt`) and non-sensitive audit metadata (`metadata/{document_id}.metadata.json`). |
| **Automated Data Hygiene** | **S3 Lifecycle Rules** | Automatically purges raw unredacted documents after 1 day, processed files after 30 days, and aborts incomplete multipart uploads after 1 day. |
| **Failure Dead-Letter Queue** | **Amazon SQS** | Captures failed invocation payloads after 2 automatic asynchronous Lambda retries are exhausted. |
| **Monitoring & Alarms** | **Amazon CloudWatch** | Monitors `NumberOfMessagesSent >= 1` on the DLQ with `TreatMissingData: notBreaching`. |
| **Proactive Notification** | **Amazon SNS** | Dispatches high-priority email alerts to operations/security teams when failures enter the DLQ and sends recovery notifications when resolved. |
| **Access Governance** | **AWS IAM** | Enforces principle of least privilege with explicit, scoped IAM actions (no broad CRUD policy templates). |

---

## 3. Detailed Step-by-Step Processing

### Step 1: Upload
The user uploads a document to `RawBucket`. The system accepts:
- `image/jpeg` (`.jpg`, `.jpeg`)
- `image/png` (`.png`)
- `application/pdf` (`.pdf` - single page only)

### Step 2: S3 Event Trigger & Deterministic ID
S3 fires `s3:ObjectCreated:*`. AWS Lambda automatically invokes `ProcessorFunction`.
The pipeline computes a deterministic, opaque `document_id`:
```python
document_id = hashlib.sha256(f"{bucket}/{object_key}/{sequencer}".encode("utf-8")).hexdigest()[:24]
```
Original file names and S3 keys are hashed (`file_name_hash`, `raw_key_hash`) so sensitive client data never leaks into IDs or logs.

### Step 3: DynamoDB Record Creation (Idempotent)
Before performing any intensive computation, Lambda creates a DynamoDB record with conditional write:
```json
{
  "document_id": "2496a951a3eeaaeffabb3a4a",
  "status": "PROCESSING",
  "raw_bucket": "pii-safe-pipeline-raw-123456789012",
  "file_type": ".png",
  "file_size_bytes": 104520,
  "file_name_hash": "a4f89d31c2b5e709",
  "raw_key_hash": "c9b21f08e4d3a789",
  "upload_timestamp": "2026-10-19T23:00:00Z",
  "stages": [
    {
      "stage": "uploaded",
      "at": "2026-10-19T23:00:00Z",
      "timestamp": "2026-10-19T23:00:00Z",
      "service": "S3",
      "duration_ms": 0,
      "items": 104520
    }
  ]
}
```
If a record with this `document_id` already exists:
- `COMPLETED` records are preserved and duplicate events skipped.
- Terminal `FAILED` records are preserved.
- Retriable errors increment the `attempts` counter.

### Step 4: Multi-Layer Validation
Lambda validates document characteristics before calling external AI services:
1. **Extension check**: Must be in `.jpg`, `.jpeg`, `.png`, `.pdf`.
2. **Size check**: Reject zero-byte files and files exceeding 5 MB.
3. **Magic bytes**: Verify byte headers (`\xff\xd8` for JPEG, `\x89PNG` for PNG, `%PDF` for PDF).
4. **PDF page count**: Count pages via `pypdf`; reject multi-page documents (> 1 page).

If validation fails, Lambda updates DynamoDB:
- `status`: `"FAILED"`
- `error_step`: `"VALIDATION"`
- `failure_reason`: Descriptive error message (e.g., `"Unsupported file type: '.txt'. Supported types are: .jpeg, .jpg, .pdf, .png"`)

The function exits gracefully without triggering retries (this is a client validation error, not an operational failure).

### Step 5: OCR Text Extraction
Lambda calls Amazon Textract synchronous API `detect_document_text`:
- Reconstructs document lines by filtering `BlockType == 'LINE'`.
- Validates extracted text:
  - If empty or whitespace only, DynamoDB is marked `FAILED` with `failure_reason: "No readable text detected in document by Textract OCR"`.
- Records `ocr_done` stage and sets `ocr_engine: "textract"`.
- Textract document-level client exceptions (`UnsupportedDocumentException`, `BadDocumentException`, `DocumentTooLargeException`) cleanly fail with `error_step: "TEXT_EXTRACTION"` without triggering Lambda retries. Only transient throttling and 5xx errors re-raise.

### Step 6: PII Detection
Lambda calls Amazon Comprehend `detect_pii_entities`:
- Analyzes text tokens in English (`LanguageCode='en'`).
- Detects PII entities including `NAME`, `EMAIL`, `PHONE`, `SSN`, `ADDRESS`, `DATE_TIME`, `AGE`, `CREDIT_DEBIT_NUMBER`, `DRIVER_ID`, `PASSPORT_NUMBER`, `BANK_ACCOUNT_NUMBER`, `IN_AADHAAR`, `AWS_ACCESS_KEY`, `PASSWORD`, `URL`, `IP_ADDRESS`.
- Server enforces default-deny masking: all detected PII categories above confidence threshold are masked regardless of client requests.
- Optional custom keywords from S3 metadata are additive only.
- Records `pii_done` stage and sets `pii_engine: "comprehend"`.

### Step 7: Precision Redaction Algorithm
To ensure character offsets remain accurate and sensitive tokens never leak:
1. **Union-Merge Overlap Resolution**: Entities with overlapping intervals are merged into a single span spanning `(min(start), max(end))` and assigned the highest-priority entity label:
   ```python
   # Spans are sorted by start offset and length; overlapping spans are unified
   # to prevent partial fragments of names, numbers, or addresses from surviving.
   ```
2. **Reverse-Offset Slicing**: Entities are sorted by `BeginOffset` in **descending** order (right to left):
   $$\text{text} = \text{text}[0:\text{start}] + \text{"["} + \text{TYPE} + \text{"]"} + \text{text}[\text{end}:]$$
   Processing right-to-left guarantees that earlier character positions remain strictly unchanged!

### Step 8: Safe Storage & DynamoDB Completion
1. Redacted text is written to `ProcessedBucket`: `redacted/{document_id}.txt`.
2. Sanitized audit metadata is written to `ProcessedBucket`: `metadata/{document_id}.metadata.json`.
3. Records `stored` stage.
4. DynamoDB record updated to `COMPLETED`:
```json
{
  "status": "COMPLETED",
  "pii_count": 5,
  "pii_types_found": {
    "NAME": 1,
    "ADDRESS": 1,
    "PHONE": 1,
    "ID_NUMBER": 1,
    "DOB": 1
  },
  "ocr_engine": "textract",
  "pii_engine": "comprehend",
  "stages": [
    {"stage": "uploaded", "service": "S3", "duration_ms": 0},
    {"stage": "validated", "service": "S3", "duration_ms": 15},
    {"stage": "ocr_done", "service": "Textract", "duration_ms": 420},
    {"stage": "pii_done", "service": "Comprehend", "duration_ms": 280},
    {"stage": "stored", "service": "S3", "duration_ms": 25}
  ],
  "processed_bucket": "pii-safe-pipeline-processed-123456789012",
  "processed_key": "redacted/2496a951a3eeaaeffabb3a4a.txt",
  "metadata_key": "metadata/2496a951a3eeaaeffabb3a4a.metadata.json",
  "execution_duration_ms": 740
}
```

### Step 9: Automatic Data Hygiene (S3 Lifecycle)
Both buckets enforce automated data hygiene via S3 Lifecycle rules:
- `RawBucket`: Files expire after `RawFileRetentionDays` (default: 1 day).
- `ProcessedBucket`: Processed redacted documents expire after 30 days.
- Incomplete multipart uploads are aborted automatically after 1 day.

### Step 10: Failure Handling & DLQ Alerting
Any unexpected operational failure (network disconnection, rate limiting, or 5xx outage):
1. **Asynchronous Retry**: AWS Lambda automatically retries up to 2 times (`MaximumRetryAttempts: 2`).
2. **DLQ Destination**: If retries are exhausted, the event payload routes to `PipelineDeadLetterQueue` (SQS).
3. **CloudWatch Alarm**: CloudWatch monitors `NumberOfMessagesSent >= 1` on the DLQ.
4. **SNS Notification**: CloudWatch triggers `FailureNotificationTopic`, sending an immediate alert email to operators, with `OKActions` sending a resolution notice when the queue is drained.
