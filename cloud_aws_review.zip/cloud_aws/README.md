# Serverless PII-Safe Document Processing Pipeline on AWS

[![AWS SAM](https://img.shields.io/badge/AWS-SAM%20CloudFormation-orange.svg)](https://aws.amazon.com/serverless/sam/)
[![Python 3.12](https://img.shields.io/badge/Python-3.12-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

An enterprise-grade, serverless data pipeline on Amazon Web Services (AWS) that automatically detects, masks, and redacts Personally Identifiable Information (PII) from ingested documents (IDs, forms, invoices) in real time. Built with automated S3 lifecycle cleanup, DynamoDB state tracking, asynchronous retries, SQS Dead-Letter Queue (DLQ), and CloudWatch/SNS alerting.

---

## Architecture Overview

```
[User / Client]
       │
       ▼ (1. Upload JPG, PNG, PDF)
[S3 Raw Bucket] ──(9. 1-Day Lifecycle Expiry)──► [Purged from S3]
       │
       ▼ (2. s3:ObjectCreated Event)
[AWS Lambda Processor]
       ├──► (3. Insert Record) ──────► [DynamoDB Table] (status: PROCESSING)
       ├──► (4. Validate Extension) ─► [DynamoDB Table] (status: FAILED if invalid)
       ├──► (5. Extract OCR Text) ───► [Amazon Textract]
       ├──► (6. Scan PII Entities) ──► [Amazon Comprehend]
       ├──► (7. Redact Entities) ────► [Reverse-Offset Slicing with [TYPE] labels]
       ├──► (8a. Store Masked Text) ─► [S3 Processed Bucket]
       └──► (8b. Finalize Audit) ────► [DynamoDB Table] (status: COMPLETED)
       │
       ▼ (10. Unhandled Failure after 2 retries)
[SQS Dead-Letter Queue]
       │
       ▼ (Queue Depth >= 1)
[CloudWatch Metric Alarm]
       │
       ▼ (Trigger Alert)
[SNS Notification Topic] ──► [Email Alert to Operations]
```

---

## AWS Services Mapping

| Purpose | AWS Service | Role |
| :--- | :--- | :--- |
| **File Upload & Ingestion** | **Amazon S3 (Raw Bucket)** | Ingestion point for JPG, PNG, and single-page PDF documents. |
| **Compute & Trigger** | **AWS Lambda** (Python 3.12) | Serverless execution triggered by S3 `ObjectCreated` events. |
| **OCR Text Extraction** | **Amazon Textract** | Synchronous OCR extraction (`DetectDocumentText`) with line reconstruction. |
| **PII Detection** | **Amazon Comprehend** | Natural language entity recognition (`DetectPiiEntities`) for names, phones, emails, SSNs, addresses, etc. |
| **Status & Metadata** | **Amazon DynamoDB** | Single-table tracking with status transitions (`PROCESSING` &rarr; `COMPLETED` / `FAILED`). |
| **Processed Storage** | **Amazon S3 (Processed Bucket)** | Secure storage for `.redacted.txt` text and non-sensitive audit metadata. |
| **Data Hygiene** | **S3 Lifecycle Rules** | Automatic expiration and purging of raw documents after 1 day. |
| **Failure Handling** | **Amazon SQS (DLQ)** | Dead-letter queue capturing failed events after 2 automatic Lambda retries. |
| **Monitoring & Alerts** | **CloudWatch + SNS** | Metric alarm on DLQ message count triggering SNS email alerts. |
| **Infrastructure as Code** | **AWS SAM / CloudFormation** | Complete declarative infrastructure specification in `template.yaml`. |

---

## Project Structure

```
cloud_aws/
├── template.yaml                  # Production AWS SAM template
├── samconfig.toml                 # Pre-configured SAM deployment settings
├── deploy.ps1                     # One-click PowerShell deployment script
├── src/
│   ├── pipeline_handler.py        # Core Lambda entry point (orchestrates steps 2-10)
│   ├── text_extractor.py          # Amazon Textract OCR integration with engine provenance
│   ├── pii_redactor.py            # Amazon Comprehend PII detection & union-merge masking
│   ├── dynamodb_manager.py        # DynamoDB idempotent state tracking & stage timeline
│   └── requirements.txt           # Lambda runtime dependencies (pypdf for PDF validation)
├── sample_docs/                   # Generated synthetic test documents
│   ├── sample_scholarship_application.pdf # Admissions scholarship application
│   ├── sample_academic_marksheet.pdf      # Student academic marksheet
│   ├── sample_income_certificate.png      # Income certificate document
│   ├── sample_id_card.png                 # Student/Government ID format
│   ├── sample_medical_intake.jpg          # Patient intake form
│   ├── sample_application.pdf             # Financial application form
│   ├── blank_document.png                 # Blank canvas to test Step 5 failure branch
│   ├── unsupported_document.txt           # Plain text file to test Step 4 validation rejection
│   ├── sample_corrupt.png                 # Corrupted image to test magic bytes validation
│   ├── sample_multipage.pdf               # Multi-page PDF to test single-page enforcement
│   └── sample_zerobyte.png                # 0-byte file to test empty file rejection
├── scripts/
│   ├── generate_sample_docs.py    # Python generator for realistic test documents
│   ├── upload_and_monitor.py      # CLI tool to upload files and stream live status
│   ├── simulate_failure.py        # DLQ, retry, and CloudWatch/SNS failure test script
│   └── dashboard_server.py        # Local web dashboard server bridging to AWS
├── dashboard/                     # Modern interactive web dashboard
│   ├── index.html                 # Single-page UI with pipeline visualization
│   ├── styles.css                 # Dark-mode glassmorphic styling
│   └── app.js                     # Real-time polling, upload, and redaction inspector
├── tests/
│   └── test_pipeline_unit.py      # Unit test suite (pytest)
└── docs/
    ├── ARCHITECTURE.md            # Deep dive into architecture, flows, and security
    └── AWS_VS_GCP_COMPARISON.md   # Side-by-side AWS vs GCP architectural comparison
```

---

## Quickstart & Deployment

### 1. Prerequisites
- Python 3.10+
- AWS CLI v2 configured (`aws configure`)
- AWS SAM CLI installed

### 2. Run Unit Tests Locally
```powershell
python -m pytest tests/test_pipeline_unit.py -v
```

### 3. Deploy to AWS
You can deploy using the provided PowerShell script or standard SAM CLI:

**Option A: Using `deploy.ps1` (Recommended)**
```powershell
# Basic deployment
.\deploy.ps1

# Deployment with failure alert email
.\deploy.ps1 -AlertEmail "admin@example.com" -RetentionDays 1
```

**Option B: Using SAM CLI**
```powershell
sam build
sam deploy --guided
```

Once deployment completes, the command outputs the S3 Bucket names, DynamoDB Table name, and SQS DLQ URL.

---

## Testing the Pipeline

### 1. Upload Documents via CLI
Upload a sample document and watch the live DynamoDB state transition in your terminal:
```powershell
# Upload a single document
python scripts/upload_and_monitor.py --file sample_docs/sample_id_card.png

# Upload core sample test documents sequentially (including failure test cases)
python scripts/upload_and_monitor.py --all
```

### 2. Launch the Web Dashboard
Start the local dashboard server to view live pipeline metrics, drag-and-drop documents, and inspect redacted outputs side-by-side:
```powershell
python scripts/dashboard_server.py
```
Open **`http://localhost:8000`** in your browser.

### 3. Test Failure Handling (Step 10)
Simulate an unhandled operational exception to verify automatic retries, delivery to the SQS Dead-Letter Queue, and CloudWatch/SNS alarm triggering:
```powershell
python scripts/simulate_failure.py
```

---

## Teardown & Clean Up

To tear down the CloudFormation stack and remove all provisioned AWS resources:

> **Important**: AWS CloudFormation cannot delete non-empty S3 buckets. You must first empty the processed documents bucket (and raw bucket if any unexpired files remain) before executing `sam delete`:
>
> ```powershell
> # 1. Empty the S3 buckets
> aws s3 rm s3://<StackName>-raw-<AccountId> --recursive
> aws s3 rm s3://<StackName>-processed-<AccountId> --recursive
>
> # 2. Delete the SAM CloudFormation stack
> sam delete --stack-name pii-safe-pipeline
> ```

---

## AWS vs. GCP Platform Comparison

As part of the assignment requirements, the pipeline was designed to be directly comparable between AWS and GCP. See [docs/AWS_VS_GCP_COMPARISON.md](docs/AWS_VS_GCP_COMPARISON.md) for the complete analysis.

| Functionality | AWS | GCP |
| :--- | :--- | :--- |
| **Object Storage** | Amazon S3 | Google Cloud Storage (GCS) |
| **Compute Engine** | AWS Lambda | Cloud Functions (2nd gen) / Cloud Run |
| **OCR Extraction** | Amazon Textract (`DetectDocumentText`) | Cloud Vision API (`DOCUMENT_TEXT_DETECTION`) |
| **PII Detection & Redaction** | Amazon Comprehend (`DetectPiiEntities`) + Lambda string slicing | Cloud Data Loss Prevention (Cloud DLP / Sensitive Data Protection) |
| **Database Tracking** | Amazon DynamoDB | Cloud Firestore |
| **Dead-Letter Handling** | Amazon SQS DLQ | Cloud Pub/Sub Dead-Letter Topic |
| **Alarms & Notifications** | CloudWatch Metric Alarm + Amazon SNS | Cloud Monitoring Alerting Policy + Notification Channel |

---

## Security Best Practices
- **TLS Transport Enforcement**: Bucket policies enforce TLS encryption in transit by explicitly denying all non-TLS (`aws:SecureTransport: "false"`) requests.
- **Least Privilege IAM**: The Lambda role has explicit, least-privilege action statements strictly scoped to the specific DynamoDB table, SQS DLQ, and S3 buckets created in the stack (no broad CRUD policy templates).
- **Opaque Deterministic IDs**: Document IDs are 24-character hex hashes generated deterministically from the bucket, key, and S3 sequencer/eTag. Raw client file names and PII never leak into IDs, DynamoDB keys, processed S3 paths (`redacted/{document_id}.txt`), or logs.
- **Automated Data Hygiene**: S3 Lifecycle automatically purges raw unredacted files after 1 day, expires processed redacted files after 30 days, and aborts incomplete multipart uploads after 1 day.
- **Server-Enforced Default-Deny Masking**: All detected PII categories above the confidence threshold are automatically masked; custom keywords are additive only. Overlapping entity spans are union-merged to prevent character fragments from leaking.
- **Privacy in Audit Logs**: CloudWatch logs and DynamoDB audit records never persist raw text, file names, or unredacted PII—only opaque hashes, entity frequencies, and stage timelines are retained. Log groups enforce 14-day retention.
