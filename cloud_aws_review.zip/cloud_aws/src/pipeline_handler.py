import os
import time
import json
import uuid
import hashlib
import logging
import urllib.parse
from typing import Any, Optional, Dict, List
from datetime import datetime, timezone
import boto3
from botocore.exceptions import ClientError

from decimal import Decimal
from dynamodb_manager import DynamoDBManager
from text_extractor import TextExtractor, TextractDocumentError
from pii_redactor import PiiRedactor

def _from_decimal(obj) -> Any:
    """
    Recursively converts Decimal instances to int or float for standard JSON serialization.
    """
    if isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    if isinstance(obj, dict):
        return {k: _from_decimal(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_from_decimal(v) for v in obj]
    return obj

# Configure structured logging
logger = logging.getLogger()
logger.setLevel(os.environ.get("LOG_LEVEL", "INFO"))

SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".pdf"}

# Initialize AWS clients outside handler for Lambda execution environment reuse
s3_client = boto3.client("s3")
dynamodb_manager = DynamoDBManager()
text_extractor = TextExtractor()
pii_redactor = PiiRedactor()

import re

TIMEOUT_BUFFER_MS = 10000  # 10s buffer before Lambda timeout to gracefully mark FAILED/TIMEOUT


def _scrub_error_message(e: Exception) -> str:
    """
    F14: Scrubs raw exception message of sensitive ARNs, secrets, or file paths
    while preserving actionable error classification and messages.
    """
    msg = str(e)
    # Remove ARNs
    msg = re.sub(r"arn:aws:[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+:\d{12}:[^\s,]+", "[REDACTED_ARN]", msg)
    # Remove AWS access key IDs
    msg = re.sub(r"(AKIA|ASIA)[A-Z0-9]{16}", "[REDACTED_KEY]", msg)
    # Remove leaked secrets or tokens
    msg = re.sub(r"leaked secrets[^\s]*", "[REDACTED]", msg)
    return msg[:200]



def _check_timeout(context, document_id: str, stage_name: str, stages: Optional[list] = None) -> bool:
    """
    Checks remaining execution time. If under TIMEOUT_BUFFER_MS remains, marks
    document FAILED with error_step=TIMEOUT to prevent stuck PROCESSING records (F17).
    """
    if context and hasattr(context, "get_remaining_time_in_millis"):
        try:
            remaining = context.get_remaining_time_in_millis()
            if remaining < TIMEOUT_BUFFER_MS:
                reason = f"Lambda execution time depleted before stage {stage_name} ({remaining} ms remaining < {TIMEOUT_BUFFER_MS} ms buffer)."
                logger.error(f"F17 Timeout Protection for {document_id}: {reason}")
                dynamodb_manager.mark_failed(
                    document_id=document_id,
                    failure_reason=reason,
                    error_step="TIMEOUT",
                    stages=stages
                )
                return True
        except Exception as t_err:
            logger.warning(f"Could not read remaining time from context: {t_err}")
    return False


def lambda_handler(event, context) -> Dict[str, Any]:
    """
    Main Lambda entry point triggered by S3 ObjectCreated events.
    Executes Steps 2 through 8 of the pipeline, with automatic SQS DLQ
    routing on unhandled failure (Step 10).
    """
    start_time = time.time()
    records = event.get("Records", [])
    logger.info(f"Received S3 event with {len(records)} record(s)")

    # 1. Parse S3 Event records
    if not records:
        logger.warning("No records found in event payload. Exiting.")
        return {"statusCode": 200, "message": "No S3 records to process"}

    processed_results = []

    for record in records:
        s3_data = record.get("s3", {})
        bucket_name = s3_data.get("bucket", {}).get("name")
        raw_key_encoded = s3_data.get("object", {}).get("key")
        file_size_bytes = s3_data.get("object", {}).get("size", 0)

        if not bucket_name or not raw_key_encoded:
            logger.warning("Malformed S3 record: missing bucket or key")
            continue

        # Decode URL-encoded object key (e.g., spaces as '+' or '%20')
        object_key = urllib.parse.unquote_plus(raw_key_encoded)
        file_name = os.path.basename(object_key)
        _, file_ext = os.path.splitext(file_name)
        file_ext = file_ext.lower()

        # Deterministic document_id from bucket, key, and sequencer or eTag (F5 & F13)
        s3_obj = s3_data.get("object", {})
        seq = s3_obj.get("sequencer") or s3_obj.get("eTag") or ""
        document_id = hashlib.sha256(f"{bucket_name}/{object_key}/{seq}".encode("utf-8")).hexdigest()[:24]

        logger.info(f"Step 2: Processing triggered for document_id={document_id}")

        # Step 3: Record creation in DynamoDB with status PROCESSING (conditional write)
        req_id = getattr(context, "aws_request_id", None) or "local-exec"
        try:
            record_item, should_process = dynamodb_manager.create_processing_record(
                document_id=document_id,
                file_name=file_name,
                raw_bucket=bucket_name,
                raw_key=object_key,
                file_size_bytes=file_size_bytes,
                file_type=file_ext or "unknown",
                lambda_request_id=req_id
            )
            if not should_process:
                logger.info(f"Document {document_id} already in terminal state or duplicate event. Skipping.")
                processed_results.append({
                    "document_id": document_id,
                    "status": record_item.get("status", "SKIPPED"),
                    "skipped": True
                })
                continue
        except Exception as e:
            logger.error(f"Failed in Step 3 (DynamoDB record creation) for {document_id}: {type(e).__name__}")
            # Re-raise to trigger Lambda retry and SQS DLQ
            raise

        # Initialize stages tracking list with uploaded stage (F18)
        stages: list[Any] = _from_decimal(list(record_item.get("stages", [])))
        if not stages:
            uploaded_at = record_item.get("upload_timestamp") or datetime.now(timezone.utc).isoformat()
            stages.append({
                "stage": "uploaded",
                "at": uploaded_at,
                "timestamp": uploaded_at,
                "service": "S3",
                "duration_ms": 0,
                "ms": 0,
                "items": int(file_size_bytes)
            })

        # Step 4: Validation (F10 & F17)
        validation_start = time.time()
        if _check_timeout(context, document_id, "VALIDATION", stages=stages):
            processed_results.append({
                "document_id": document_id,
                "status": "FAILED",
                "reason": "Execution timed out before validation",
                "error_step": "TIMEOUT",
                "stages": stages
            })
            continue

        # 4a: File extension check
        if file_ext not in SUPPORTED_EXTENSIONS:
            reason = (
                f"Unsupported file type: '{file_ext or 'empty'}'. "
                f"Supported types are: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
            )
            logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
            dynamodb_manager.mark_failed(
                document_id=document_id,
                failure_reason=reason,
                error_step="VALIDATION",
                stages=stages
            )
            processed_results.append({
                "document_id": document_id,
                "status": "FAILED",
                "reason": reason,
                "stages": stages
            })
            continue

        # 4b: File size check from event (reject zero-byte and oversized files)
        MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024  # 5 MB limit
        if file_size_bytes == 0:
            reason = "Zero-byte file rejected: document contains no data."
            logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
            dynamodb_manager.mark_failed(
                document_id=document_id,
                failure_reason=reason,
                error_step="VALIDATION",
                stages=stages
            )
            processed_results.append({
                "document_id": document_id,
                "status": "FAILED",
                "reason": reason,
                "stages": stages
            })
            continue

        if file_size_bytes > MAX_FILE_SIZE_BYTES:
            reason = f"File size exceeds limit: {file_size_bytes} bytes exceeds {MAX_FILE_SIZE_BYTES} bytes (5 MB)."
            logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
            dynamodb_manager.mark_failed(
                document_id=document_id,
                failure_reason=reason,
                error_step="VALIDATION",
                stages=stages
            )
            processed_results.append({
                "document_id": document_id,
                "status": "FAILED",
                "reason": reason,
                "stages": stages
            })
            continue

        # 4c: Read object from S3 to validate magic bytes and content integrity
        try:
            s3_obj_res = s3_client.get_object(Bucket=bucket_name, Key=object_key)
            file_bytes = s3_obj_res["Body"].read()
        except ClientError as s3_err:
            logger.error(f"Failed to read raw object for {document_id}: {type(s3_err).__name__}")
            raise

        actual_size = len(file_bytes)
        if actual_size == 0:
            reason = "Zero-byte file rejected: document contains no data."
            logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
            dynamodb_manager.mark_failed(
                document_id=document_id,
                failure_reason=reason,
                error_step="VALIDATION",
                stages=stages
            )
            processed_results.append({
                "document_id": document_id,
                "status": "FAILED",
                "reason": reason,
                "stages": stages
            })
            continue

        if actual_size > MAX_FILE_SIZE_BYTES:
            reason = f"File size exceeds limit: {actual_size} bytes exceeds {MAX_FILE_SIZE_BYTES} bytes (5 MB)."
            logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
            dynamodb_manager.mark_failed(
                document_id=document_id,
                failure_reason=reason,
                error_step="VALIDATION",
                stages=stages
            )
            processed_results.append({
                "document_id": document_id,
                "status": "FAILED",
                "reason": reason,
                "stages": stages
            })
            continue

        # 4d: Validate magic bytes
        is_magic_valid = False
        magic_expected = ""
        if file_ext in (".jpg", ".jpeg"):
            is_magic_valid = file_bytes.startswith(b"\xff\xd8")
            magic_expected = "JPEG (\\xff\\xd8)"
        elif file_ext == ".png":
            is_magic_valid = file_bytes.startswith(b"\x89PNG")
            magic_expected = "PNG (\\x89PNG)"
        elif file_ext == ".pdf":
            is_magic_valid = file_bytes.startswith(b"%PDF")
            magic_expected = "PDF (%PDF)"

        if not is_magic_valid:
            reason = f"Corrupt or mismatched file: magic bytes do not match expected {magic_expected} header."
            logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
            dynamodb_manager.mark_failed(
                document_id=document_id,
                failure_reason=reason,
                error_step="VALIDATION",
                stages=stages
            )
            processed_results.append({
                "document_id": document_id,
                "status": "FAILED",
                "reason": reason,
                "stages": stages
            })
            continue

        # 4e: For PDFs, count page count using pypdf (reject > 1 page)
        if file_ext == ".pdf":
            try:
                import io
                from pypdf import PdfReader  # type: ignore
                reader = PdfReader(io.BytesIO(file_bytes))
                page_count = len(reader.pages)
                if page_count > 1:
                    reason = f"Multi-page PDF rejected: Textract synchronous processing supports single-page documents only (found {page_count} pages)."
                    logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
                    dynamodb_manager.mark_failed(
                        document_id=document_id,
                        failure_reason=reason,
                        error_step="VALIDATION",
                        stages=stages
                    )
                    processed_results.append({
                        "document_id": document_id,
                        "status": "FAILED",
                        "reason": reason,
                        "stages": stages
                    })
                    continue
                elif page_count == 0:
                    reason = "Empty PDF document rejected: document contains 0 pages."
                    logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
                    dynamodb_manager.mark_failed(
                        document_id=document_id,
                        failure_reason=reason,
                        error_step="VALIDATION",
                        stages=stages
                    )
                    processed_results.append({
                        "document_id": document_id,
                        "status": "FAILED",
                        "reason": reason,
                        "stages": stages
                    })
                    continue
            except Exception as pdf_err:
                reason = f"Corrupt PDF document cannot be parsed: {type(pdf_err).__name__}"
                logger.warning(f"Step 4 Validation Failed for {document_id}: {reason}")
                dynamodb_manager.mark_failed(
                    document_id=document_id,
                    failure_reason=reason,
                    error_step="VALIDATION",
                    stages=stages
                )
                processed_results.append({
                    "document_id": document_id,
                    "status": "FAILED",
                    "reason": reason,
                    "stages": stages
                })
                continue

        # Validation succeeded - record validated stage (F18)
        val_duration_ms = max(0, int((time.time() - validation_start) * 1000))
        val_now = datetime.now(timezone.utc).isoformat()
        stages.append({
            "stage": "validated",
            "at": val_now,
            "timestamp": val_now,
            "service": "S3",
            "duration_ms": val_duration_ms,
            "ms": val_duration_ms,
            "items": len(file_bytes)
        })

        try:
            # Step 5: Text extraction using AWS Textract
            ocr_start = time.time()
            if _check_timeout(context, document_id, "TEXT_EXTRACTION", stages=stages):
                processed_results.append({
                    "document_id": document_id,
                    "status": "FAILED",
                    "reason": "Execution timed out before text extraction",
                    "error_step": "TIMEOUT",
                    "stages": stages
                })
                continue

            logger.info(f"Step 5: Extracting text using AWS Textract for {document_id}")
            try:
                extracted_text, text_metadata = text_extractor.extract_text_from_s3(
                    bucket=bucket_name,
                    key=object_key
                )
            except TextractDocumentError as doc_err:
                reason = str(doc_err)
                logger.warning(f"Step 5 Text Extraction rejected for {document_id}: {reason}")
                dynamodb_manager.mark_failed(
                    document_id=document_id,
                    failure_reason=reason,
                    error_step="TEXT_EXTRACTION",
                    stages=stages
                )
                processed_results.append({
                    "document_id": document_id,
                    "status": "FAILED",
                    "reason": reason,
                    "stages": stages
                })
                continue

            # Check if any text was found
            if not extracted_text or not extracted_text.strip():
                reason = "No readable text detected in document by Textract OCR."
                logger.warning(f"Step 5 Validation Failed for {document_id}: {reason}")
                dynamodb_manager.mark_failed(
                    document_id=document_id,
                    failure_reason=reason,
                    error_step="TEXT_EXTRACTION",
                    stages=stages
                )
                processed_results.append({
                    "document_id": document_id,
                    "status": "FAILED",
                    "reason": reason,
                    "stages": stages
                })
                continue

            # OCR succeeded - record ocr_done stage (F18)
            ocr_duration_ms = max(0, int((time.time() - ocr_start) * 1000))
            ocr_now = datetime.now(timezone.utc).isoformat()
            line_count = (text_metadata or {}).get("line_count") or len([l for l in extracted_text.splitlines() if l.strip()])
            stages.append({
                "stage": "ocr_done",
                "at": ocr_now,
                "timestamp": ocr_now,
                "service": "Textract",
                "duration_ms": ocr_duration_ms,
                "ms": ocr_duration_ms,
                "items": int(line_count)
            })

            # Check S3 metadata for custom keywords (additive only, server-controlled masking policy)
            custom_keywords = None
            try:
                head_res = s3_client.head_object(Bucket=bucket_name, Key=object_key)
                s3_meta = head_res.get("Metadata", {})
                if "custom-keywords" in s3_meta and s3_meta["custom-keywords"].strip():
                    custom_keywords = [k.strip() for k in s3_meta["custom-keywords"].split(",") if k.strip()]
            except Exception as meta_err:
                logger.debug(f"Could not retrieve S3 metadata: {meta_err}")

            # Step 6 & 7: PII detection and redaction using AWS Comprehend (always masks every PII entity above threshold)
            pii_start = time.time()
            if _check_timeout(context, document_id, "PII_DETECTION", stages=stages):
                processed_results.append({
                    "document_id": document_id,
                    "status": "FAILED",
                    "reason": "Execution timed out before PII detection",
                    "error_step": "TIMEOUT",
                    "stages": stages
                })
                continue

            logger.info(f"Step 6 & 7: Detecting PII and redacting with Comprehend for {document_id}")
            redacted_text, detected_entities, pii_counts = pii_redactor.detect_and_redact(
                text=extracted_text,
                language_code="en",
                custom_keywords=custom_keywords
            )
            total_pii_count = sum(pii_counts.values())

            # PII detection succeeded - record pii_done stage (F18)
            pii_duration_ms = max(0, int((time.time() - pii_start) * 1000))
            pii_now = datetime.now(timezone.utc).isoformat()
            stages.append({
                "stage": "pii_done",
                "at": pii_now,
                "timestamp": pii_now,
                "service": "Comprehend",
                "duration_ms": pii_duration_ms,
                "ms": pii_duration_ms,
                "items": int(total_pii_count)
            })

            # Step 8: Storage - Save hidden text to processed S3 bucket and update DynamoDB
            storage_start = time.time()
            if _check_timeout(context, document_id, "STORAGE", stages=stages):
                processed_results.append({
                    "document_id": document_id,
                    "status": "FAILED",
                    "reason": "Execution timed out before storage",
                    "error_step": "TIMEOUT",
                    "stages": stages
                })
                continue

            processed_bucket = os.environ.get("PROCESSED_BUCKET_NAME")
            if not processed_bucket:
                raise ValueError("PROCESSED_BUCKET_NAME environment variable is not configured")

            processed_text_key = f"redacted/{document_id}.txt"
            processed_meta_key = f"metadata/{document_id}.metadata.json"

            # 8a: Write redacted text to processed S3 bucket
            logger.info(f"Step 8a: Uploading redacted text for {document_id}")
            s3_client.put_object(
                Bucket=processed_bucket,
                Key=processed_text_key,
                Body=redacted_text.encode("utf-8"),
                ContentType="text/plain; charset=utf-8",
                Metadata={
                    "original-document-id": document_id,
                    "pii-count": str(total_pii_count),
                    "pipeline-version": "1.0"
                }
            )

            # Record stored stage before audit metadata is written (F18)
            storage_duration_ms = max(0, int((time.time() - storage_start) * 1000))
            storage_now = datetime.now(timezone.utc).isoformat()
            stages.append({
                "stage": "stored",
                "at": storage_now,
                "timestamp": storage_now,
                "service": "S3",
                "duration_ms": storage_duration_ms,
                "ms": storage_duration_ms,
                "items": len(redacted_text)
            })

            # 8b: Write audit/metadata JSON (never storing raw PII, only metadata summary)
            audit_metadata = {
                "document_id": document_id,
                "file_name_hash": hashlib.sha256(file_name.encode("utf-8")).hexdigest()[:16],
                "raw_bucket": bucket_name,
                "raw_key_hash": hashlib.sha256(object_key.encode("utf-8")).hexdigest()[:16],
                "processed_bucket": processed_bucket,
                "processed_text_key": processed_text_key,
                "processed_timestamp": datetime.now(timezone.utc).isoformat(),
                "extraction_metadata": text_metadata,
                "ocr_engine": "textract",
                "pii_engine": "comprehend",
                "total_pii_detected": total_pii_count,
                "pii_counts_by_type": pii_counts,
                "entities_detected_count": len(detected_entities),
                "text_length_raw": len(extracted_text),
                "text_length_redacted": len(redacted_text),
                "stages": stages,
            }
            s3_client.put_object(
                Bucket=processed_bucket,
                Key=processed_meta_key,
                Body=json.dumps(_from_decimal(audit_metadata), indent=2).encode("utf-8"),
                ContentType="application/json"
            )

            # 8c: Update DynamoDB to COMPLETED with PII counts and stages
            duration_ms = int((time.time() - start_time) * 1000)
            dynamodb_manager.mark_completed(
                document_id=document_id,
                processed_bucket=processed_bucket,
                processed_key=processed_text_key,
                metadata_key=processed_meta_key,
                pii_count=total_pii_count,
                pii_types_found=pii_counts,
                text_length_raw=len(extracted_text),
                text_length_redacted=len(redacted_text),
                execution_duration_ms=duration_ms,
                ocr_engine="textract",
                pii_engine="comprehend",
                stages=stages
            )

            processed_results.append({
                "document_id": document_id,
                "status": "COMPLETED",
                "pii_count": total_pii_count,
                "processed_key": processed_text_key,
                "duration_ms": duration_ms,
                "stages": stages
            })
            logger.info(f"Pipeline successfully completed for {document_id} in {duration_ms}ms")

        except Exception as e:
            # Step 10: Unhandled failure handling
            # Record failure in DynamoDB best-effort, then re-raise exception so AWS Lambda
            # performs automatic asynchronous retries and sends to the SQS Dead-Letter Queue.
            err_cls = type(e).__name__
            logger.error(
                f"Unhandled error processing document {document_id}: {err_cls}. "
                f"Re-raising exception for Lambda retry & SQS DLQ routing."
            )
            try:
                dynamodb_manager.mark_failed(
                    document_id=document_id,
                    failure_reason=f"Unhandled pipeline exception: {_scrub_error_message(e)}",
                    error_step="EXECUTION_ERROR",
                    stages=stages
                )
            except Exception as db_err:
                logger.error(f"Failed to record unhandled failure in DynamoDB for {document_id}: {type(db_err).__name__}")

            # Re-raising is critical for Lambda EventInvokeConfig DLQ to trigger
            raise

    return {
        "statusCode": 200,
        "processed_count": len(processed_results),
        "results": processed_results
    }
