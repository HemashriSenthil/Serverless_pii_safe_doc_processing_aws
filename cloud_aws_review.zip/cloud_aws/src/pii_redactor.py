import re
import logging
import boto3
from typing import List, Dict, Any, Tuple, Optional
from collections import Counter
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

PRIORITY_MAP = {
    "MASKED_TEXT": 10,
    "PASSWORD": 9,
    "AWS_ACCESS_KEY": 9,
    "AWS_SECRET_KEY": 9,
    "EMAIL": 9,
    "PHONE": 8,
    "URL": 8,
    "IP_ADDRESS": 8,
    "MAC_ADDRESS": 8,
    "ID_NUMBER": 7,
    "OTHER": 7,
    "ID": 7,
    "SSN": 7,
    "NAME": 6,
    "USERNAME": 6,
    "DOB": 5,
    "DATE": 5,
    "DATE_TIME": 5,
    "ADDRESS": 4
}


class PiiRedactor:
    def __init__(self, comprehend_client = None, min_confidence_score: float = 0.5):
        self.comprehend = comprehend_client or boto3.client("comprehend")
        self.min_confidence_score = min_confidence_score
        # Max chunk size for AWS Comprehend detect_pii_entities is 100,000 bytes
        self.max_chunk_bytes = 80000

    def detect_and_redact(
        self,
        text: str,
        language_code: str = "en",
        allowed_types: Optional[List[str]] = None,
        custom_keywords: Optional[List[str]] = None,
        mask_mode: str = "LABEL"
    ) -> Tuple[str, List[Dict[str, Any]], Dict[str, int]]:
        """
        Steps 6 & 7: Detects PII entities using AWS Comprehend and masks them.
        Default-deny server-enforced policy: every detected entity above the confidence threshold
        is masked. Custom keywords are additive only.
        Supports:
            - mask_mode="LABEL" (default): masks with [TYPE] labels (e.g. [NAME], [SSN], [PHONE])
            - mask_mode="ASTERISK": masks with fixed-length asterisks (*****) preventing length leakage
            - custom_keywords: additive terms to mask
        Returns:
            - redacted_text: The safely masked document text.
            - detected_entities: Full list of detected entity objects with types, scores, and offsets.
            - pii_counts: Counter mapping each PII type to its occurrence count.
        """
        if not text or not text.strip():
            return text, [], {}

        # 1. Detect PII entities (handling large texts via chunking if needed)
        entities = self._detect_pii_with_chunking(text, language_code)

        # 1b. Add custom keywords if specified (additive only)
        if custom_keywords:
            for kw in custom_keywords:
                kw_clean = kw.strip()
                if not kw_clean:
                    continue
                for m in re.finditer(re.escape(kw_clean), text, re.IGNORECASE):
                    entities.append({
                        "Type": "MASKED_TEXT",
                        "Score": 1.0,
                        "BeginOffset": m.start(),
                        "EndOffset": m.end()
                    })

        # 2. Filter by minimum confidence score (server-controlled default-deny)
        valid_entities = [
            e for e in entities 
            if e.get("Score", 0.0) >= self.min_confidence_score
        ]

        # 2b. Map Comprehend / Legacy entity types
        id_types = {
            "OTHER", "ID", "PASSPORT_NUMBER", "DRIVER_ID", "BANK_ACCOUNT_NUMBER",
            "BANK_ROUTING", "CREDIT_DEBIT_NUMBER", "CREDIT_DEBIT_CVV", "PIN",
            "SWIFT_CODE", "INTERNATIONAL_BANK_ACCOUNT_NUMBER", "IN_AADHAAR",
            "IN_PAN", "IN_VOTER_ID", "TAX_ID", "VEHICLE_IDENTIFICATION_NUMBER"
        }
        for e in valid_entities:
            t = e.get("Type", "")
            if t in id_types:
                e["Type"] = "ID_NUMBER"
            elif t == "DATE_TIME":
                start_idx = e.get("BeginOffset", 0)
                preceding_text = text[max(0, start_idx - 30):start_idx].lower()
                if any(k in preceding_text for k in ["birth", "dob", "born"]):
                    e["Type"] = "DOB"
                else:
                    e["Type"] = "DATE"

        # 3. Resolve and deduplicate any overlapping entity spans using union-merge
        non_overlapping_entities = self._resolve_overlapping_spans(valid_entities)

        # 4. Count occurrences of each entity type
        pii_counts = dict(Counter(e["Type"] for e in non_overlapping_entities))

        # 5. Redact text from right to left (descending BeginOffset)
        # Slicing from end to start guarantees offset indices remain strictly valid
        redacted_text = text
        sorted_for_redaction = sorted(non_overlapping_entities, key=lambda x: x["BeginOffset"], reverse=True)

        for entity in sorted_for_redaction:
            start = entity["BeginOffset"]
            end = entity["EndOffset"]
            entity_type = entity["Type"]

            if mask_mode and mask_mode.upper() == "ASTERISK":
                replacement = "*****"  # Fixed-length mask so exact length is never leaked
            else:
                replacement = f"[{entity_type}]"

            # Apply replacement
            redacted_text = redacted_text[:start] + replacement + redacted_text[end:]

        logger.info(
            f"PII Redaction complete. Detected {len(valid_entities)} entities, "
            f"applied {len(non_overlapping_entities)} non-overlapping redactions. Summary: {pii_counts}"
        )

        return redacted_text, non_overlapping_entities, pii_counts

    def _detect_pii_with_chunking(self, text: str, language_code: str) -> List[Dict[str, Any]]:
        """
        Handles texts that might exceed Comprehend's 100KB UTF-8 payload limit by chunking on newlines.
        """
        text_bytes = len(text.encode("utf-8"))
        if text_bytes <= self.max_chunk_bytes:
            return self._call_comprehend_detect_pii(text, language_code, offset_delta=0)

        logger.info(f"Text size ({text_bytes} bytes) exceeds {self.max_chunk_bytes} limit, chunking...")
        chunks = []
        current_chunk = []
        current_bytes = 0
        current_offset = 0
        all_entities = []

        lines = text.splitlines(keepends=True)
        chunk_start_char = 0
        accumulated_chars = 0

        for line in lines:
            line_bytes = len(line.encode("utf-8"))
            if current_bytes + line_bytes > self.max_chunk_bytes and current_chunk:
                chunk_str = "".join(current_chunk)
                entities = self._call_comprehend_detect_pii(chunk_str, language_code, offset_delta=chunk_start_char)
                all_entities.extend(entities)
                current_chunk = [line]
                current_bytes = line_bytes
                chunk_start_char = accumulated_chars
            else:
                current_chunk.append(line)
                current_bytes += line_bytes
            accumulated_chars += len(line)

        if current_chunk:
            chunk_str = "".join(current_chunk)
            entities = self._call_comprehend_detect_pii(chunk_str, language_code, offset_delta=chunk_start_char)
            all_entities.extend(entities)

        return all_entities

    def _call_comprehend_detect_pii(self, text_chunk: str, language_code: str, offset_delta: int) -> List[Dict[str, Any]]:
        """
        Calls AWS Comprehend detect_pii_entities and shifts returned character offsets by offset_delta.
        """
        try:
            response = self.comprehend.detect_pii_entities(
                Text=text_chunk,
                LanguageCode=language_code
            )
            entities = response.get("Entities", [])
            adjusted_entities = []
            for e in entities:
                adj = dict(e)
                adj["BeginOffset"] = e["BeginOffset"] + offset_delta
                adj["EndOffset"] = e["EndOffset"] + offset_delta
                adjusted_entities.append(adj)
            return adjusted_entities
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            error_message = e.response.get("Error", {}).get("Message", str(e))
            if error_code == "SubscriptionRequiredException":
                logger.error(
                    "AWS Comprehend SubscriptionRequiredException encountered. "
                    "Comprehend is not activated for this account/region."
                )
                raise RuntimeError("Comprehend is not activated for this account/region") from e
            logger.error(f"Comprehend API Error [{error_code}]: {error_message}")
            raise

    @staticmethod
    def _resolve_overlapping_spans(entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Resolves overlapping intervals using union-merge.
        Sorts primarily by start offset ascending, then by end offset descending.
        Merges any overlapping intervals so that the entire contiguous span of PII is covered,
        retaining the highest-priority entity type for the merged span.
        """
        if not entities:
            return []

        spans = sorted(entities, key=lambda e: (e["BeginOffset"], -e["EndOffset"]))
        merged = []
        for e in spans:
            if merged and e["BeginOffset"] < merged[-1]["EndOffset"]:
                last = merged[-1]
                if e["EndOffset"] > last["EndOffset"]:
                    last["EndOffset"] = e["EndOffset"]
                if PRIORITY_MAP.get(e.get("Type", ""), 0) > PRIORITY_MAP.get(last.get("Type", ""), 0):
                    last["Type"] = e["Type"]
                if e.get("Score", 0.0) > last.get("Score", 0.0):
                    last["Score"] = e["Score"]
            else:
                merged.append(dict(e))
        return merged
