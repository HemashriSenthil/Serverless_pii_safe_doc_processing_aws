import logging
import boto3
from botocore.exceptions import ClientError
from typing import Tuple, Dict, Any

logger = logging.getLogger(__name__)

class TextractDocumentError(Exception):
    """Raised for non-retriable document errors (Unsupported, Bad, TooLarge, InvalidParameter)."""
    def __init__(self, code: str, message: str):
        super().__init__(f"Textract document error [{code}]: {message}")
        self.code = code
        self.message = message

class TextExtractor:
    def __init__(self, textract_client = None):
        self.textract = textract_client or boto3.client("textract")

    def extract_text_from_s3(self, bucket: str, key: str) -> Tuple[str, Dict[str, Any]]:
        """
        Step 5: Invokes AWS Textract synchronously to extract text from a document in S3.
        Returns the concatenated line text and extraction metadata (line count, word count, confidence).
        """
        logger.info(f"Calling Textract detect_document_text for bucket {bucket}")
        try:
            response = self.textract.detect_document_text(
                Document={
                    "S3Object": {
                        "Bucket": bucket,
                        "Name": key
                    }
                }
            )
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            error_message = e.response.get("Error", {}).get("Message", str(e))
            if error_code == "SubscriptionRequiredException":
                logger.error(
                    f"AWS Textract SubscriptionRequiredException encountered for bucket {bucket}. "
                    "Textract is not activated for this account/region."
                )
                raise RuntimeError("Textract is not activated for this account/region") from e

            # Non-retriable document errors: classify as TextractDocumentError (F10)
            if error_code in (
                "UnsupportedDocumentException",
                "BadDocumentException",
                "DocumentTooLargeException",
                "InvalidParameterException"
            ):
                logger.warning(f"Textract non-retriable document error [{error_code}]: {error_message}")
                raise TextractDocumentError(error_code, error_message) from e

            # Throttling and 5xx errors: re-raise to trigger Lambda retry and SQS DLQ
            logger.error(f"Textract operational/transient API Error [{error_code}]: {error_message}")
            raise

        blocks = response.get("Blocks", [])
        lines = []
        confidences = []
        word_count = 0

        for block in blocks:
            block_type = block.get("BlockType")
            if block_type == "LINE":
                text = block.get("Text", "").strip()
                if text:
                    lines.append(text)
                if "Confidence" in block:
                    confidences.append(block["Confidence"])
            elif block_type == "WORD":
                word_count += 1

        full_text = "\n".join(lines).strip()
        avg_confidence = (sum(confidences) / len(confidences)) if confidences else 0.0

        metadata = {
            "total_blocks": len(blocks),
            "line_count": len(lines),
            "word_count": word_count,
            "average_confidence": round(avg_confidence, 2),
            "ocr_engine": "textract",
        }

        logger.info(
            f"Extracted {len(lines)} lines, {word_count} words from bucket {bucket} "
            f"with {avg_confidence:.1f}% average confidence."
        )
        return full_text, metadata
