import os
import logging
import hashlib
from typing import Tuple, Optional, Any, Dict, List
from decimal import Decimal
from datetime import datetime, timezone
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

def _to_decimal(obj) -> Any:
    """
    Recursively converts float values to Decimal for DynamoDB serialization.
    """
    if isinstance(obj, float):
        return Decimal(str(obj))
    if isinstance(obj, dict):
        return {k: _to_decimal(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_to_decimal(v) for v in obj]
    return obj

class DynamoDBManager:
    def __init__(self, table_name: Optional[str] = None, dynamodb_resource = None):
        self.table_name = table_name or os.environ.get("TABLE_NAME")
        if not self.table_name:
            raise ValueError("DynamoDB TABLE_NAME environment variable is required")
        self.dynamodb: Any = dynamodb_resource or boto3.resource("dynamodb")
        self.table: Any = self.dynamodb.Table(self.table_name)

    def create_processing_record(
        self,
        document_id: str,
        file_name: str,
        raw_bucket: str,
        raw_key: str,
        file_size_bytes: int,
        file_type: str,
        max_attempts: int = 3,
        lambda_request_id: Optional[str] = None
    ) -> Tuple[dict, bool]:
        """
        Step 3: Creates the initial DynamoDB record with status 'PROCESSING' using
        conditional writes (attribute_not_exists(document_id)) to guarantee idempotency.
        
        Returns (item, should_process):
          - (item, True): Newly created or resumed retry, proceed with processing.
          - (item, False): Duplicate event or terminal state, skip processing.
        """
        now = datetime.now(timezone.utc).isoformat()
        file_name_hash = hashlib.sha256(file_name.encode("utf-8")).hexdigest()[:16]
        raw_key_hash = hashlib.sha256(raw_key.encode("utf-8")).hexdigest()[:16]

        uploaded_stage = {
            "stage": "uploaded",
            "at": now,
            "timestamp": now,
            "service": "S3",
            "duration_ms": 0,
            "ms": 0,
            "items": file_size_bytes
        }

        item = {
            "document_id": document_id,
            "status": "PROCESSING",
            "raw_bucket": raw_bucket,
            "file_type": file_type,
            "file_size_bytes": file_size_bytes,
            "file_name_hash": file_name_hash,
            "raw_key_hash": raw_key_hash,
            "upload_timestamp": now,
            "created_at": now,
            "updated_at": now,
            "processing_started_at": now,
            "lambda_request_id": lambda_request_id or "unknown",
            "attempts": 1,
            "pii_count": 0,
            "pii_types_found": {},
            "failure_reason": None,
            "stages": [uploaded_stage],
        }

        try:
            self.table.put_item(
                Item=_to_decimal(item),
                ConditionExpression="attribute_not_exists(document_id)"
            )
            logger.info(f"Created DynamoDB record for document_id={document_id} with status=PROCESSING")
            return item, True
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
                existing_res = self.table.get_item(Key={"document_id": document_id})
                existing_item = existing_res.get("Item", {})
                current_status = existing_item.get("status")
                attempts = int(existing_item.get("attempts", 1))

                if current_status == "COMPLETED":
                    logger.info(f"Document {document_id} already COMPLETED. Skipping duplicate event.")
                    return existing_item, False

                if current_status == "FAILED":
                    error_step = existing_item.get("error_step")
                    if error_step in ("VALIDATION", "TEXT_EXTRACTION") or attempts >= max_attempts:
                        logger.info(
                            f"Document {document_id} already in terminal FAILED state ({error_step}, attempts={attempts}). Skipping."
                        )
                        return existing_item, False

                    # Retriable execution error with attempts < max_attempts: resume processing
                    new_attempts = attempts + 1
                    update_res = self.table.update_item(
                        Key={"document_id": document_id},
                        UpdateExpression="SET #st = :st, attempts = :att, updated_at = :now, processing_started_at = :now, lambda_request_id = :lrid, failure_reason = :null",
                        ExpressionAttributeNames={"#st": "status"},
                        ExpressionAttributeValues={
                            ":st": "PROCESSING",
                            ":att": new_attempts,
                            ":now": now,
                            ":lrid": lambda_request_id or "unknown",
                            ":null": None
                        },
                        ReturnValues="ALL_NEW"
                    )
                    updated_item = update_res.get("Attributes", existing_item)
                    logger.info(f"Resuming document {document_id} for retry attempt {new_attempts}")
                    return updated_item, True

                if current_status == "PROCESSING":
                    new_attempts = attempts + 1
                    update_res = self.table.update_item(
                        Key={"document_id": document_id},
                        UpdateExpression="SET attempts = :att, updated_at = :now, processing_started_at = :now, lambda_request_id = :lrid",
                        ExpressionAttributeValues={
                            ":att": new_attempts,
                            ":now": now,
                            ":lrid": lambda_request_id or "unknown"
                        },
                        ReturnValues="ALL_NEW"
                    )
                    updated_item = update_res.get("Attributes", existing_item)
                    logger.info(f"Incremented attempts to {new_attempts} for PROCESSING document {document_id}")
                    return updated_item, True

                return existing_item, False

            logger.error(f"Failed to create DynamoDB record for {document_id}: {type(e).__name__}")
            raise

    def mark_failed(
        self,
        document_id: str,
        failure_reason: str,
        error_step: str = "VALIDATION",
        stages: Optional[list] = None
    ) -> bool:
        """
        Marks the record as FAILED with a descriptive reason.
        Enforces conditional write so a terminal status (COMPLETED) is never overwritten.
        """
        now = datetime.now(timezone.utc).isoformat()
        update_expr = "SET #st = :status, failure_reason = :reason, error_step = :step, updated_at = :updated_at"
        expr_values: Dict[str, Any] = {
            ":status": "FAILED",
            ":expected_status": "PROCESSING",
            ":reason": failure_reason,
            ":step": error_step,
            ":updated_at": now,
        }
        if stages is not None:
            update_expr += ", stages = :stages"
            expr_values[":stages"] = stages

        try:
            self.table.update_item(
                Key={"document_id": document_id},
                UpdateExpression=update_expr,
                ConditionExpression="#st = :expected_status",
                ExpressionAttributeNames={"#st": "status"},
                ExpressionAttributeValues=_to_decimal(expr_values)
            )
            logger.warning(f"Marked document {document_id} as FAILED at step {error_step}: {failure_reason}")
            return True
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
                logger.warning(
                    f"Could not mark document {document_id} as FAILED: current status is not PROCESSING (terminal status preserved)."
                )
                return False
            logger.error(f"Failed to update DynamoDB record to FAILED for {document_id}: {type(e).__name__}")
            raise

    def mark_completed(
        self,
        document_id: str,
        processed_bucket: str,
        processed_key: str,
        metadata_key: str,
        pii_count: int,
        pii_types_found: dict,
        text_length_raw: int,
        text_length_redacted: int,
        execution_duration_ms: int,
        ocr_engine: str = "textract",
        pii_engine: str = "comprehend",
        stages: Optional[list] = None
    ) -> bool:
        """
        Updates the record to COMPLETED with PII counts, S3 keys, and metrics.
        Enforces conditional write so only records in PROCESSING status can be completed.
        """
        now = datetime.now(timezone.utc).isoformat()
        update_expr = (
            "SET #st = :status, "
            "processed_bucket = :p_bucket, "
            "processed_key = :p_key, "
            "metadata_key = :m_key, "
            "pii_count = :count, "
            "pii_types_found = :types, "
            "text_length_raw = :raw_len, "
            "text_length_redacted = :red_len, "
            "execution_duration_ms = :duration, "
            "ocr_engine = :ocr_engine, "
            "pii_engine = :pii_engine, "
            "completed_at = :now, "
            "updated_at = :now"
        )
        expr_values: Dict[str, Any] = {
            ":status": "COMPLETED",
            ":expected_status": "PROCESSING",
            ":p_bucket": processed_bucket,
            ":p_key": processed_key,
            ":m_key": metadata_key,
            ":count": pii_count,
            ":types": pii_types_found,
            ":raw_len": text_length_raw,
            ":red_len": text_length_redacted,
            ":duration": execution_duration_ms,
            ":ocr_engine": ocr_engine,
            ":pii_engine": pii_engine,
            ":now": now,
        }
        if stages is not None:
            update_expr += ", stages = :stages"
            expr_values[":stages"] = stages

        try:
            self.table.update_item(
                Key={"document_id": document_id},
                UpdateExpression=update_expr,
                ConditionExpression="#st = :expected_status",
                ExpressionAttributeNames={"#st": "status"},
                ExpressionAttributeValues=_to_decimal(expr_values)
            )
            logger.info(f"Marked document {document_id} as COMPLETED. Redacted {pii_count} PII entities.")
            return True
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
                logger.warning(
                    f"Could not mark document {document_id} as COMPLETED: status is not PROCESSING."
                )
                return False
            logger.error(f"Failed to update DynamoDB record to COMPLETED for {document_id}: {type(e).__name__}")
            raise

    def get_document_record(self, document_id: str) -> dict:
        """
        Fetches the current status and metadata of a document.
        """
        try:
            response = self.table.get_item(Key={"document_id": document_id})
            return response.get("Item")
        except ClientError as e:
            logger.error(f"Failed to fetch record for {document_id}: {type(e).__name__}")
            raise

    def query_by_status(
        self,
        status: str,
        limit: int = 50,
        scan_index_forward: bool = False,
        exclusive_start_key: Optional[dict] = None
    ) -> Tuple[list, Optional[dict]]:
        """
        F12: Queries StatusIndex GSI for records with the given status,
        ordered by upload_timestamp (descending by default for newest first).
        Returns (items, last_evaluated_key).
        """
        kwargs: Dict[str, Any] = {
            "IndexName": "StatusIndex",
            "KeyConditionExpression": Key("status").eq(status),
            "ScanIndexForward": scan_index_forward,
            "Limit": limit,
        }
        if exclusive_start_key:
            kwargs["ExclusiveStartKey"] = exclusive_start_key

        try:
            res = self.table.query(**kwargs)
            return res.get("Items", []), res.get("LastEvaluatedKey")
        except ClientError as e:
            logger.warning(f"GSI query failed for status {status}: {e}. Falling back to scan.")
            scan_kwargs: Dict[str, Any] = {
                "FilterExpression": Key("status").eq(status),
                "Limit": limit,
            }
            if exclusive_start_key:
                scan_kwargs["ExclusiveStartKey"] = exclusive_start_key
            scan_res = self.table.scan(**scan_kwargs)
            items = scan_res.get("Items", [])
            items.sort(key=lambda x: str(x.get("upload_timestamp", "")), reverse=not scan_index_forward)
            return items, scan_res.get("LastEvaluatedKey")

    def count_by_status(self, status: str) -> int:
        """
        F12: Counts items for a given status using paginated GSI Query with Select="COUNT".
        """
        try:
            count = 0
            kwargs = {
                "IndexName": "StatusIndex",
                "KeyConditionExpression": Key("status").eq(status),
                "Select": "COUNT",
            }
            while True:
                res = self.table.query(**kwargs)
                count += res.get("Count", 0)
                lek = res.get("LastEvaluatedKey")
                if not lek:
                    break
                kwargs["ExclusiveStartKey"] = lek
            return count
        except ClientError as e:
            logger.warning(f"GSI count query failed for status {status}: {e}. Falling back to scan.")
            count = 0
            scan_kwargs = {
                "FilterExpression": Key("status").eq(status),
                "Select": "COUNT",
            }
            res = self.table.scan(**scan_kwargs)
            count += res.get("Count", 0)
            while "LastEvaluatedKey" in res:
                scan_kwargs["ExclusiveStartKey"] = res["LastEvaluatedKey"]
                res = self.table.scan(**scan_kwargs)
                count += res.get("Count", 0)
            return count

