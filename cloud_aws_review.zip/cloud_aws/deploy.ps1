# PowerShell Deployment Script for Serverless PII-Safe Document Processing Pipeline
param(
    [string]$StackName = "pii-safe-pipeline",
    [string]$Region = "us-east-1",
    [string]$Environment = "dev",
    [string]$AlertEmail = "",
    [int]$RetentionDays = 1
)

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host " Deploying PII-Safe Document Processing Pipeline to AWS ($Region)" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# 1. Check prerequisites and caller identity
Write-Host "`n[*] Checking AWS CLI and SAM CLI versions..." -ForegroundColor Yellow
aws --version
sam --version

Write-Host "`n[*] Verifying AWS caller identity (aws sts get-caller-identity)..." -ForegroundColor Yellow
aws sts get-caller-identity
if ($LASTEXITCODE -ne 0) {
    Write-Host "[!] Error: Failed to resolve AWS caller identity. Check your credentials or AWS_PROFILE." -ForegroundColor Red
    exit 1
}

# 2. Validate SAM template with linting
Write-Host "`n[*] Validating template with 'sam validate --lint'..." -ForegroundColor Yellow
sam validate --lint
if ($LASTEXITCODE -ne 0) {
    Write-Host "[!] Error: 'sam validate --lint' failed." -ForegroundColor Red
    exit 1
}

# 3. Check AlertEmail
if ([string]::IsNullOrWhiteSpace($AlertEmail)) {
    Write-Host "`n[!] WARNING: AlertEmail parameter is empty. Failure alerts via SNS topic will have NO email subscribers." -ForegroundColor Yellow
    Write-Host "    To enable email alerting, supply your address: .\deploy.ps1 -AlertEmail your-email@example.com" -ForegroundColor Yellow
} else {
    Write-Host "`n[*] SNS Failure Alerts will be sent to: $AlertEmail" -ForegroundColor Green
    Write-Host "    NOTE: AWS sends a subscription confirmation email. Please click the confirmation link to activate alerts." -ForegroundColor Green
}

# 4. Build SAM application
Write-Host "`n[*] Building SAM application with 'sam build'..." -ForegroundColor Yellow
sam build
if ($LASTEXITCODE -ne 0) {
    Write-Host "[!] Error: 'sam build' failed." -ForegroundColor Red
    exit 1
}

# 5. Construct parameter overrides
$paramOverrides = "Environment=$Environment RawFileRetentionDays=$RetentionDays"
if (-not [string]::IsNullOrWhiteSpace($AlertEmail)) {
    $paramOverrides += " AlertEmail=$AlertEmail"
}

# 6. Deploy SAM stack
Write-Host "`n[*] Deploying CloudFormation stack: $StackName (Environment: $Environment)..." -ForegroundColor Yellow
sam deploy `
    --stack-name $StackName `
    --region $Region `
    --capabilities CAPABILITY_IAM CAPABILITY_AUTO_EXPAND `
    --resolve-s3 `
    --parameter-overrides $paramOverrides `
    --no-confirm-changeset `
    --no-fail-on-empty-changeset

if ($LASTEXITCODE -ne 0) {
    Write-Host "[!] Error: 'sam deploy' failed." -ForegroundColor Red
    exit 1
}

# 7. Fetch Outputs
Write-Host "`n[+] Deployment Succeeded! Stack Outputs:" -ForegroundColor Green
aws cloudformation describe-stacks `
    --stack-name $StackName `
    --region $Region `
    --query "Stacks[0].Outputs" `
    --output table

Write-Host "`nNext Steps:" -ForegroundColor Cyan
Write-Host "1. Run local dashboard: python scripts/dashboard_server.py" -ForegroundColor White
Write-Host "2. Upload sample docs:   python scripts/upload_and_monitor.py --all" -ForegroundColor White
Write-Host "3. Test failure / DLQ:   python scripts/simulate_failure.py" -ForegroundColor White
