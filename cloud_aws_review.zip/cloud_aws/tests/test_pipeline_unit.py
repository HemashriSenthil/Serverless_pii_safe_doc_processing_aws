import os
import sys
import json
import base64
import hashlib
import urllib.parse
import pytest
from unittest.mock import MagicMock, patch
from decimal import Decimal
from botocore.exceptions import ClientError
from botocore.config import Config  # type: ignore
from moto import mock_aws  # type: ignore
import boto3  # type: ignore
from typing import Any, Optional

# Set dummy credentials before boto3 or pipeline_handler initialization
os.environ["AWS_ACCESS_KEY_ID"] = "testing"
os.environ["AWS_SECRET_ACCESS_KEY"] = "testing"
os.environ["AWS_SECURITY_TOKEN"] = "testing"
os.environ["AWS_SESSION_TOKEN"] = "testing"
os.environ["AWS_DEFAULT_REGION"] = "us-east-1"
os.environ["TABLE_NAME"] = "test-document-tracking"
os.environ["RAW_BUCKET_NAME"] = "test-raw-bucket"
os.environ["PROCESSED_BUCKET_NAME"] = "test-processed-bucket"

# Add src and scripts to python path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "scripts")))

try:
    from pii_redactor import PiiRedactor  # type: ignore
    from dynamodb_manager import _to_decimal, DynamoDBManager  # type: ignore
    from text_extractor import TextExtractor  # type: ignore
    import pipeline_handler  # type: ignore
    import dashboard_server  # type: ignore
except ImportError:
    from src.pii_redactor import PiiRedactor  # type: ignore
    from src.dynamodb_manager import _to_decimal, DynamoDBManager  # type: ignore
    from src.text_extractor import TextExtractor  # type: ignore
    import src.pipeline_handler as pipeline_handler  # type: ignore
    import scripts.dashboard_server as dashboard_server  # type: ignore


@pytest.fixture
def moto_environment():
    """Sets up a moto mock environment for S3 and DynamoDB."""
    with mock_aws():
        dynamodb: Any = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName="test-document-tracking",
            KeySchema=[{"AttributeName": "document_id", "KeyType": "HASH"}],
            AttributeDefinitions=[
                {"AttributeName": "document_id", "AttributeType": "S"},
                {"AttributeName": "status", "AttributeType": "S"},
                {"AttributeName": "upload_timestamp", "AttributeType": "S"}
            ],
            GlobalSecondaryIndexes=[
                {
                    "IndexName": "StatusIndex",
                    "KeySchema": [
                        {"AttributeName": "status", "KeyType": "HASH"},
                        {"AttributeName": "upload_timestamp", "KeyType": "RANGE"}
                    ],
                    "Projection": {"ProjectionType": "ALL"}
                }
            ],
            BillingMode="PAY_PER_REQUEST"
        )
        s3 = boto3.client("s3", region_name="us-east-1", config=Config(signature_version="s3v4"))
        s3.create_bucket(Bucket="test-raw-bucket")
        s3.create_bucket(Bucket="test-processed-bucket")

        # Point handler dependencies to this mock
        pipeline_handler.dynamodb_manager.dynamodb = dynamodb
        pipeline_handler.dynamodb_manager.table = table
        pipeline_handler.s3_client = s3
        dashboard_server._CACHED_RESOURCES = {
            "RawBucketName": "test-raw-bucket",
            "ProcessedBucketName": "test-processed-bucket",
            "DocumentTrackingTableName": "test-document-tracking",
            "PipelineDeadLetterQueueUrl": "https://sqs.us-east-1.amazonaws.com/123456789012/test-dlq"
        }
        dashboard_server._CACHED_TIME = 9999999999
        dashboard_server.invalidate_items_cache()

        yield {
            "s3": s3,
            "dynamodb": dynamodb,
            "table": table,
            "raw_bucket": "test-raw-bucket",
            "processed_bucket": "test-processed-bucket",
        }


def make_s3_event(bucket: str, key: str, size: int = 1024, sequencer: Optional[str] = None, etag: Optional[str] = None):
    obj = {"key": key, "size": size}
    if sequencer:
        obj["sequencer"] = sequencer
    if etag:
        obj["eTag"] = etag
    return {
        "Records": [
            {
                "s3": {
                    "bucket": {"name": bucket},
                    "object": obj
                }
            }
        ]
    }


def make_valid_png() -> bytes:
    return b"\x89PNG\r\n\x1a\n" + b"\x00" * 128


def make_valid_jpg() -> bytes:
    return b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00" + b"\x00" * 128


def make_valid_pdf(pages: int = 1) -> bytes:
    import io
    from pypdf import PdfWriter  # type: ignore
    writer = PdfWriter()
    for _ in range(pages):
        writer.add_blank_page(width=72, height=72)
    bio = io.BytesIO()
    writer.write(bio)
    return bio.getvalue()


def test_decimal_conversion():
    data = {
        "float_val": 99.85,
        "nested": {"score": 0.999, "items": [1.5, 2.0, "text"]},
        "int_val": 42,
        "str_val": "hello"
    }
    converted = _to_decimal(data)
    assert isinstance(converted["float_val"], Decimal)
    assert isinstance(converted["nested"]["score"], Decimal)
    assert isinstance(converted["nested"]["items"][0], Decimal)
    assert converted["int_val"] == 42
    assert converted["str_val"] == "hello"


def test_redaction_algorithm_single_entity():
    mock_comprehend = MagicMock()
    text = "Hello, my name is John Doe and I am an applicant."
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "NAME", "Score": 0.98, "BeginOffset": 18, "EndOffset": 26}
        ]
    }

    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted_text, entities, counts = redactor.detect_and_redact(text)

    assert redacted_text == "Hello, my name is [NAME] and I am an applicant."
    assert counts == {"NAME": 1}
    assert len(entities) == 1


def test_redaction_algorithm_multiple_entities():
    mock_comprehend = MagicMock()
    text = "Contact Jane Doe at jane@example.com or call 555-0199."
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "NAME", "Score": 0.99, "BeginOffset": 8, "EndOffset": 16},
            {"Type": "EMAIL", "Score": 0.99, "BeginOffset": 20, "EndOffset": 36},
            {"Type": "PHONE", "Score": 0.95, "BeginOffset": 45, "EndOffset": 53},
        ]
    }

    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted_text, entities, counts = redactor.detect_and_redact(text)

    assert redacted_text == "Contact [NAME] at [EMAIL] or call [PHONE]."
    assert counts == {"NAME": 1, "EMAIL": 1, "PHONE": 1}


def test_redaction_resolves_overlapping_entities():
    mock_comprehend = MagicMock()
    text = "Address: 742 Evergreen Terrace, Springfield"
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "ADDRESS", "Score": 0.60, "BeginOffset": 9, "EndOffset": 12},
            {"Type": "ADDRESS", "Score": 0.95, "BeginOffset": 9, "EndOffset": 30},
        ]
    }

    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted_text, entities, counts = redactor.detect_and_redact(text)

    assert redacted_text == "Address: [ADDRESS], Springfield"
    assert len(entities) == 1
    assert counts["ADDRESS"] == 1


def test_text_extractor_line_parsing():
    mock_textract = MagicMock()
    mock_textract.detect_document_text.return_value = {
        "Blocks": [
            {"BlockType": "PAGE", "Id": "1"},
            {"BlockType": "LINE", "Text": "First Line of Document", "Confidence": 99.5},
            {"BlockType": "WORD", "Text": "First"},
            {"BlockType": "WORD", "Text": "Line"},
            {"BlockType": "LINE", "Text": "Second Line of Document", "Confidence": 98.2},
        ]
    }

    extractor = TextExtractor(textract_client=mock_textract)
    text, meta = extractor.extract_text_from_s3("dummy-bucket", "dummy-key.png")

    assert text == "First Line of Document\nSecond Line of Document"
    assert meta["line_count"] == 2
    assert meta["average_confidence"] == pytest.approx(98.85, 0.1)
    assert meta["ocr_engine"] == "textract"


def test_empty_text_handling():
    redactor = PiiRedactor(comprehend_client=MagicMock())
    redacted, entities, counts = redactor.detect_and_redact("")
    assert redacted == ""
    assert entities == []
    assert counts == {}


def test_text_extractor_subscription_required_raises():
    mock_textract = MagicMock()
    mock_textract.detect_document_text.side_effect = ClientError(
        {"Error": {"Code": "SubscriptionRequiredException", "Message": "Subscription required"}},
        "DetectDocumentText"
    )
    extractor = TextExtractor(textract_client=mock_textract)
    with pytest.raises(RuntimeError, match="Textract is not activated for this account/region"):
        extractor.extract_text_from_s3("test-bucket", "test-key.png")


def test_pii_redactor_subscription_required_raises():
    mock_comprehend = MagicMock()
    mock_comprehend.detect_pii_entities.side_effect = ClientError(
        {"Error": {"Code": "SubscriptionRequiredException", "Message": "Subscription required"}},
        "DetectPiiEntities"
    )
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    with pytest.raises(RuntimeError, match="Comprehend is not activated for this account/region"):
        redactor.detect_and_redact("Sample text that needs Comprehend")


def test_handler_textract_subscription_required(moto_environment):
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="applicant_id.png", Body=make_valid_png())

    mock_textract = MagicMock()
    mock_textract.detect_document_text.side_effect = ClientError(
        {"Error": {"Code": "SubscriptionRequiredException", "Message": "Subscription required"}},
        "DetectDocumentText"
    )
    pipeline_handler.text_extractor.textract = mock_textract

    event = make_s3_event(env["raw_bucket"], "applicant_id.png")
    with pytest.raises(RuntimeError, match="Textract is not activated"):
        pipeline_handler.lambda_handler(event, None)

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["error_step"] == "EXECUTION_ERROR"
    assert "Textract is not activated" in items[0]["failure_reason"]

    # Processed bucket must remain empty
    proc_objs = env["s3"].list_objects_v2(Bucket=env["processed_bucket"]).get("KeyCount", 0)
    assert proc_objs == 0


def test_handler_comprehend_subscription_required(moto_environment):
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="application.pdf", Body=make_valid_pdf(1))

    mock_textract = MagicMock()
    mock_textract.detect_document_text.return_value = {
        "Blocks": [
            {"BlockType": "LINE", "Text": "Applicant Name: John Doe", "Confidence": 99.0}
        ]
    }
    mock_comprehend = MagicMock()
    mock_comprehend.detect_pii_entities.side_effect = ClientError(
        {"Error": {"Code": "SubscriptionRequiredException", "Message": "Subscription required"}},
        "DetectPiiEntities"
    )

    pipeline_handler.text_extractor.textract = mock_textract
    pipeline_handler.pii_redactor.comprehend = mock_comprehend

    event = make_s3_event(env["raw_bucket"], "application.pdf")
    with pytest.raises(RuntimeError, match="Comprehend is not activated"):
        pipeline_handler.lambda_handler(event, None)

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["error_step"] == "EXECUTION_ERROR"
    assert "Comprehend is not activated" in items[0]["failure_reason"]

    # Processed bucket must remain empty
    proc_objs = env["s3"].list_objects_v2(Bucket=env["processed_bucket"]).get("KeyCount", 0)
    assert proc_objs == 0


@pytest.mark.parametrize("filename", ["scan_0042.jpg", "holiday_video.png", "blank.png", "my_invoice_photo.jpg"])
def test_handler_blank_png_never_reaches_completed(moto_environment, filename):
    env = moto_environment
    content = make_valid_jpg() if filename.endswith((".jpg", ".jpeg")) else make_valid_png()
    env["s3"].put_object(Bucket=env["raw_bucket"], Key=filename, Body=content)

    mock_textract = MagicMock()
    # Blank image returns no text lines
    mock_textract.detect_document_text.return_value = {"Blocks": []}
    pipeline_handler.text_extractor.textract = mock_textract

    event = make_s3_event(env["raw_bucket"], filename)
    res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    assert res["results"][0]["status"] == "FAILED"
    assert "No readable text detected" in res["results"][0]["reason"]

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["error_step"] == "TEXT_EXTRACTION"
    assert items[0]["status"] != "COMPLETED"

    proc_objs = env["s3"].list_objects_v2(Bucket=env["processed_bucket"]).get("KeyCount", 0)
    assert proc_objs == 0


def test_handler_happy_path_provenance(moto_environment):
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="license.png", Body=make_valid_png())

    mock_textract = MagicMock()
    mock_textract.detect_document_text.return_value = {
        "Blocks": [
            {"BlockType": "LINE", "Text": "Driver License DL-12345", "Confidence": 98.5},
            {"BlockType": "WORD", "Text": "Driver"},
            {"BlockType": "WORD", "Text": "License"},
        ]
    }
    mock_comprehend = MagicMock()
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "DRIVER_ID", "Score": 0.99, "BeginOffset": 15, "EndOffset": 23}
        ]
    }

    pipeline_handler.text_extractor.textract = mock_textract
    pipeline_handler.pii_redactor.comprehend = mock_comprehend

    event = make_s3_event(env["raw_bucket"], "license.png")
    res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    assert res["results"][0]["status"] == "COMPLETED"

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    record = items[0]
    assert record["status"] == "COMPLETED"
    assert record["ocr_engine"] == "textract"
    assert record["pii_engine"] == "comprehend"

    # Verify audit metadata JSON in processed bucket
    proc_listing = env["s3"].list_objects_v2(Bucket=env["processed_bucket"])
    keys = [o["Key"] for o in proc_listing.get("Contents", [])]
    meta_keys = [k for k in keys if k.startswith("metadata/")]
    assert len(meta_keys) == 1

    meta_obj = env["s3"].get_object(Bucket=env["processed_bucket"], Key=meta_keys[0])
    audit_data = json.loads(meta_obj["Body"].read().decode("utf-8"))
    assert audit_data["ocr_engine"] == "textract"
    assert audit_data["pii_engine"] == "comprehend"
    assert audit_data["extraction_metadata"]["ocr_engine"] == "textract"


def test_comprehend_detects_and_masks_pii_types():
    mock_comprehend = MagicMock()
    text = "User SSN: 555-01-9988 and phone 555-0199."
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "SSN", "Score": 0.99, "BeginOffset": 10, "EndOffset": 21},
            {"Type": "PHONE", "Score": 0.95, "BeginOffset": 32, "EndOffset": 40},
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted, entities, counts = redactor.detect_and_redact(text)

    assert "[SSN]" in redacted
    assert "[PHONE]" in redacted
    assert "555-01-9988" not in redacted
    assert "555-0199" not in redacted
    assert counts == {"SSN": 1, "PHONE": 1}


def test_allowed_types_cannot_reduce_masking():
    mock_comprehend = MagicMock()
    text = "Name: John Doe, Email: john@example.com, Phone: 555-0199"
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "NAME", "Score": 0.99, "BeginOffset": 6, "EndOffset": 14},
            {"Type": "EMAIL", "Score": 0.99, "BeginOffset": 23, "EndOffset": 39},
            {"Type": "PHONE", "Score": 0.95, "BeginOffset": 48, "EndOffset": 56},
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    # Pass an attempt to whitelist ONLY EMAIL
    redacted, entities, counts = redactor.detect_and_redact(text, allowed_types=["EMAIL"])

    # Default-deny server policy: allowed_types can no longer reduce masking
    assert "[EMAIL]" in redacted
    assert "[NAME]" in redacted
    assert "[PHONE]" in redacted
    assert "john@example.com" not in redacted
    assert "John Doe" not in redacted
    assert "555-0199" not in redacted
    assert counts == {"NAME": 1, "EMAIL": 1, "PHONE": 1}


def test_credentials_urls_and_in_aadhaar_masked():
    mock_comprehend = MagicMock()
    text = "Credentials: secret123, Key: AKIAIOSFODNN7EXAMPLE, Site: https://internal.corp, IP: 192.168.1.1, Aadhaar: 1234 5678 9012"
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "PASSWORD", "Score": 0.99, "BeginOffset": 13, "EndOffset": 22},
            {"Type": "AWS_ACCESS_KEY", "Score": 0.99, "BeginOffset": 29, "EndOffset": 49},
            {"Type": "URL", "Score": 0.95, "BeginOffset": 57, "EndOffset": 78},
            {"Type": "IP_ADDRESS", "Score": 0.95, "BeginOffset": 84, "EndOffset": 95},
            {"Type": "IN_AADHAAR", "Score": 0.99, "BeginOffset": 106, "EndOffset": 120},
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted, entities, counts = redactor.detect_and_redact(text)

    assert "secret123" not in redacted
    assert "AKIAIOSFODNN7EXAMPLE" not in redacted
    assert "https://internal.corp" not in redacted
    assert "192.168.1.1" not in redacted
    assert "1234 5678 9012" not in redacted

    assert "[PASSWORD]" in redacted
    assert "[AWS_ACCESS_KEY]" in redacted
    assert "[URL]" in redacted
    assert "[IP_ADDRESS]" in redacted
    assert "[ID_NUMBER]" in redacted  # IN_AADHAAR correctly mapped to ID_NUMBER
    assert counts["ID_NUMBER"] == 1


def test_date_time_not_labeled_dob_without_birth_keyword():
    mock_comprehend = MagicMock()
    text = "Invoice Date: 10/24/2026 and Date of Birth: 05/14/1990."
    # Offsets: "10/24/2026" (14 to 24), "05/14/1990" (44 to 54)
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "DATE_TIME", "Score": 0.98, "BeginOffset": 14, "EndOffset": 24},
            {"Type": "DATE_TIME", "Score": 0.98, "BeginOffset": 44, "EndOffset": 54},
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted, entities, counts = redactor.detect_and_redact(text)

    assert "Invoice Date: [DATE] and Date of Birth: [DOB]." == redacted
    assert counts == {"DATE": 1, "DOB": 1}


def test_asterisk_masking_mode_with_comprehend():
    mock_comprehend = MagicMock()
    text = "Secret Token: VERY_LONG_SECRET_KEY_12345"
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "PASSWORD", "Score": 0.99, "BeginOffset": 14, "EndOffset": 40}
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted, entities, counts = redactor.detect_and_redact(text, mask_mode="ASTERISK")

    assert "VERY_LONG_SECRET_KEY_12345" not in redacted
    # Fixed-length mask (5 asterisks), never revealing original 26-character length
    assert redacted == "Secret Token: *****"
    assert "*" * 26 not in redacted


def test_custom_keywords_additive_only():
    mock_comprehend = MagicMock()
    text = "Contact Jane Doe regarding ProjectPegasus today."
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "NAME", "Score": 0.99, "BeginOffset": 8, "EndOffset": 16}
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted, entities, counts = redactor.detect_and_redact(
        text,
        custom_keywords=["ProjectPegasus"]
    )

    assert "[NAME]" in redacted
    assert "[MASKED_TEXT]" in redacted
    assert "Jane Doe" not in redacted
    assert "ProjectPegasus" not in redacted
    assert counts == {"NAME": 1, "MASKED_TEXT": 1}


def test_no_personal_data_in_codebase():
    """Verifies that hard-coded personal data fixtures do not exist in source, scripts, or test files."""
    forbidden_terms = [
        "Naveenasri",
        "Rangaraju",
        "OOTHUMEDU",
        "RAMANAYACKENPALAYAM",
        "6383148839",
        "9976833799",
        "2457 3922 3844",
        "74484 05454",
        "717623104052",
    ]
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    checked_extensions = {".py", ".json", ".js", ".html", ".css", ".yaml", ".yml"}
    violations = []

    for root, dirs, files in os.walk(base_dir):
        # Exclude git, cache, and audit report (which discusses the audit findings)
        if any(ignored in root for ignored in [".git", "__pycache__", ".pytest_cache", ".aws-sam"]):
            continue
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in checked_extensions:
                file_path = os.path.join(root, file)
                if os.path.abspath(file_path) == os.path.abspath(__file__):
                    continue
                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                        for term in forbidden_terms:
                            if term.lower() in content.lower():
                                violations.append(f"{file_path} contains forbidden term: {term}")
                except Exception:
                    pass

    assert not violations, f"Personal data leaks found in repository files: {violations}"


def test_overlap_head_does_not_leak():
    mock_comprehend = MagicMock()
    text = "Reach John Alexander Smith for details."
    # Spans (6, 20) = "John Alexander" and (11, 26) = "Alexander Smith"
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "NAME", "Score": 0.95, "BeginOffset": 6, "EndOffset": 20},
            {"Type": "NAME", "Score": 0.95, "BeginOffset": 11, "EndOffset": 26},
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted, entities, counts = redactor.detect_and_redact(text)
    assert "John" not in redacted
    assert "Smith" not in redacted
    assert "Alexander" not in redacted
    assert redacted == "Reach [NAME] for details."


def test_overlap_tail_does_not_leak():
    mock_comprehend = MagicMock()
    text = "Reach John Alexander Smith for details."
    # Spans (6, 20) = "John Alexander" and (15, 26) = "ander Smith"
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "NAME", "Score": 0.95, "BeginOffset": 6, "EndOffset": 20},
            {"Type": "NAME", "Score": 0.95, "BeginOffset": 15, "EndOffset": 26},
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted, entities, counts = redactor.detect_and_redact(text)
    assert "John" not in redacted
    assert "Smith" not in redacted
    assert redacted == "Reach [NAME] for details."


def test_overlap_card_number_digits_do_not_leak():
    mock_comprehend = MagicMock()
    text = "Card 4111 2222 3333 4444 on file."
    # Spans (5, 15) = "4111 2222 " and (10, 24) = "2222 3333 4444"
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {"Type": "ID_NUMBER", "Score": 0.95, "BeginOffset": 5, "EndOffset": 15},
            {"Type": "ID_NUMBER", "Score": 0.95, "BeginOffset": 10, "EndOffset": 24},
        ]
    }
    redactor = PiiRedactor(comprehend_client=mock_comprehend)
    redacted, entities, counts = redactor.detect_and_redact(text)
    assert "4111" not in redacted
    assert "4444" not in redacted
    assert redacted == "Card [ID_NUMBER] on file."


def test_overlap_nested_spans():
    entities = [
        {"Type": "NAME", "Score": 0.90, "BeginOffset": 5, "EndOffset": 25},
        {"Type": "NAME", "Score": 0.99, "BeginOffset": 10, "EndOffset": 18},
    ]
    merged = PiiRedactor._resolve_overlapping_spans(entities)
    assert len(merged) == 1
    assert merged[0]["BeginOffset"] == 5
    assert merged[0]["EndOffset"] == 25


def test_overlap_adjacent_spans():
    entities = [
        {"Type": "NAME", "Score": 0.95, "BeginOffset": 5, "EndOffset": 10},
        {"Type": "EMAIL", "Score": 0.95, "BeginOffset": 10, "EndOffset": 20},
    ]
    merged = PiiRedactor._resolve_overlapping_spans(entities)
    assert len(merged) == 2
    assert (merged[0]["BeginOffset"], merged[0]["EndOffset"]) == (5, 10)
    assert (merged[1]["BeginOffset"], merged[1]["EndOffset"]) == (10, 20)


def test_overlap_identical_spans():
    entities = [
        {"Type": "NAME", "Score": 0.70, "BeginOffset": 5, "EndOffset": 15},
        {"Type": "NAME", "Score": 0.95, "BeginOffset": 5, "EndOffset": 15},
    ]
    merged = PiiRedactor._resolve_overlapping_spans(entities)
    assert len(merged) == 1
    assert (merged[0]["BeginOffset"], merged[0]["EndOffset"]) == (5, 15)


def test_overlap_random_property_test():
    import random
    text = "The quick brown fox jumps over the lazy dog and runs across the wide open green meadow."
    rng = random.Random(42)
    for _ in range(50):
        start1 = rng.randint(0, len(text) - 15)
        len1 = rng.randint(5, 15)
        end1 = start1 + len1

        start2 = rng.randint(start1, end1 - 1)
        len2 = rng.randint(5, 15)
        end2 = min(len(text), start2 + len2)

        spans = [
            {"Type": "NAME", "Score": 0.9, "BeginOffset": start1, "EndOffset": end1},
            {"Type": "NAME", "Score": 0.9, "BeginOffset": start2, "EndOffset": end2},
        ]
        merged = PiiRedactor._resolve_overlapping_spans(spans)

        expected_indices = set(range(start1, end1)) | set(range(start2, end2))
        covered_indices = set()
        for m in merged:
            covered_indices.update(range(m["BeginOffset"], m["EndOffset"]))
        assert expected_indices == covered_indices, f"Mismatch on spans ({start1}, {end1}) and ({start2}, {end2})"


def test_idempotent_same_s3_event_twice(moto_environment):
    """F5 Test: Same S3 event processed twice produces exactly one row in DynamoDB."""
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="application.pdf", Body=make_valid_pdf(1))

    mock_textract = MagicMock()
    mock_textract.detect_document_text.return_value = {
        "Blocks": [{"BlockType": "LINE", "Text": "Sample text line", "Confidence": 99.0}]
    }
    mock_comprehend = MagicMock()
    mock_comprehend.detect_pii_entities.return_value = {"Entities": []}

    pipeline_handler.text_extractor.textract = mock_textract
    pipeline_handler.pii_redactor.comprehend = mock_comprehend

    event = make_s3_event(env["raw_bucket"], "application.pdf", sequencer="005F9A1B2C")

    # Run event first time
    res1 = pipeline_handler.lambda_handler(event, None)
    assert res1["statusCode"] == 200
    assert res1["results"][0]["status"] == "COMPLETED"

    # Run the exact same event second time
    res2 = pipeline_handler.lambda_handler(event, None)
    assert res2["statusCode"] == 200
    assert res2["results"][0]["skipped"] is True

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "COMPLETED"
    assert items[0]["attempts"] == 1


def test_idempotent_transient_textract_failure_then_success(moto_environment):
    """F5 Test: Transient failure then retry success results in one row, COMPLETED, attempts=2."""
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="statement.png", Body=make_valid_png())

    event = make_s3_event(env["raw_bucket"], "statement.png", sequencer="005F9A1B2D")

    # Attempt 1: Textract fails with a transient throttling error
    mock_textract_fail = MagicMock()
    mock_textract_fail.detect_document_text.side_effect = ClientError(
        {"Error": {"Code": "ProvisionedThroughputExceededException", "Message": "Rate exceeded"}},
        "DetectDocumentText"
    )
    pipeline_handler.text_extractor.textract = mock_textract_fail

    with pytest.raises(ClientError):
        pipeline_handler.lambda_handler(event, None)

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["attempts"] == 1
    assert items[0]["error_step"] == "EXECUTION_ERROR"

    # Attempt 2: Textract succeeds on retry
    mock_textract_ok = MagicMock()
    mock_textract_ok.detect_document_text.return_value = {
        "Blocks": [{"BlockType": "LINE", "Text": "Account Statement Data", "Confidence": 98.0}]
    }
    mock_comprehend = MagicMock()
    mock_comprehend.detect_pii_entities.return_value = {"Entities": []}

    pipeline_handler.text_extractor.textract = mock_textract_ok
    pipeline_handler.pii_redactor.comprehend = mock_comprehend

    res2 = pipeline_handler.lambda_handler(event, None)
    assert res2["statusCode"] == 200
    assert res2["results"][0]["status"] == "COMPLETED"

    # Must still be exactly one row, now COMPLETED with attempts=2
    items_after = env["table"].scan().get("Items", [])
    assert len(items_after) == 1
    assert items_after[0]["status"] == "COMPLETED"
    assert items_after[0]["attempts"] == 2


def test_idempotent_three_failures_produces_one_failed_row(moto_environment):
    """F5 Test: Three consecutive failures produce exactly one FAILED row with attempts=3."""
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="corrupt.png", Body=make_valid_png())

    event = make_s3_event(env["raw_bucket"], "corrupt.png", sequencer="005F9A1B2E")

    mock_textract_fail = MagicMock()
    mock_textract_fail.detect_document_text.side_effect = ClientError(
        {"Error": {"Code": "InternalServerError", "Message": "Internal service error"}},
        "DetectDocumentText"
    )
    pipeline_handler.text_extractor.textract = mock_textract_fail

    # Attempt 1
    with pytest.raises(ClientError):
        pipeline_handler.lambda_handler(event, None)

    # Attempt 2
    with pytest.raises(ClientError):
        pipeline_handler.lambda_handler(event, None)

    # Attempt 3
    with pytest.raises(ClientError):
        pipeline_handler.lambda_handler(event, None)

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["attempts"] == 3
    assert items[0]["error_step"] == "EXECUTION_ERROR"

    # Attempt 4 (duplicate or delayed redrive after max retries): skipped
    res4 = pipeline_handler.lambda_handler(event, None)
    assert res4["statusCode"] == 200
    assert res4["results"][0]["skipped"] is True

    items_after = env["table"].scan().get("Items", [])
    assert len(items_after) == 1
    assert items_after[0]["status"] == "FAILED"
    assert items_after[0]["attempts"] == 3


def test_terminal_completed_never_overwritten_by_late_failed(moto_environment):
    """F5 Test: A terminal COMPLETED status is never overwritten by a late mark_failed."""
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="finished.pdf", Body=make_valid_pdf(1))

    mock_textract = MagicMock()
    mock_textract.detect_document_text.return_value = {
        "Blocks": [{"BlockType": "LINE", "Text": "Finished document text", "Confidence": 99.0}]
    }
    mock_comprehend = MagicMock()
    mock_comprehend.detect_pii_entities.return_value = {"Entities": []}

    pipeline_handler.text_extractor.textract = mock_textract
    pipeline_handler.pii_redactor.comprehend = mock_comprehend

    event = make_s3_event(env["raw_bucket"], "finished.pdf", sequencer="005F9A1B2F")
    res = pipeline_handler.lambda_handler(event, None)
    doc_id = res["results"][0]["document_id"]

    # Verify status is COMPLETED
    record_before = env["table"].get_item(Key={"document_id": doc_id})["Item"]
    assert record_before["status"] == "COMPLETED"

    # Simulate a delayed/late mark_failed invocation
    updated = pipeline_handler.dynamodb_manager.mark_failed(
        document_id=doc_id,
        failure_reason="Late failure simulation",
        error_step="EXECUTION_ERROR"
    )
    assert updated is False

    # Status must still be COMPLETED
    record_after = env["table"].get_item(Key={"document_id": doc_id})["Item"]
    assert record_after["status"] == "COMPLETED"
    assert record_after.get("failure_reason") is None


def test_opaque_ids_and_no_file_names_leak(moto_environment, caplog):
    """F13 Test: File name Priya_Raman_resume.pdf never leaks into document_id, DynamoDB attributes,
    processed keys, audit JSON, or log statements."""
    import logging
    env = moto_environment
    file_name = "Priya_Raman_resume.pdf"
    env["s3"].put_object(Bucket=env["raw_bucket"], Key=file_name, Body=make_valid_pdf(1))

    mock_textract = MagicMock()
    mock_textract.detect_document_text.return_value = {
        "Blocks": [{"BlockType": "LINE", "Text": "Candidate Resume content", "Confidence": 98.0}]
    }
    mock_comprehend = MagicMock()
    mock_comprehend.detect_pii_entities.return_value = {"Entities": []}

    pipeline_handler.text_extractor.textract = mock_textract
    pipeline_handler.pii_redactor.comprehend = mock_comprehend

    event = make_s3_event(env["raw_bucket"], file_name, sequencer="005F9A1B30")

    with caplog.at_level(logging.INFO):
        res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    doc_id = res["results"][0]["document_id"]

    # 1. document_id must be opaque (no file name)
    assert "Priya_Raman" not in doc_id
    assert "resume" not in doc_id

    # 2. Assert no DynamoDB attribute contains Priya_Raman
    record = env["table"].get_item(Key={"document_id": doc_id})["Item"]
    for k, v in record.items():
        assert "Priya_Raman" not in str(k), f"File name leaked into DynamoDB key: {k}"
        assert "Priya_Raman" not in str(v), f"File name leaked into DynamoDB attribute {k}: {v}"
        assert "resume" not in str(v) or k == "file_type", f"Leaked in attribute {k}: {v}"

    # 3. Assert processed S3 bucket keys are opaque
    proc_listing = env["s3"].list_objects_v2(Bucket=env["processed_bucket"])
    proc_keys = [o["Key"] for o in proc_listing.get("Contents", [])]
    for pk in proc_keys:
        assert "Priya_Raman" not in pk
        assert "resume" not in pk
        assert pk in (f"redacted/{doc_id}.txt", f"metadata/{doc_id}.metadata.json")

    # 4. Assert audit JSON contains no raw file name
    meta_obj = env["s3"].get_object(Bucket=env["processed_bucket"], Key=f"metadata/{doc_id}.metadata.json")
    audit_data = json.loads(meta_obj["Body"].read().decode("utf-8"))
    assert "Priya_Raman" not in json.dumps(audit_data)
    assert "resume" not in json.dumps(audit_data)
    assert "file_name" not in audit_data
    assert "raw_key" not in audit_data

    # 5. Assert captured logs contain no file name
    assert "Priya_Raman" not in caplog.text


def test_validation_rejects_zero_byte_file(moto_environment):
    """F10 Test: Zero-byte file is rejected as FAILED at VALIDATION without re-raising."""
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="empty.png", Body=b"")

    event = make_s3_event(env["raw_bucket"], "empty.png", size=0)
    res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    assert res["results"][0]["status"] == "FAILED"
    assert "Zero-byte" in res["results"][0]["reason"]

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["error_step"] == "VALIDATION"


def test_validation_rejects_oversized_file(moto_environment):
    """F10 Test: File exceeding 5 MB is rejected as FAILED at VALIDATION without re-raising."""
    env = moto_environment
    # 6 MB file
    oversized_data = b"\x89PNG\r\n\x1a\n" + b"\x00" * (6 * 1024 * 1024)
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="oversized.png", Body=oversized_data)

    event = make_s3_event(env["raw_bucket"], "oversized.png", size=len(oversized_data))
    res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    assert res["results"][0]["status"] == "FAILED"
    assert "exceeds limit" in res["results"][0]["reason"]

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["error_step"] == "VALIDATION"


def test_validation_rejects_corrupt_png_magic_bytes(moto_environment):
    """F10 Test: File with invalid PNG magic bytes is rejected as FAILED at VALIDATION."""
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="bad_header.png", Body=b"NOT_A_PNG_FILE_HEADER")

    event = make_s3_event(env["raw_bucket"], "bad_header.png", size=21)
    res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    assert res["results"][0]["status"] == "FAILED"
    assert "magic bytes" in res["results"][0]["reason"]

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["error_step"] == "VALIDATION"


def test_validation_rejects_multipage_pdf(moto_environment):
    """F10 Test: Multi-page PDF (> 1 page) is rejected as FAILED at VALIDATION."""
    env = moto_environment
    # 2 pages
    multi_page_bytes = make_valid_pdf(pages=2)
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="two_page_doc.pdf", Body=multi_page_bytes)

    event = make_s3_event(env["raw_bucket"], "two_page_doc.pdf", size=len(multi_page_bytes))
    res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    assert res["results"][0]["status"] == "FAILED"
    assert "Multi-page PDF rejected" in res["results"][0]["reason"]

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["error_step"] == "VALIDATION"


@pytest.mark.parametrize("error_code", [
    "UnsupportedDocumentException",
    "BadDocumentException",
    "DocumentTooLargeException",
    "InvalidParameterException",
])
def test_textract_client_document_errors_clean_fail(moto_environment, error_code):
    """F10 Test: Textract document errors are classified as clean FAILED/TEXT_EXTRACTION with no re-raise."""
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="doc_err.png", Body=make_valid_png())

    mock_textract = MagicMock()
    mock_textract.detect_document_text.side_effect = ClientError(
        {"Error": {"Code": error_code, "Message": f"Simulated {error_code}"}},
        "DetectDocumentText"
    )
    pipeline_handler.text_extractor.textract = mock_textract

    event = make_s3_event(env["raw_bucket"], "doc_err.png")
    # Must NOT raise exception
    res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    assert res["results"][0]["status"] == "FAILED"
    assert error_code in res["results"][0]["reason"]

    items = env["table"].scan().get("Items", [])
    assert len(items) == 1
    assert items[0]["status"] == "FAILED"
    assert items[0]["error_step"] == "TEXT_EXTRACTION"

    proc_objs = env["s3"].list_objects_v2(Bucket=env["processed_bucket"]).get("KeyCount", 0)
    assert proc_objs == 0


@pytest.mark.parametrize("error_code", [
    "ProvisionedThroughputExceededException",
    "ThrottlingException",
    "InternalServerError",
    "ServiceUnavailable",
])
def test_textract_throttling_or_5xx_reraises(moto_environment, error_code):
    """F10 Test: Throttling and 5xx errors re-raise so Lambda retries and SQS DLQ captures."""
    env = moto_environment
    env["s3"].put_object(Bucket=env["raw_bucket"], Key="transient.png", Body=make_valid_png())

    mock_textract = MagicMock()
    mock_textract.detect_document_text.side_effect = ClientError(
        {"Error": {"Code": error_code, "Message": f"Simulated {error_code}"}},
        "DetectDocumentText"
    )
    pipeline_handler.text_extractor.textract = mock_textract

    event = make_s3_event(env["raw_bucket"], "transient.png")
    # Must re-raise ClientError
    with pytest.raises(ClientError):
        pipeline_handler.lambda_handler(event, None)


# ============================================================================
# F2 TESTS: Hardened Management API & Function URL Lockdown
# ============================================================================

# ============================================================================
# F2 & F9 TESTS: Local Dashboard Server Hardening & Template Cleanliness
# ============================================================================

def test_template_has_no_management_function_or_api_url():
    """Verify ManagementFunction and ManagementApiUrl are completely deleted from template.yaml."""
    template_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "template.yaml"))
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()
    assert "ManagementFunction:" not in content
    assert "ManagementApiUrl:" not in content


@pytest.fixture
def dashboard_test_server(moto_environment):
    """Launches the hardened ThreadingHTTPServer on an ephemeral port with mock AWS resources."""
    import threading
    server = dashboard_server.ThreadingHTTPServer(("127.0.0.1", 0), dashboard_server.PipelineDashboardHandler)
    host, port = server.server_address[:2]
    server_addr = f"{host}:{port}"

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    yield server_addr

    server.shutdown()
    server.server_close()


def test_f9_upload_sample_path_traversal_and_allowlist(dashboard_test_server):
    """F9 Test: POST /upload-sample?file=../README.md returns 400, not 200/500; only files in sample_docs allowed."""
    import http.client
    host = dashboard_test_server

    traversal_files = [
        "../README.md",
        "..\\template.yaml",
        "nested/path.png",
        "nonexistent_sample.png",
        "",
    ]
    for filename in traversal_files:
        conn = http.client.HTTPConnection(host)
        conn.request(
            "POST",
            f"/upload-sample?file={urllib.parse.quote(filename)}",
            headers={"Host": host, "Origin": "http://localhost:8000"}
        )
        resp = conn.getresponse()
        assert resp.status == 400, f"Expected 400 for sample '{filename}', got {resp.status}"
        data = json.loads(resp.read().decode())
        assert "error" in data
        conn.close()

    # Valid sample in sample_docs succeeds and returns deterministic document_id
    conn = http.client.HTTPConnection(host)
    conn.request(
        "POST",
        "/upload-sample?file=sample_id_card.png",
        headers={"Host": host, "Origin": "http://localhost:8000"}
    )
    resp = conn.getresponse()
    assert resp.status == 200
    data = json.loads(resp.read().decode())
    assert data["status"] == "SUCCESS"
    assert "document_id" in data
    assert len(data["document_id"]) == 24
    conn.close()


def test_f9_foreign_host_and_origin_rejected_403(dashboard_test_server):
    """F9 Test: Requests with foreign Host or Origin headers are rejected with 403 Forbidden."""
    import http.client
    host = dashboard_test_server

    # Foreign Host header
    conn = http.client.HTTPConnection(host)
    conn.request("GET", "/stats", headers={"Host": "malicious-site.com"})
    resp = conn.getresponse()
    assert resp.status == 403
    conn.close()

    # Foreign Origin header
    conn = http.client.HTTPConnection(host)
    conn.request("GET", "/stats", headers={"Host": host, "Origin": "http://evil-attacker.com"})
    resp = conn.getresponse()
    assert resp.status == 403
    conn.close()

    # Allowed Host and Origin
    conn = http.client.HTTPConnection(host)
    conn.request("GET", "/stats", headers={"Host": host, "Origin": "http://localhost:8000"})
    resp = conn.getresponse()
    assert resp.status == 200
    conn.close()


def test_f9_payload_size_cap_413(dashboard_test_server):
    """F9 Test: Request payloads exceeding 10 MB limit are rejected with 413 Payload Too Large."""
    import http.client
    host = dashboard_test_server

    conn = http.client.HTTPConnection(host)
    oversized_length = 11 * 1024 * 1024  # 11 MB
    # Send headers indicating payload > 10MB without needing to send all bytes
    conn.putrequest("POST", "/upload-direct")
    conn.putheader("Host", host)
    conn.putheader("Origin", "http://localhost:8000")
    conn.putheader("Content-Length", str(oversized_length))
    conn.endheaders()

    resp = conn.getresponse()
    assert resp.status == 413
    data = json.loads(resp.read().decode())
    assert "Payload too large" in data["error"]
    conn.close()


def test_f9_upload_direct_validation_and_deterministic_id(dashboard_test_server):
    """F9 Test: POST /upload-direct catches JSON/base64 errors, rejects path traversal, and returns document_id."""
    import http.client
    host = dashboard_test_server

    # Malformed JSON
    conn = http.client.HTTPConnection(host)
    conn.request(
        "POST",
        "/upload-direct",
        body="not-a-valid-json",
        headers={"Host": host, "Origin": "http://localhost:8000", "Content-Type": "application/json"}
    )
    resp = conn.getresponse()
    assert resp.status == 400
    conn.close()

    # Invalid base64
    conn = http.client.HTTPConnection(host)
    payload_bad_b64 = json.dumps({"file_name": "doc.png", "data_base64": "!!!not_base64!!!"})
    conn.request(
        "POST",
        "/upload-direct",
        body=payload_bad_b64,
        headers={"Host": host, "Origin": "http://localhost:8000", "Content-Type": "application/json"}
    )
    resp = conn.getresponse()
    assert resp.status == 400
    conn.close()

    # Path traversal in file_name
    conn = http.client.HTTPConnection(host)
    payload_traversal = json.dumps({"file_name": "../secret.png", "data_base64": base64.b64encode(b"test").decode()})
    conn.request(
        "POST",
        "/upload-direct",
        body=payload_traversal,
        headers={"Host": host, "Origin": "http://localhost:8000", "Content-Type": "application/json"}
    )
    resp = conn.getresponse()
    assert resp.status == 400
    conn.close()

    # Valid direct upload
    valid_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
    valid_b64 = base64.b64encode(valid_bytes).decode("ascii")
    payload_valid = json.dumps({"file_name": "passport.png", "data_base64": valid_b64})
    conn = http.client.HTTPConnection(host)
    conn.request(
        "POST",
        "/upload-direct",
        body=payload_valid,
        headers={"Host": host, "Origin": "http://localhost:8000", "Content-Type": "application/json"}
    )
    resp = conn.getresponse()
    assert resp.status == 200
    res_data = json.loads(resp.read().decode())
    assert res_data["status"] == "SUCCESS"
    assert "document_id" in res_data
    assert len(res_data["document_id"]) == 24
    conn.close()


def test_f9_no_wildcard_cors(dashboard_test_server):
    """F9 Test: Verify Access-Control-Allow-Origin is never wildcard '*'."""
    import http.client
    host = dashboard_test_server

    conn = http.client.HTTPConnection(host)
    conn.request("GET", "/stats", headers={"Host": host, "Origin": "http://localhost:8000"})
    resp = conn.getresponse()
    assert resp.status == 200
    allow_origin = resp.getheader("Access-Control-Allow-Origin")
    assert allow_origin != "*"
    assert allow_origin == "http://localhost:8000"
    conn.close()


def test_f11_alarm_on_number_of_messages_sent_with_ok_actions():
    """
    F11 Test: Verify CloudWatch DLQ alarm monitors NumberOfMessagesSent,
    triggers on >= 1 message, includes OKActions to notify when queue is drained,
    uses TreatMissingData: notBreaching, and documents a runbook.
    """
    template_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "template.yaml"))
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()

    assert "DLQAlarm:" in content
    assert "MetricName: NumberOfMessagesSent" in content
    assert "Namespace: AWS/SQS" in content
    assert "TreatMissingData: notBreaching" in content
    assert "ComparisonOperator: GreaterThanOrEqualToThreshold" in content
    assert "AlarmActions:" in content
    assert "OKActions:" in content
    assert "Runbook:" in content or "runbook:" in content.lower()


def test_f17_graceful_timeout_handling(moto_environment):
    """
    F17 Test: When Lambda context indicates depleted execution time (< 10000ms),
    handler stops execution gracefully before downstream stages and marks record
    as FAILED with error_step='TIMEOUT', recording lambda_request_id, attempts,
    and processing_started_at.
    """
    s3 = moto_environment["s3"]
    bucket = "test-raw-bucket"
    key = "raw/sample_timeout.png"
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
    s3.put_object(Bucket=bucket, Key=key, Body=png_bytes)

    class TimeoutContext:
        aws_request_id = "req-timeout-999"
        def get_remaining_time_in_millis(self):
            return 4000

    event = {
        "Records": [
            {
                "eventVersion": "2.1",
                "eventSource": "aws:s3",
                "awsRegion": "us-east-1",
                "eventTime": "2026-10-19T12:00:00.000Z",
                "eventName": "ObjectCreated:Put",
                "s3": {
                    "bucket": {"name": bucket},
                    "object": {"key": key, "size": len(png_bytes), "eTag": "etag-timeout-1"},
                    "s3SchemaVersion": "1.0",
                    "configurationId": "testConfig"
                }
            }
        ]
    }

    result = pipeline_handler.lambda_handler(event, TimeoutContext())
    assert result["statusCode"] == 200
    assert result["processed_count"] == 1
    processed_doc = result["results"][0]
    assert processed_doc["status"] == "FAILED"
    assert processed_doc["error_step"] == "TIMEOUT"

    table = moto_environment["table"]
    doc_id = processed_doc["document_id"]
    item = table.get_item(Key={"document_id": doc_id}).get("Item")
    assert item is not None
    assert item["status"] == "FAILED"
    assert item["error_step"] == "TIMEOUT"
    assert "remaining" in item["failure_reason"].lower()
    assert item["lambda_request_id"] == "req-timeout-999"
    assert item["attempts"] == 1
    assert "processing_started_at" in item


def test_f12_list_and_stats_gsi_query_with_200_rows(moto_environment):
    """
    F12 Test: Seed 200 documents across statuses into DynamoDB;
    verify that get_table_stats returns totals equal to 200,
    and fetch_table_items_by_gsi always returns the newest upload first.
    """
    table = moto_environment["table"]
    mgr = DynamoDBManager(table_name="test-document-tracking", dynamodb_resource=moto_environment["dynamodb"])

    now_base = "2026-01-01T10:00:"
    with table.batch_writer() as batch:
        for i in range(120):
            batch.put_item(Item={
                "document_id": f"comp-{i:03d}",
                "status": "COMPLETED",
                "upload_timestamp": f"{now_base}{i % 60:02d}.000Z",
                "pii_count": 2,
            })
        for i in range(50):
            batch.put_item(Item={
                "document_id": f"fail-{i:03d}",
                "status": "FAILED",
                "upload_timestamp": f"{now_base}{i % 60:02d}.000Z",
                "error_step": "VALIDATION",
            })
        for i in range(29):
            batch.put_item(Item={
                "document_id": f"proc-{i:03d}",
                "status": "PROCESSING",
                "upload_timestamp": f"{now_base}{i % 60:02d}.000Z",
                "attempts": 1,
            })
        batch.put_item(Item={
            "document_id": "doc-newest-200",
            "status": "PROCESSING",
            "upload_timestamp": "2026-10-19T23:59:59.999Z",
            "attempts": 1,
        })

    # 1. Verify totals equal 200
    stats = dashboard_server.get_table_stats(table)
    assert stats["total_documents"] == 200
    assert stats["completed"] == 120
    assert stats["failed"] == 50
    assert stats["processing"] == 30
    assert stats["total_pii_redacted"] == 240

    # 2. Verify DynamoDBManager count_by_status and query_by_status
    assert mgr.count_by_status("COMPLETED") == 120
    assert mgr.count_by_status("FAILED") == 50
    assert mgr.count_by_status("PROCESSING") == 30

    comp_items, _ = mgr.query_by_status("COMPLETED", limit=10)
    assert len(comp_items) == 10
    assert all(item["status"] == "COMPLETED" for item in comp_items)

    # 3. Verify newest upload ALWAYS appears at the top
    items = dashboard_server.fetch_table_items_by_gsi(table, limit=50)
    assert len(items) > 0
    assert items[0]["document_id"] == "doc-newest-200"
    assert items[0]["status"] == "PROCESSING"

    # 4. Filter by status
    failed_items = dashboard_server.fetch_table_items_by_gsi(table, status_filter="FAILED", limit=20)
    assert len(failed_items) == 20
    assert all(i["status"] == "FAILED" for i in failed_items)


def test_f12_dashboard_api_stats_and_list_200_rows(dashboard_test_server, moto_environment):
    """
    F12 Test: Seed 200 documents and verify /stats and /documents HTTP endpoints.
    """
    import http.client
    host = dashboard_test_server
    table = moto_environment["table"]

    with table.batch_writer() as batch:
        for i in range(150):
            batch.put_item(Item={
                "document_id": f"api-comp-{i:03d}",
                "status": "COMPLETED",
                "upload_timestamp": f"2026-05-01T12:{i % 60:02d}:00Z",
                "pii_count": 1,
            })
        for i in range(49):
            batch.put_item(Item={
                "document_id": f"api-fail-{i:03d}",
                "status": "FAILED",
                "upload_timestamp": f"2026-05-01T13:{i % 60:02d}:00Z",
            })
        batch.put_item(Item={
            "document_id": "api-newest-upload",
            "status": "PROCESSING",
            "upload_timestamp": "2026-10-19T23:59:59.000Z",
        })

    dashboard_server.invalidate_items_cache()

    # Check /stats HTTP endpoint
    conn = http.client.HTTPConnection(host)
    conn.request("GET", "/stats", headers={"Host": host, "Origin": "http://localhost:8000"})
    resp = conn.getresponse()
    assert resp.status == 200
    data = json.loads(resp.read().decode())
    assert data["total_documents"] == 200
    assert data["completed"] == 150
    assert data["failed"] == 49
    assert data["processing"] == 1
    conn.close()

    # Check /documents HTTP endpoint - newest item is present at index 0
    conn = http.client.HTTPConnection(host)
    conn.request("GET", "/documents", headers={"Host": host, "Origin": "http://localhost:8000"})
    resp = conn.getresponse()
    assert resp.status == 200
    doc_data = json.loads(resp.read().decode())
    assert doc_data["stats"]["total_documents"] == 200
    docs = doc_data["documents"]
    assert any(d["document_id"] == "api-newest-upload" for d in docs)
    assert docs[0]["document_id"] == "api-newest-upload"
    conn.close()


def test_f14_no_pii_or_keys_in_logs_and_caplog(moto_environment, caplog):
    """
    F14 Test: Verify that neither sensitive file names (e.g. Priya_Raman_resume.pdf)
    nor raw S3 keys appear in captured logger output during processing.
    """
    import logging
    caplog.set_level(logging.INFO)

    s3 = moto_environment["s3"]
    bucket = "test-raw-bucket"
    sensitive_file_name = "Priya_Raman_confidential_resume.png"
    key = f"raw/{sensitive_file_name}"
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
    s3.put_object(Bucket=bucket, Key=key, Body=png_bytes)

    # Mock Textract & Comprehend for clean execution
    mock_textract = MagicMock()
    mock_textract.detect_document_text.return_value = {
        "Blocks": [{"BlockType": "LINE", "Text": "Sample clean application text", "Confidence": 99.0}]
    }
    mock_comp = MagicMock()
    mock_comp.detect_pii_entities.return_value = {"Entities": []}
    pipeline_handler.text_extractor.textract = mock_textract
    pipeline_handler.pii_redactor.comprehend = mock_comp

    event = {
        "Records": [
            {
                "eventVersion": "2.1",
                "eventSource": "aws:s3",
                "awsRegion": "us-east-1",
                "eventTime": "2026-10-19T12:00:00.000Z",
                "eventName": "ObjectCreated:Put",
                "s3": {
                    "bucket": {"name": bucket},
                    "object": {"key": key, "size": len(png_bytes), "eTag": "etag-log-1"},
                    "s3SchemaVersion": "1.0",
                    "configurationId": "testConfig"
                }
            }
        ]
    }

    class MockContext:
        aws_request_id = "req-log-test-123"
        def get_remaining_time_in_millis(self):
            return 60000

    result = pipeline_handler.lambda_handler(event, MockContext())
    assert result["statusCode"] == 200

    # Assert no sensitive filename appears in the logs
    all_logs = caplog.text
    assert sensitive_file_name not in all_logs
    assert "Priya_Raman" not in all_logs
    assert "raw/Priya_Raman" not in all_logs


def test_f14_log_retention_and_no_str_e_in_stored_reasons(moto_environment):
    """
    F14 Test: Verify CloudFormation template specifies 14-day log retention for ProcessorFunction,
    and unhandled errors store scrubbed error classes rather than raw str(e) stack/ARN dumps.
    """
    template_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "template.yaml"))
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()

    assert "ProcessorFunctionLogGroup:" in content
    assert "RetentionInDays: 14" in content
    assert "AWS::Logs::LogGroup" in content

    # Test error scrubbing on unhandled exception
    s3 = moto_environment["s3"]
    bucket = "test-raw-bucket"
    key = "raw/crash_test_doc.png"
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
    s3.put_object(Bucket=bucket, Key=key, Body=png_bytes)

    event = {
        "Records": [
            {
                "eventVersion": "2.1",
                "eventSource": "aws:s3",
                "awsRegion": "us-east-1",
                "eventTime": "2026-10-19T12:00:00.000Z",
                "eventName": "ObjectCreated:Put",
                "s3": {
                    "bucket": {"name": bucket},
                    "object": {"key": key, "size": len(png_bytes), "eTag": "etag-crash-1"},
                    "s3SchemaVersion": "1.0",
                    "configurationId": "testConfig"
                }
            }
        ]
    }

    class CrashContext:
        aws_request_id = "req-crash-123"
        def get_remaining_time_in_millis(self):
            return 60000

    orig_extract = pipeline_handler.text_extractor.extract_text_from_s3
    try:
        pipeline_handler.text_extractor.extract_text_from_s3 = MagicMock(
            side_effect=RuntimeError("Internal Database Connection to arn:aws:dynamodb:us-east-1:123456789012:table/internal_table leaked secrets")
        )
        with pytest.raises(RuntimeError):
            pipeline_handler.lambda_handler(event, CrashContext())

        table = moto_environment["table"]
        doc_id = hashlib.sha256(f"{bucket}/{key}/etag-crash-1".encode("utf-8")).hexdigest()[:24]
        item = table.get_item(Key={"document_id": doc_id}).get("Item")
        assert item is not None
        assert item["status"] == "FAILED"
        assert item["error_step"] == "EXECUTION_ERROR"
        assert "Unhandled pipeline exception" in item["failure_reason"]
        assert "123456789012" not in item["failure_reason"]
        assert "leaked secrets" not in item["failure_reason"]
        assert "[REDACTED_ARN]" in item["failure_reason"]
        assert "[REDACTED]" in item["failure_reason"]
    finally:
        pipeline_handler.text_extractor.extract_text_from_s3 = orig_extract


def test_f15_least_privilege_iam_statements_in_template():
    """
    F15 Test: Verify SAM template contains explicit least-privilege IAM statements
    instead of broad CRUD policy templates (no DynamoDBCrudPolicy, no S3CrudPolicy).
    """
    template_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "template.yaml"))
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Broad policy templates must be removed
    assert "DynamoDBCrudPolicy:" not in content
    assert "S3CrudPolicy:" not in content
    assert "S3ReadPolicy:" not in content

    # Scoped permissions must be present
    assert "s3:GetObject" in content
    assert "s3:PutObject" in content
    assert "dynamodb:PutItem" in content
    assert "dynamodb:UpdateItem" in content
    assert "dynamodb:GetItem" in content
    assert "sqs:SendMessage" in content
    assert "textract:DetectDocumentText" in content
    assert "comprehend:DetectPiiEntities" in content

    # Dangerous / unneeded permissions must not be granted
    assert "dynamodb:DeleteItem" not in content
    assert "comprehend:ContainsPiiEntities" not in content


def test_f16_bucket_policies_lifecycle_and_teardown():
    """
    F16 Test: Verify bucket TLS enforcement, processed bucket lifecycle,
    incomplete multipart upload abort, lack of open CORS, table deletion policy,
    and documented sam delete teardown.
    """
    template_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "template.yaml"))
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()

    # TLS Deny policy on both buckets
    assert "RawBucketPolicy:" in content
    assert "ProcessedBucketPolicy:" in content
    assert '"aws:SecureTransport": "false"' in content

    # No open wildcard CORS
    assert 'AllowedOrigins: ["*"]' not in content

    # Lifecycle rules with AbortIncompleteMultipartUpload
    assert "AbortIncompleteMultipartUpload:" in content
    assert "DaysAfterInitiation: 1" in content
    assert "ExpireProcessedDocumentsAfterRetentionDays" in content
    assert "ExpirationInDays: 30" in content

    # Table DeletionPolicy
    assert "DeletionPolicy: Delete" in content

    # README sam delete teardown documentation
    readme_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "README.md"))
    with open(readme_path, "r", encoding="utf-8") as f:
        readme_content = f.read()

    assert "Teardown & Clean Up" in readme_content
    assert "sam delete" in readme_content
    assert "aws s3 rm s3://" in readme_content
    assert "empty the processed documents bucket" in readme_content.lower()


def test_f18_stage_timeline_and_provenance(moto_environment):
    """
    F18 Test: Happy-path handler execution asserts that:
    1. The DynamoDB record contains a 'stages' list with all 5 stages in order:
       ['uploaded', 'validated', 'ocr_done', 'pii_done', 'stored'].
    2. Each stage dict contains timestamp/at, service, and duration_ms/ms.
    3. The stage timestamps are non-decreasing ISO8601 strings.
    4. Service attribution is correct:
       - uploaded -> S3
       - validated -> S3
       - ocr_done -> Textract
       - pii_done -> Comprehend
       - stored -> S3
    5. Provenance engine indicators ocr_engine='textract' and pii_engine='comprehend'
       are recorded on the DynamoDB record and the audit metadata JSON.
    """
    env = moto_environment
    file_name = "f18_test_scholarship.pdf"
    pdf_bytes = make_valid_pdf(1)
    env["s3"].put_object(Bucket=env["raw_bucket"], Key=file_name, Body=pdf_bytes)

    mock_textract = MagicMock()
    mock_textract.detect_document_text.return_value = {
        "Blocks": [
            {"BlockType": "PAGE"},
            {"BlockType": "LINE", "Text": "Student Name: Ananya Sharma", "Confidence": 99.0},
            {"BlockType": "LINE", "Text": "Marks: 95.5% in Mathematics", "Confidence": 98.0}
        ]
    }
    mock_comprehend = MagicMock()
    mock_comprehend.detect_pii_entities.return_value = {
        "Entities": [
            {
                "Type": "NAME",
                "Score": 0.99,
                "BeginOffset": 14,
                "EndOffset": 27
            }
        ]
    }

    pipeline_handler.text_extractor.textract = mock_textract
    pipeline_handler.pii_redactor.comprehend = mock_comprehend

    event = make_s3_event(env["raw_bucket"], file_name, sequencer="SEQ_F18_001")
    res = pipeline_handler.lambda_handler(event, None)

    assert res["statusCode"] == 200
    assert len(res["results"]) == 1
    result = res["results"][0]
    assert result["status"] == "COMPLETED"
    doc_id = result["document_id"]

    # 1. Inspect DynamoDB record
    record = env["table"].get_item(Key={"document_id": doc_id})["Item"]
    assert record["status"] == "COMPLETED"
    assert record["ocr_engine"] == "textract"
    assert record["pii_engine"] == "comprehend"

    # 2. Check stages list
    stages = record.get("stages", [])
    assert len(stages) == 5, f"Expected 5 stages, got {len(stages)}: {stages}"

    expected_stages = ["uploaded", "validated", "ocr_done", "pii_done", "stored"]
    actual_stages = [s["stage"] for s in stages]
    assert actual_stages == expected_stages, f"Stages not in expected order: {actual_stages}"

    expected_services = ["S3", "S3", "Textract", "Comprehend", "S3"]
    actual_services = [s["service"] for s in stages]
    assert actual_services == expected_services, f"Services mismatch: {actual_services}"

    # 3. Check timestamps, duration, and monotonicity
    timestamps = []
    for s in stages:
        ts = s.get("at") or s.get("timestamp")
        assert ts is not None, f"Stage {s['stage']} missing timestamp/at"
        timestamps.append(ts)

        assert "service" in s, f"Stage {s['stage']} missing service"
        assert ("duration_ms" in s) or ("ms" in s), f"Stage {s['stage']} missing duration_ms/ms"
        duration = s.get("duration_ms", s.get("ms"))
        assert duration >= 0, f"Stage {s['stage']} duration should be non-negative"

    # Assert non-decreasing timestamps
    for i in range(len(timestamps) - 1):
        assert timestamps[i] <= timestamps[i + 1], (
            f"Timestamps not non-decreasing: {timestamps[i]} > {timestamps[i+1]} "
            f"between {actual_stages[i]} and {actual_stages[i+1]}"
        )

    # 4. Check audit metadata JSON in S3 processed bucket
    meta_key = record["metadata_key"]
    meta_res = env["s3"].get_object(Bucket=env["processed_bucket"], Key=meta_key)
    meta_data = json.loads(meta_res["Body"].read().decode("utf-8"))

    assert meta_data["ocr_engine"] == "textract"
    assert meta_data["pii_engine"] == "comprehend"
    assert "stages" in meta_data
    assert [s["stage"] for s in meta_data["stages"]] == expected_stages


def test_f20_cleanup_and_docs_and_scripts():
    """
    F20 Test: Verifies repository cleanup, documentation accuracy,
    and hardening of deploy.ps1 & simulate_failure.py:
    1. AI_REVIEW_PROMPTS.md and duplicate sample_document.png do not exist.
    2. .gitignore exists and contains .aws-sam, __pycache__, .env, and .pytest_cache.
    3. LICENSE exists and matches MIT license.
    4. deploy.ps1 runs 'aws sts get-caller-identity' and 'sam validate --lint',
       accepts -Environment, and warns when AlertEmail is empty.
    5. simulate_failure.py verifies DLQ arrival, ALARM state, and confirmed SNS
       subscription before exiting 0, and cleans up test rows.
    6. template.yaml does not contain public unauthenticated AuthType: NONE.
    """
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

    # 1. Deleted unnecessary files
    assert not os.path.exists(os.path.join(repo_root, "AI_REVIEW_PROMPTS.md"))
    assert not os.path.exists(os.path.join(repo_root, "sample_docs", "sample_document.png"))

    # 2. .gitignore
    gitignore_path = os.path.join(repo_root, ".gitignore")
    assert os.path.exists(gitignore_path)
    with open(gitignore_path, "r", encoding="utf-8") as f:
        gi_content = f.read()
    assert ".aws-sam" in gi_content
    assert "__pycache__" in gi_content
    assert ".env" in gi_content
    assert ".pytest_cache" in gi_content

    # 3. LICENSE
    license_path = os.path.join(repo_root, "LICENSE")
    assert os.path.exists(license_path)
    with open(license_path, "r", encoding="utf-8") as f:
        lic_content = f.read()
    assert "MIT License" in lic_content

    # 4. deploy.ps1
    deploy_path = os.path.join(repo_root, "deploy.ps1")
    assert os.path.exists(deploy_path)
    with open(deploy_path, "r", encoding="utf-8") as f:
        deploy_content = f.read()
    assert "aws sts get-caller-identity" in deploy_content
    assert "sam validate --lint" in deploy_content
    assert "$Environment" in deploy_content
    assert "AlertEmail" in deploy_content
    assert "WARNING: AlertEmail parameter is empty" in deploy_content

    # 5. simulate_failure.py
    sim_path = os.path.join(repo_root, "scripts", "simulate_failure.py")
    assert os.path.exists(sim_path)
    with open(sim_path, "r", encoding="utf-8") as f:
        sim_content = f.read()
    assert "list_subscriptions_by_topic" in sim_content
    assert "PendingConfirmation" in sim_content
    assert "StateValue" in sim_content
    assert "ALARM" in sim_content
    assert "delete_item" in sim_content
    assert "sys.exit(1)" in sim_content

    # 6. template.yaml contains no public unauthenticated AuthType: NONE
    tmpl_path = os.path.join(repo_root, "template.yaml")
    with open(tmpl_path, "r", encoding="utf-8") as f:
        tmpl_content = f.read()
    assert "AuthType: NONE" not in tmpl_content


@patch("simulate_failure.time.sleep", return_value=None)
def test_f20_simulate_failure_mock_logic(mock_sleep):
    """
    F20 Test: Verifies that test_unhandled_failure_and_dlq in simulate_failure.py
    returns False when DLQ message fails to arrive or subscription is unconfirmed,
    and returns True when all 3 conditions succeed.
    """
    import simulate_failure  # type: ignore
    mock_lambda = MagicMock()
    mock_sqs = MagicMock()
    mock_cw = MagicMock()
    mock_sns = MagicMock()
    mock_dynamodb = MagicMock()

    # Case 1: Message does not arrive in DLQ
    mock_sqs.get_queue_attributes.return_value = {"Attributes": {"ApproximateNumberOfMessages": "0"}}
    res = simulate_failure.test_unhandled_failure_and_dlq(
        lambda_client=mock_lambda,
        sqs_client=mock_sqs,
        cw_client=mock_cw,
        sns_client=mock_sns,
        dynamodb_resource=mock_dynamodb,
        function_arn="arn:aws:lambda:us-east-1:123456789012:function:test",
        dlq_url="https://sqs.us-east-1.amazonaws.com/123456789012/test-dlq",
        alarm_name="test-alarm",
        topic_arn="arn:aws:sns:us-east-1:123456789012:test-topic",
        table_name="test-table"
    )
    assert res is False

    # Case 2: Message arrives, alarm reaches ALARM, but subscription is PendingConfirmation
    mock_sqs.get_queue_attributes.side_effect = [
        {"Attributes": {"ApproximateNumberOfMessages": "0"}},
        {"Attributes": {"ApproximateNumberOfMessages": "1"}}
    ]
    mock_cw.describe_alarms.return_value = {
        "MetricAlarms": [{"StateValue": "ALARM", "StateReason": "Threshold Breached"}]
    }
    mock_sns.list_subscriptions_by_topic.return_value = {
        "Subscriptions": [
            {"Endpoint": "user@example.com", "SubscriptionArn": "PendingConfirmation", "Protocol": "email"}
        ]
    }
    res_pending = simulate_failure.test_unhandled_failure_and_dlq(
        lambda_client=mock_lambda,
        sqs_client=mock_sqs,
        cw_client=mock_cw,
        sns_client=mock_sns,
        dynamodb_resource=mock_dynamodb,
        function_arn="arn:aws:lambda:us-east-1:123456789012:function:test",
        dlq_url="https://sqs.us-east-1.amazonaws.com/123456789012/test-dlq",
        alarm_name="test-alarm",
        topic_arn="arn:aws:sns:us-east-1:123456789012:test-topic",
        table_name="test-table"
    )
    assert res_pending is False

    # Case 3: All 3 conditions satisfied: message arrived, ALARM state, confirmed subscription
    mock_sqs.get_queue_attributes.side_effect = [
        {"Attributes": {"ApproximateNumberOfMessages": "0"}},
        {"Attributes": {"ApproximateNumberOfMessages": "1"}}
    ]
    mock_sns.list_subscriptions_by_topic.return_value = {
        "Subscriptions": [
            {"Endpoint": "user@example.com", "SubscriptionArn": "arn:aws:sns:us-east-1:123456789012:test-topic:sub-uuid", "Protocol": "email"}
        ]
    }
    res_ok = simulate_failure.test_unhandled_failure_and_dlq(
        lambda_client=mock_lambda,
        sqs_client=mock_sqs,
        cw_client=mock_cw,
        sns_client=mock_sns,
        dynamodb_resource=mock_dynamodb,
        function_arn="arn:aws:lambda:us-east-1:123456789012:function:test",
        dlq_url="https://sqs.us-east-1.amazonaws.com/123456789012/test-dlq",
        alarm_name="test-alarm",
        topic_arn="arn:aws:sns:us-east-1:123456789012:test-topic",
        table_name="test-table"
    )
    assert res_ok is True



